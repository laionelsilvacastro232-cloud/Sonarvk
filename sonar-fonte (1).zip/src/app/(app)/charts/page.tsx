import Link from "next/link";
import { Suspense } from "react";
import { getChart, type ChartPeriod, type ChartScope } from "@/lib/charts";
import { getCurrentUser } from "@/lib/auth";
import { PageHeader } from "@/components/Cards";
import { ChartList, ChartPeriodTabs, ChartScopeTabs } from "@/components/ChartsUi";
import { fmtDate } from "@/lib/format";

export const metadata = { title: "Charts" };
export const dynamic = "force-dynamic";

export default async function ChartsPage({ searchParams }: { searchParams: Promise<{ escopo?: string; periodo?: string }> }) {
  const { escopo, periodo } = await searchParams;
  const scope: ChartScope = escopo === "artistas" ? "artists" : "tracks";
  const period: ChartPeriod = periodo === "mes" ? "month" : periodo === "geral" ? "all" : "week";
  const user = await getCurrentUser();

  return (
    <div className="mx-auto max-w-[900px]">
      <PageHeader eyebrow="Ranking" title="Charts" />
      <p className="mb-6 max-w-[600px] text-sm text-[color:var(--text)/0.55]">
        Ranking calculado a partir de reproduções reais na plataforma. Cada posição guarda o histórico para mostrar a variação em relação à medição anterior.
      </p>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <ChartScopeTabs scope={scope} />
        <ChartPeriodTabs period={period} />
      </div>

      <Suspense fallback={<ChartSkeleton />}>
        <ChartContent scope={scope} period={period} />
      </Suspense>
    </div>
  );
}

async function ChartContent({ scope, period }: { scope: ChartScope; period: ChartPeriod }) {
  const { rows, hasData } = await getChart(scope, period, 50);

  if (!hasData) {
    return (
      <div className="rounded-2xl border border-dashed border-[color:var(--border-strong)] px-6 py-14 text-center">
        <p className="text-lg font-semibold">Ainda não há dados suficientes para um ranking.</p>
        <p className="mx-auto mt-2 max-w-[420px] text-sm text-[color:var(--text)/0.5]">
          O ranking é gerado a partir de reproduções reais de músicas e artistas desta plataforma. Quando houver atividade suficiente, o chart aparece aqui automaticamente. Não exibimos números fictícios.
        </p>
      </div>
    );
  }

  const movements = rows.filter((r) => r.change != null && r.change !== 0).length;
  const newText = rows.filter((r) => r.change == null).length;

  return (
    <div>
      <p className="mb-4 text-xs text-[color:var(--text)/0.4">
        {rows.length} posições · {movements} em movimento · {newText} entradas novas · gerado em {fmtDate(new Date())}
      </p>
      <ChartList rows={rows} scope={scope} />
    </div>
  );
}

function ChartSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 rounded-xl border border-[color:var(--border)] p-3">
          <div className="h-8 w-8 animate-pulse rounded-lg bg-[color:var(--accent)/0.08]" />
          <div className="h-4 flex-1 animate-pulse rounded bg-[color:var(--accent)/0.08]" />
        </div>
      ))}
    </div>
  );
}
