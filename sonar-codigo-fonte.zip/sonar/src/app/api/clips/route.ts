import { NextResponse } from "next/server";
import { db } from "@/db";
import { tracks, artists, users, clipLikes, clipComments, clipReposts, notifications } from "@/db/schema";
import { eq, and, desc, ne, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";

// Clipes = músicas publicadas que têm videoclipe (tracks.videoUrl).
async function clipsPayload(meId: number | null) {
  const rows = await db.select().from(tracks)
    .where(and(eq(tracks.published, true), ne(tracks.videoUrl, "")))
    .orderBy(desc(tracks.plays), desc(tracks.createdAt))
    .limit(60);
  const allArtists = await db.select().from(artists);
  const aMap = new Map(allArtists.map(a => [a.id, a]));
  const likes = await db.select().from(clipLikes);
  const reposts = await db.select().from(clipReposts);
  const comments = await db.select({ trackId: clipComments.trackId, n: sql<number>`count(*)::int` }).from(clipComments).groupBy(clipComments.trackId);
  const cMap = new Map(comments.map(c => [c.trackId, Number(c.n)]));
  return rows.map(t => ({
    id: t.id,
    title: t.title,
    videoUrl: t.videoUrl,
    thumbnail: (t as any).videoThumbnailUrl || t.coverUrl || "",
    coverUrl: t.coverUrl || "",
    genre: t.genre || "",
    plays: t.plays || 0,
    artist: aMap.get(t.artistId) ? { id: t.artistId, name: aMap.get(t.artistId)!.name, imageUrl: aMap.get(t.artistId)!.imageUrl || "", genre: aMap.get(t.artistId)!.genre || "" } : null,
    likeCount: likes.filter(l => l.trackId === t.id).length,
    repostCount: reposts.filter(r => r.trackId === t.id).length,
    commentCount: cMap.get(t.id) || 0,
    liked: meId ? likes.some(l => l.trackId === t.id && l.userId === meId) : false,
    reposted: meId ? reposts.some(r => r.trackId === t.id && r.userId === meId) : false,
  }));
}

export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const trackId = Number(url.searchParams.get("trackId") || 0);
  const me = await getCurrentUser();
  if (trackId) {
    const rows = await db.select().from(clipComments).where(eq(clipComments.trackId, trackId)).orderBy(desc(clipComments.createdAt)).limit(100);
    const us = await db.select().from(users);
    const um = new Map(us.map(u => [u.id, u]));
    return NextResponse.json({
      comments: rows.map(c => ({
        id: c.id, body: c.body, createdAt: c.createdAt,
        user: um.get(c.userId) ? { id: c.userId, displayName: um.get(c.userId)!.displayName, username: um.get(c.userId)!.username, avatarUrl: um.get(c.userId)!.avatarUrl || "" } : null,
      })),
    });
  }
  return NextResponse.json({ clips: await clipsPayload(me?.id || null) });
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Faça login para curtir, comentar e repostar." }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const trackId = Number(b.trackId);
  if (!trackId) return NextResponse.json({ error: "Clipe inválido." }, { status: 400 });
  const [track] = await db.select().from(tracks).where(eq(tracks.id, trackId)).limit(1);
  if (!track || !track.published || !(track as any).videoUrl) return NextResponse.json({ error: "Clipe não encontrado." }, { status: 404 });
  const [artist] = await db.select().from(artists).where(eq(artists.id, track.artistId)).limit(1);
  const notifyArtist = async (title: string, body: string) => {
    if (artist?.userId && artist.userId !== me.id) {
      await db.insert(notifications).values({ userId: artist.userId, title, body });
    }
  };
  try {
    if (b.action === "like") {
      const [ex] = await db.select().from(clipLikes).where(and(eq(clipLikes.userId, me.id), eq(clipLikes.trackId, trackId))).limit(1);
      if (ex) await db.delete(clipLikes).where(eq(clipLikes.id, ex.id));
      else { await db.insert(clipLikes).values({ userId: me.id, trackId }); await notifyArtist("Seu clipe foi curtido", `${me.displayName} curtiu "${track.title}".`); }
    } else if (b.action === "repost") {
      const [ex] = await db.select().from(clipReposts).where(and(eq(clipReposts.userId, me.id), eq(clipReposts.trackId, trackId))).limit(1);
      if (ex) await db.delete(clipReposts).where(eq(clipReposts.id, ex.id));
      else { await db.insert(clipReposts).values({ userId: me.id, trackId }); await notifyArtist("Seu clipe foi repostado", `${me.displayName} repostou "${track.title}" para os seguidores.`); }
    } else if (b.action === "comment") {
      const body = String(b.body || "").trim();
      if (body.length < 1) return NextResponse.json({ error: "Escreva um comentário." }, { status: 400 });
      if (body.length > 500) return NextResponse.json({ error: "Comentário muito longo (máx. 500 caracteres)." }, { status: 400 });
      await db.insert(clipComments).values({ userId: me.id, trackId, body });
      await notifyArtist("Novo comentário no seu clipe", `${me.displayName}: "${body.slice(0, 90)}"`);
    } else if (b.action === "delete-comment") {
      const [c] = await db.select().from(clipComments).where(eq(clipComments.id, Number(b.commentId))).limit(1);
      if (!c) return NextResponse.json({ error: "Comentário não encontrado." }, { status: 404 });
      if (c.userId !== me.id && me.role !== "admin") return NextResponse.json({ error: "Você só pode excluir seus comentários." }, { status: 403 });
      await db.delete(clipComments).where(eq(clipComments.id, c.id));
    } else {
      return NextResponse.json({ error: "Ação inválida." }, { status: 400 });
    }
    return NextResponse.json({ ok: true, clips: await clipsPayload(me.id) });
  } catch (e) {
    console.error("clips", e);
    return NextResponse.json({ error: "Erro ao salvar. Tente novamente." }, { status: 500 });
  }
}
