import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ensureSeed } from "@/lib/catalog";
export async function GET(){ await ensureSeed(); const all=await db.select().from(users); return NextResponse.json({users: all.map(u=>({id:u.id, username:u.username, displayName:u.displayName, bio:u.bio, avatarUrl:u.avatarUrl, createdAt:u.createdAt}))}); }
