import { Suspense } from "react";
import { SearchPage } from "@/components/pages";
export default function Page(){ return <Suspense fallback={<div className="p-8 text-neutral-500">Carregando...</div>}><SearchPage/></Suspense>; }
