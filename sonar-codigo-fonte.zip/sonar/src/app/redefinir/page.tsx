import { Suspense } from "react";
import { ResetPasswordPage } from "@/components/pages";
export default function Page(){ return <Suspense fallback={<div className="min-h-dvh bg-black text-white grid place-items-center text-sm text-neutral-500">Carregando...</div>}><ResetPasswordPage/></Suspense>; }
