"use client";
import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import QRCode from "qrcode";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Shuffle, Repeat, Repeat1, Heart, Search, Home, Library, Plus, X, MoreHorizontal, Share2, ListMusic, User, Settings, LogOut, Disc3, Music2, Mic2, Clock, Trash2, Edit3, Check, ChevronLeft, Bell, Shield, BarChart3, Users, Disc, Flag, Eye, Sparkles, Info, LifeBuoy, TrendingUp, Upload, Clapperboard } from "lucide-react";

/* ---------- types & ctx ---------- */
export type Track={id:number,title:string,artistId:number,albumId:number|null,featuring?:string,coverUrl:string,audioUrl:string,duration:number,releaseDate?:string,genre:string,credits:string,lyrics:string,lyricsSource?:string,videoUrl?:string,videoThumbnailUrl?:string,plays:number,featured:boolean,artist?:any,album?:any};
type CtxType={user:any,setUser:(u:any)=>void,library:any,refreshLibrary:()=>void,catalog:any,refreshCatalog:()=>void,play:(t:Track,queue?:Track[])=>void,current:Track|null,playing:boolean,toggle:()=>void,next:()=>void,prev:()=>void,queue:Track[],isFav:(id:number)=>boolean,toggleFav:(id:number)=>void,toast:string,theme:string,setTheme:(t:string)=>void};
const Ctx=createContext<CtxType>(null as any);
export const useApp=()=>useContext(Ctx);
const fmt=(s:number)=>{ if(!isFinite(s)||s<0)s=0; const m=Math.floor(s/60), sec=Math.floor(s%60); return `${m}:${String(sec).padStart(2,"0")}`; };

export function SonarBrandMark({size=28}:{size?:number}){
  const {catalog}=useApp() as any;
  const logoUrl=catalog?.settings?.logoUrl||"";
  if(logoUrl){
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={logoUrl} alt="" style={{height:size,width:"auto",maxWidth:size*3}} className="object-contain"/>;
  }
  return <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
    <rect x="1" y="1" width="30" height="30" rx="9" stroke="#fff" strokeWidth="1.6"/>
    <path d="M8 19c3 0 3-6 6-6s3 8 6 8 3-10 6-10" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"/>
  </svg>;
}

export function SonarLogo({size=28}:{size?:number}){
  const {catalog}=useApp() as any;
  const rawName=(catalog?.settings?.siteName||"Sonar").trim();
  const site=rawName.toLowerCase()==="sonar" ? "Sonar" : rawName;
  const logoUrl=catalog?.settings?.logoUrl||"";
  if(logoUrl){
    return <Link href="/" className="inline-flex items-center shrink-0" aria-label={`${site} — início`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={logoUrl} alt="" style={{height:size,width:"auto",maxWidth:size*3}} className="object-contain"/>
    </Link>;
  }
  return <Link href="/" className="inline-flex items-center gap-2.5 shrink-0" aria-label={`${site} — início`}>
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <rect x="1" y="1" width="30" height="30" rx="9" stroke="#fff" strokeWidth="1.6"/>
      <path d="M8 19c3 0 3-6 6-6s3 8 6 8 3-10 6-10" stroke="#fff" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
    <span className="text-[19px] font-extrabold tracking-tight text-white">{site}</span>
  </Link>;
}

export function AppProvider({children}:{children:React.ReactNode}){
  const [user,setUser]=useState<any>(undefined);
  const [library,setLibrary]=useState<any>(null);
  const [catalog,setCatalog]=useState<any>(null);
  const [current,setCurrent]=useState<Track|null>(null);
  const [queue,setQueue]=useState<Track[]>([]);
  const [playing,setPlaying]=useState(false);
  const [toast,setToast]=useState("");
  const [theme,setThemeState]=useState("original");
  useEffect(()=>{ try{ const t=localStorage.getItem("sonar_theme")||"original"; setThemeState(t); document.documentElement.dataset.theme=t; }catch{} },[]);
  const setTheme=(t:string)=>{ setThemeState(t); try{ localStorage.setItem("sonar_theme",t); }catch{} document.documentElement.dataset.theme=t; if(user) fetch("/api/prefs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({theme:t})}).catch(()=>{}); };
  const audioRef=useRef<HTMLAudioElement|null>(null);
  const stateRef=useRef({queue,current,playing}); stateRef.current={queue,current,playing};

  const showToast=(m:string)=>{ setToast(m); setTimeout(()=>setToast(""),2600); };
  const refreshCatalog=useCallback(async()=>{ const r=await fetch("/api/catalog"); if(r.ok) setCatalog(await r.json()); },[]);
  const refreshLibrary=useCallback(async()=>{ const r=await fetch("/api/actions"); if(r.ok) setLibrary(await r.json()); else setLibrary(null); },[]);
  useEffect(()=>{ (async()=>{ const r=await fetch("/api/auth"); const d=await r.json(); let u=d.user||null;
    if(!u){ try{ const t=localStorage.getItem("sonar_token"); if(t){ const rr=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"restore",token:t})}); const dd=await rr.json(); if(rr.ok&&dd.user) u=dd.user; else localStorage.removeItem("sonar_token"); } }catch{} }
    setUser(u); refreshCatalog(); })(); },[refreshCatalog]);
  useEffect(()=>{ if(user) refreshLibrary(); else setLibrary(null); },[user,refreshLibrary]);
  useEffect(()=>{ if(user){ (async()=>{ try{ const r=await fetch("/api/prefs"); const d=await r.json(); const t=d.prefs?.theme; if(t&&t!=="original"){ setThemeState(t); try{ localStorage.setItem("sonar_theme",t); }catch{} document.documentElement.dataset.theme=t; } }catch{} })(); } },[user]);

  // audio element
  useEffect(()=>{ const a=new Audio(); a.preload="metadata"; audioRef.current=a;
    a.addEventListener("ended",()=>{ const {queue:q,current:c}=stateRef.current; /* handled by nextRef */ nextRef.current(); });
    return ()=>{ a.pause(); };
  },[]);
  const playTrack=useCallback((t:Track,q?:Track[])=>{
    const a=audioRef.current; if(!a) return;
    const list=q&&q.length?q:[t]; setQueue(list); setCurrent(t);
    if(a.src!==t.audioUrl){ a.src=t.audioUrl; }
    a.currentTime=0; a.play().then(()=>setPlaying(true)).catch(()=>{ setPlaying(false); showToast("Não foi possível reproduzir esta fonte de áudio."); });
    if(user) fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"play",trackId:t.id})}).then(()=>refreshLibrary());
    if("mediaSession" in navigator){ try{ navigator.mediaSession.metadata=new MediaMetadata({title:t.title, artist:t.artist?.name||"", album:t.album?.title||"", artwork:t.coverUrl?[{src:t.coverUrl,sizes:"512x512"}]:[]}); }catch{} }
  },[user,refreshLibrary]);

  const nextRef=useRef(()=>{});
  const doNext=useCallback((auto=false)=>{
    const {queue:q,current:c}=stateRef.current; if(!q.length||!c) return;
    // repeat/shuffle handled via window vars
    const rep=(window as any).__noirRepeat||"off"; const shuf=(window as any).__noirShuffle;
    if(auto&&rep==="one"){ const a=audioRef.current; if(a){a.currentTime=0; a.play();} return; }
    let idx=q.findIndex(t=>t.id===c.id);
    let nIdx= shuf? Math.floor(Math.random()*q.length) : idx+1;
    if(nIdx>=q.length){ if(rep==="all"||!auto) nIdx=0; else { setPlaying(false); return; } }
    playTrack(q[nIdx], q);
  },[playTrack]);
  nextRef.current=()=>doNext(true);

  const toggle=()=>{ const a=audioRef.current; if(!a||!current) return; if(playing){a.pause(); setPlaying(false);} else a.play().then(()=>setPlaying(true)); };
  const prev=()=>{ const {queue:q,current:c}=stateRef.current; if(!q.length||!c) return; const idx=q.findIndex(t=>t.id===c.id); playTrack(q[(idx-1+q.length)%q.length], q); };

  const isFav=(id:number)=> !!library?.favoriteIds?.includes(id);
  const toggleFav=async(id:number)=>{ if(!user){ showToast("Faça login para favoritar."); return; } const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"toggle-favorite",trackId:id})}); const d=await r.json(); if(d.library) setLibrary(d.library); };

  const setUserPersist=(u:any)=>{ setUser(u); if(!u){ try{ localStorage.removeItem("sonar_token"); }catch{} } };
  const ctx:CtxType={user,setUser:setUserPersist,library,refreshLibrary,catalog,refreshCatalog,play:playTrack,current,playing,toggle,next:()=>doNext(false),prev,queue,isFav,toggleFav,toast,theme,setTheme};
  (ctx as any).audioRef=audioRef; (ctx as any).showToast=showToast; (ctx as any).setPlaying=setPlaying;
  return <Ctx.Provider value={ctx}>{children}<PlayerBar/>{toast&&<div className="fixed bottom-28 md:bottom-24 left-1/2 -translate-x-1/2 z-[80] bg-white text-black text-sm font-semibold px-4 py-2.5 rounded-full shadow-2xl">{toast}</div>}</Ctx.Provider>;
}

/* ---------- Player ---------- */
function PlayerBar(){
  const pathname=usePathname();
  const app=useApp() as any; const {current,playing,toggle,next,prev,isFav,toggleFav,queue}=app; const audioRef=app.audioRef;
  const [time,setTime]=useState(0); const [dur,setDur]=useState(0); const [vol,setVol]=useState(0.8); const [shuffle,setShuffle]=useState(false); const [repeat,setRepeat]=useState<"off"|"all"|"one">("off"); const [expanded,setExpanded]=useState(false); const [showQueue,setShowQueue]=useState(false);
  useEffect(()=>{ (window as any).__noirShuffle=shuffle; },[shuffle]); useEffect(()=>{ (window as any).__noirRepeat=repeat; },[repeat]);
  useEffect(()=>{ const a=audioRef.current; if(!a) return; const u=()=>{setTime(a.currentTime); setDur(a.duration||current?.duration||0);}; const i=setInterval(u,400); return ()=>clearInterval(i); },[current,audioRef]);
  if(!current||pathname?.startsWith("/clipes")) return null;
  const share=async()=>{ const url=location.origin+"/track/"+current.id; if(navigator.share) await navigator.share({title:current.title,url}).catch(()=>{}); else { app.showToast("Compartilhamento direto não suportado neste aparelho."); } };
  return <>
  <div className="fixed left-0 right-0 bottom-14 md:bottom-0 z-50 bg-black/95 backdrop-blur border-t border-white/10 px-3 md:px-4 py-2.5">
    <div className="max-w-[1600px] mx-auto flex items-center gap-3">
      <button onClick={()=>setExpanded(true)} className="flex items-center gap-3 min-w-0 flex-1 md:flex-none md:w-72 text-left">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={current.coverUrl||"/icon.svg"} alt="" className="w-11 h-11 rounded object-cover bg-neutral-800"/>
        <span className="min-w-0"><span className="block text-sm font-semibold truncate">{current.title}</span><span className="block text-xs text-neutral-400 truncate">{current.artist?.name}</span></span>
      </button>
      <button onClick={()=>toggleFav(current.id)} className="hidden sm:block text-neutral-300 hover:text-white"><Heart size={19} fill={isFav(current.id)?"#fff":"none"}/></button>
      <div className="flex flex-col items-center flex-1 max-w-xl mx-auto">
        <div className="flex items-center gap-3">
          <button onClick={()=>setShuffle(!shuffle)} className={shuffle?"text-white":"text-neutral-500"}><Shuffle size={16}/></button>
          <button onClick={prev} className="text-neutral-300 hover:text-white"><SkipBack size={19} fill="currentColor"/></button>
          <button onClick={toggle} className="w-9 h-9 rounded-full bg-white text-black grid place-items-center hover:scale-105 transition">{playing?<Pause size={17} fill="currentColor"/>:<Play size={17} fill="currentColor" className="ml-0.5"/>}</button>
          <button onClick={next} className="text-neutral-300 hover:text-white"><SkipForward size={19} fill="currentColor"/></button>
          <button onClick={()=>setRepeat(repeat==="off"?"all":repeat==="all"?"one":"off")} className={repeat!=="off"?"text-white":"text-neutral-500"}>{repeat==="one"?<Repeat1 size={16}/>:<Repeat size={16}/>}</button>
        </div>
        <div className="hidden md:flex items-center gap-2 w-full mt-1 text-[11px] text-neutral-400"><span>{fmt(time)}</span><input type="range" min={0} max={dur||0} step={0.1} value={time} onChange={e=>{ if(audioRef.current) audioRef.current.currentTime=+e.target.value; }} className="flex-1 accent-white h-1"/><span>{fmt(dur||current.duration)}</span></div>
      </div>
      <div className="hidden lg:flex items-center gap-2 w-48 justify-end">
        <button onClick={()=>setShowQueue(!showQueue)} className="text-neutral-300 hover:text-white"><ListMusic size={18}/></button>
        <button onClick={share} className="text-neutral-300 hover:text-white"><Share2 size={17}/></button>
        <Volume2 size={17} className="text-neutral-400"/><input type="range" min={0} max={1} step={0.01} value={vol} onChange={e=>{setVol(+e.target.value); if(audioRef.current) audioRef.current.volume=+e.target.value;}} className="w-20 accent-white"/>
      </div>
    </div>
    <div className="md:hidden mt-1.5 h-1 bg-white/10 rounded"><div className="h-full bg-white rounded" style={{width:`${dur?time/dur*100:0}%`}}/></div>
  </div>
  {showQueue&&<div className="fixed right-3 bottom-32 md:bottom-20 z-[60] w-80 max-w-[92vw] bg-neutral-900 border border-white/10 rounded-2xl p-3 shadow-2xl"><div className="flex justify-between items-center mb-2"><b className="text-sm">Fila de reprodução</b><button onClick={()=>setShowQueue(false)}><X size={16}/></button></div><div className="max-h-72 overflow-auto space-y-1">{queue.map((t:Track)=> <button key={t.id} onClick={()=>app.play(t,queue)} className={`w-full text-left px-2 py-2 rounded-lg text-sm flex gap-2 ${t.id===current.id?"bg-white text-black font-semibold":"hover:bg-white/5"}`}><span className="truncate">{t.title} — {t.artist?.name}</span></button>)}</div></div>}
  {expanded&&<div className="fixed inset-0 z-[70] bg-black overflow-auto">
    <div className="max-w-2xl mx-auto px-5 py-6 pb-32">
      <button onClick={()=>setExpanded(false)} className="text-neutral-400 mb-6 flex items-center gap-1 text-sm"><ChevronLeft size={18}/> Voltar</button>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={current.coverUrl} alt="" className="w-full aspect-square object-cover rounded-2xl"/>
      <div className="flex items-start justify-between mt-6"><div><h1 className="text-3xl font-bold">{current.title}</h1><Link href={`/artist/${current.artistId}`} onClick={()=>setExpanded(false)} className="text-neutral-400 hover:text-white">{current.artist?.name}</Link>{current.album&&<p className="text-sm text-neutral-500 mt-1">{current.album.title} • {current.genre}</p>}</div><button onClick={()=>toggleFav(current.id)}><Heart size={26} fill={isFav(current.id)?"#fff":"none"}/></button></div>
      <div className="flex items-center gap-2 mt-6 text-xs text-neutral-400"><span>{fmt(time)}</span><input type="range" min={0} max={dur||0} step={0.1} value={time} onChange={e=>{ if(audioRef.current) audioRef.current.currentTime=+e.target.value; }} className="flex-1 accent-white"/><span>{fmt(dur||current.duration)}</span></div>
      <div className="flex items-center justify-center gap-6 mt-4">
        <button onClick={()=>setShuffle(!shuffle)} className={shuffle?"":"text-neutral-500"}><Shuffle/></button><button onClick={prev}><SkipBack size={28} fill="currentColor"/></button>
        <button onClick={toggle} className="w-16 h-16 rounded-full bg-white text-black grid place-items-center">{playing?<Pause size={28} fill="currentColor"/>:<Play size={28} fill="currentColor" className="ml-1"/>}</button>
        <button onClick={next}><SkipForward size={28} fill="currentColor"/></button><button onClick={()=>setRepeat(repeat==="off"?"all":repeat==="all"?"one":"off")} className={repeat!=="off"?"":"text-neutral-500"}>{repeat==="one"?<Repeat1/>:<Repeat/>}</button>
      </div>
      <div className="flex items-center gap-2 mt-6"><Volume2 size={18} className="text-neutral-400"/><input type="range" min={0} max={1} step={0.01} value={vol} onChange={e=>{setVol(+e.target.value); if(audioRef.current) audioRef.current.volume=+e.target.value;}} className="flex-1 accent-white"/></div>
      {current.lyrics&&<div className="mt-8 bg-neutral-900 border border-white/10 rounded-2xl p-5"><h3 className="font-bold mb-3">Letra</h3><p className="whitespace-pre-line text-neutral-300 leading-relaxed text-[15px]">{current.lyrics}</p></div>}
      {current.credits&&<p className="mt-5 text-sm text-neutral-500">{current.credits}</p>}
      <button onClick={share} className="mt-5 w-full py-3 rounded-full border border-white/20 font-semibold flex items-center justify-center gap-2"><Share2 size={17}/> Compartilhar</button>
    </div></div>}
  </>;
}


export function CookieBanner(){
  const {user}=useApp() as any; const [show,setShow]=useState(false); const [custom,setCustom]=useState(false); const [analytics,setAnalytics]=useState(false); const [personal,setPersonal]=useState(true);
  useEffect(()=>{ try{ if(!localStorage.getItem("sonar_cookies")) setShow(true); }catch{} const open=()=>setShow(true); window.addEventListener("sonar:cookies",open); return ()=>window.removeEventListener("sonar:cookies",open); },[]);
  if(!show) return null;
  const save=(c:any)=>{ try{ localStorage.setItem("sonar_cookies", JSON.stringify(c)); }catch{} if(user) fetch("/api/prefs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({cookieConsent:c})}).catch(()=>{}); setShow(false); };
  return <div className="fixed left-3 right-3 md:left-auto md:right-5 bottom-32 md:bottom-24 z-[75] md:w-[380px] bg-neutral-900 border border-white/15 rounded-2xl p-5 shadow-2xl">
    <p className="font-bold text-sm">Sua privacidade</p>
    <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed">Usamos cookies essenciais para login e reprodução. Com sua permissão, também guardamos suas preferências (tema, gêneros) para personalizar o app. Nada de rastreamento externo sem você aceitar.</p>
    {custom&&<div className="mt-3 space-y-2 text-sm"><label className="flex items-center justify-between gap-3 border border-white/10 rounded-xl px-3 py-2.5">Essenciais (login e player)<span className="text-xs text-neutral-500 font-bold">SEMPRE ATIVO</span></label><label className="flex items-center justify-between gap-3 border border-white/10 rounded-xl px-3 py-2.5">Personalização (tema e gostos)<input type="checkbox" checked={personal} onChange={e=>setPersonal(e.target.checked)} className="accent-white"/></label><label className="flex items-center justify-between gap-3 border border-white/10 rounded-xl px-3 py-2.5">Análise de uso<input type="checkbox" checked={analytics} onChange={e=>setAnalytics(e.target.checked)} className="accent-white"/></label></div>}
    <div className="flex gap-2 mt-4">{custom
      ? <><button onClick={()=>save({essential:true, personalization:personal, analytics})} className="flex-1 bg-white text-black font-bold py-2.5 rounded-full text-sm">Salvar escolhas</button><button onClick={()=>setCustom(false)} className="px-4 py-2.5 rounded-full border border-white/25 text-sm font-bold">Voltar</button></>
      : <><button onClick={()=>save({essential:true, personalization:true, analytics:true})} className="bg-white text-black font-bold px-4 py-2.5 rounded-full text-sm">Aceitar todos</button><button onClick={()=>save({essential:true, personalization:false, analytics:false})} className="px-4 py-2.5 rounded-full border border-white/25 text-sm font-bold">Rejeitar</button><button onClick={()=>setCustom(true)} className="px-3 py-2.5 text-sm font-bold text-neutral-300">Personalizar</button></>}
    </div>
  </div>;
}

/* ---------- Shell ---------- */
export function Shell({children}:{children:React.ReactNode}){
  const {user,catalog}=useApp() as any; const pathname=usePathname(); const router=useRouter(); const [q,setQ]=useState("");
  const site=catalog?.settings?.siteName||"SONAR";
  const nav=[{href:"/",label:"Início",icon:Home},{href:"/search",label:"Buscar",icon:Search},{href:"/charts",label:"Charts",icon:TrendingUp},{href:"/library",label:"Biblioteca",icon:Library},{href:"/profile",label:"Perfil",icon:User}];
  const isAdminPage=pathname?.startsWith("/admin");
  if(pathname?.startsWith("/login")||pathname?.startsWith("/register")||pathname?.startsWith("/seja-artista")||pathname?.startsWith("/redefinir")||pathname?.startsWith("/recuperar-conta")) return <>{children}</>;
  if(pathname?.startsWith("/clipes")) return <>{children}</>;
  if(pathname==="/"&&user===null) return <>{children}</>;
  return <div className="min-h-screen bg-[#0a0a0a] text-white">
    <aside className="hidden md:flex fixed left-0 top-0 bottom-0 w-60 flex-col bg-black border-r border-white/10 p-4 z-40 pb-24">
      <div className="px-2 py-2"><SonarLogo/></div>
      <p className="px-2 text-[11px] text-neutral-500 -mt-1 mb-5">{catalog?.settings?.tagline||"A nova era da música social"}</p>
      <nav className="space-y-1">{nav.map(n=> <Link key={n.href} href={n.href} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname===n.href?"bg-white text-black":"text-neutral-300 hover:bg-white/5 hover:text-white"}`}><n.icon size={19}/>{n.label}</Link>)}
      <Link href="/history" className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname==="/history"?"bg-white text-black":"text-neutral-300 hover:bg-white/5"}`}><Clock size={19}/>Histórico</Link>
      <Link href="/clipes" className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname==="/clipes"?"bg-white text-black":"text-neutral-300 hover:bg-white/5"}`}><Clapperboard size={19}/>Clipes</Link>
      <Link href="/area-artista" className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname==="/area-artista"?"bg-white text-black":"text-neutral-300 hover:bg-white/5"}`}><Mic2 size={19}/>Estúdio do Artista</Link>
      <Link href="/charts" className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname==="/charts"?"bg-white text-black":"text-neutral-300 hover:bg-white/5"}`}><TrendingUp size={19}/>Charts</Link>
      <Link href="/sobre" className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname==="/sobre"?"bg-white text-black":"text-neutral-300 hover:bg-white/5"}`}><Info size={19}/>Sobre o aplicativo</Link>
      <Link href="/suporte" className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${pathname==="/suporte"?"bg-white text-black":"text-neutral-300 hover:bg-white/5"}`}><LifeBuoy size={19}/>Suporte</Link>
      {user?.role==="admin"&&<Link href="/admin" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-300 hover:bg-white/5"><Shield size={19}/>Painel admin</Link>}
      {user?.role==="admin"&&<Link href="/area-artista" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-neutral-300 hover:bg-white/5"><Mic2 size={19}/>Estúdio (admin artista)</Link>}
      </nav>
      <div className="mt-6 px-2 flex items-center justify-between"><span className="text-xs font-bold tracking-widest text-neutral-500">SUA BIBLIOTECA</span><Link href="/library?new=1" className="text-neutral-400 hover:text-white"><Plus size={18}/></Link></div>
      <div className="mt-2 space-y-1 overflow-auto">
        {(useApp().library?.playlists||[]).slice(0,8).map((p:any)=><Link key={p.id} href={`/playlist/${p.id}`} className="block px-3 py-2 rounded-lg text-sm text-neutral-300 hover:bg-white/5 truncate">{p.name}</Link>)}
        {!user&&<p className="px-3 py-2 text-xs text-neutral-500 leading-relaxed">Entre para criar playlists, favoritar e seguir artistas.</p>}
      </div>
      <div className="mt-auto border-t border-white/10 pt-4">
        {user? <Link href="/profile" className="flex items-center gap-3 px-2"><span className="w-9 h-9 rounded-full bg-white text-black grid place-items-center font-bold overflow-hidden">{user.avatarUrl?<img src={user.avatarUrl} alt="" className="w-full h-full object-cover"/>:user.displayName?.[0]}</span><span className="min-w-0"><span className="block text-sm font-semibold truncate">{user.displayName}</span><span className="block text-xs text-neutral-500">@{user.username}</span></span></Link>
        : <Link href="/login" className="block text-center bg-white text-black font-bold py-2.5 rounded-full text-sm">Entrar</Link>}
      </div>
    </aside>
    <div className="md:pl-60">
      <header className="sticky top-0 z-30 bg-[#0a0a0a]/90 backdrop-blur border-b border-white/10 px-4 md:px-8 py-3 flex items-center gap-3">
        <div className="md:hidden"><SonarLogo size={28}/></div>
        <form className="hidden sm:flex flex-1 max-w-xl mx-auto" onSubmit={e=>{e.preventDefault(); router.push("/search?q="+encodeURIComponent(q));}}>
          <div className="relative w-full"><Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500"/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Buscar músicas, artistas, álbuns, playlists..." className="w-full bg-neutral-900 border border-white/10 rounded-full pl-10 pr-4 py-2.5 text-sm outline-none focus:border-white/40 placeholder:text-neutral-500"/></div>
        </form>
        <div className="ml-auto flex items-center gap-2">
          {user&&<NotifBell/>}
          {user? <>{user.role==="admin"&&<Link href="/admin" title="Painel Admin" className="p-2 text-white"><Shield size={19}/></Link>}<Link href="/area-artista" title="Estúdio do Artista" className="p-2 text-neutral-300 hover:text-white"><Mic2 size={19}/></Link><Link href="/settings" title="Configurações" className="p-2 text-neutral-300 hover:text-white"><Settings size={19}/></Link></> : <><Link href="/seja-artista" className="hidden sm:block text-sm font-semibold text-neutral-300 hover:text-white px-2">Sou artista</Link><Link href="/login" className="text-sm font-semibold text-neutral-300 hover:text-white px-2">Entrar</Link><Link href="/register" className="bg-white text-black text-sm font-bold px-4 py-2 rounded-full">Criar conta</Link></>}
        </div>
      </header>
      <main className="pb-40 md:pb-28">{children}</main>
      <footer className="border-t border-white/10 px-4 md:px-8 py-8 pb-44 md:pb-32 text-xs text-neutral-500 flex flex-wrap gap-4"><span>© {new Date().getFullYear()} {site} — Plataforma musical independente.</span><Link href="/terms" className="hover:text-white">Termos de uso</Link><Link href="/privacy" className="hover:text-white">Privacidade</Link><Link href="/sobre" className="hover:text-white">Sobre o aplicativo</Link><Link href="/suporte" className="hover:text-white">Suporte</Link><button onClick={()=>window.dispatchEvent(new Event("sonar:cookies"))} className="hover:text-white">Cookies e privacidade</button><span>Áudio demonstrativo autorizado: SoundHelix.</span></footer>
    </div>
    <CookieBanner/>
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-black border-t border-white/10 grid grid-cols-6 pb-[env(safe-area-inset-bottom)]">
      {[...nav.slice(0,2),{href:"/clipes",label:"Clipes",icon:Clapperboard},nav[3],{href:"/area-artista",label:"Estúdio",icon:Mic2},nav[4]].map(n=> <Link key={n.href} href={n.href} className={`flex min-w-0 flex-col items-center gap-0.5 py-2 text-[9px] font-medium ${pathname===n.href?"text-white":"text-neutral-500"}`}><n.icon size={20}/><span className="max-w-full truncate px-0.5">{n.label}</span></Link>)}
    </nav>
  </div>;
}
function NotifBell(){ const {library}=useApp() as any; const [open,setOpen]=useState(false); const items=library?.notifications||[]; const unread=items.filter((n:any)=>!n.read).length;
  const mark=async()=>{ await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"mark-notifications"})}); };
  return <div className="relative"><button onClick={()=>{setOpen(!open); if(!open) mark();}} className="p-2 text-neutral-300 relative"><Bell size={19}/>{unread>0&&<span className="absolute top-1 right-1 w-4 h-4 bg-white text-black text-[9px] font-bold rounded-full grid place-items-center">{unread}</span>}</button>
  {open&&<div className="absolute right-0 top-11 w-80 max-w-[90vw] bg-neutral-900 border border-white/10 rounded-2xl p-2 shadow-2xl z-50">{items.length?items.slice(0,8).map((n:any)=><div key={n.id} className="px-3 py-2.5 border-b border-white/5 last:border-0"><p className="text-sm font-semibold">{n.title}</p><p className="text-xs text-neutral-400">{n.body}</p></div>):<p className="text-sm text-neutral-400 px-3 py-3">Sem notificações.</p>}</div>}</div>;
}

/* ---------- Cards / rows ---------- */
export function TrackRow({track,queue,index}:{track:Track,queue:Track[],index?:number}){
  const app=useApp() as any; const {play,current,playing,toggle,isFav,toggleFav,user,library}=app; const [menu,setMenu]=useState(false); const [art,setArt]=useState<{format:PromoFormat,action:"share"|"download"}|null>(null); const router=useRouter();
  const isCurrent=current?.id===track.id;
  const act=async(action:string,extra:any={})=>{ if(!user){ router.push("/login"); return; } const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,...extra})}); const d=await r.json(); if(!r.ok) app.showToast(d.error||"Erro"); else { app.showToast("Feito."); if(d.library) app.refreshLibrary(); } setMenu(false); };
  const share=async()=>{ const url=location.origin+"/track/"+track.id; if(navigator.share) await navigator.share({title:track.title,text:`${track.title} — ${track.artist?.name||""}`,url}).catch(()=>{}); else app.showToast("Compartilhamento direto não suportado aqui — use as artes abaixo."); setMenu(false); };
  return <div className={`group flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-white/5 ${isCurrent?"bg-white/5":""}`}>
    <span className="w-5 text-center text-xs text-neutral-500">{index!==undefined?index+1:""}</span>
    <button onClick={()=> isCurrent?toggle():play(track,queue)} className="relative shrink-0">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={track.coverUrl||"/icon.svg"} alt="" className="w-11 h-11 rounded object-cover bg-neutral-800"/>
      <span className={`absolute inset-0 grid place-items-center bg-black/50 rounded ${isCurrent?"opacity-100":"opacity-0 group-hover:opacity-100"}`}>{isCurrent&&playing?<Pause size={16} fill="#fff"/>:<Play size={16} fill="#fff"/>}</span>
    </button>
    <div className="flex-1 min-w-0"><Link href={`/track/${track.id}`} className={`block text-sm font-semibold truncate ${isCurrent?"text-white underline underline-offset-4":""}`}>{track.title}</Link><Link href={`/artist/${track.artistId}`} className="block text-xs text-neutral-400 truncate hover:text-white">{track.artist?.name}</Link></div>
    <span className="hidden md:block text-xs text-neutral-500 w-24 truncate">{track.album?.title}</span>
    <span className="hidden sm:block text-xs text-neutral-500">{(track.plays/1000).toFixed(0)}k</span>
    <button onClick={()=>toggleFav(track.id)} className={isFav(track.id)?"text-white":"text-neutral-500 hover:text-white"}><Heart size={17} fill={isFav(track.id)?"#fff":"none"}/></button>
    <span className="text-xs text-neutral-500 w-9 text-right">{fmt(track.duration)}</span>
    <div className="relative"><button onClick={()=>setMenu(!menu)} className="text-neutral-400 hover:text-white p-1"><MoreHorizontal size={18}/></button>
    {menu&&<div className="absolute right-0 top-8 z-40 w-72 bg-neutral-900 border border-white/10 rounded-xl p-1.5 shadow-2xl text-sm">
      <button onClick={share} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 flex gap-2"><Share2 size={15}/> Compartilhar</button>
      <button onClick={()=>{setArt({format:"stories",action:"share"}); setMenu(false);}} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5">Compartilhar nos Stories (9:16)</button>
      <button onClick={()=>{setArt({format:"feed",action:"share"}); setMenu(false);}} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5">Compartilhar no Feed (4:5)</button>
      <button onClick={()=>{setArt({format:"stories",action:"download"}); setMenu(false);}} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5">Baixar arte para Stories</button>
      <button onClick={()=>{setArt({format:"feed",action:"download"}); setMenu(false);}} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5">Baixar arte para Feed</button>
      <Link href={`/artist/${track.artistId}`} className="block px-3 py-2 rounded-lg hover:bg-white/5">Ir para o artista</Link>
      {track.albumId&&<Link href={`/album/${track.albumId}`} className="block px-3 py-2 rounded-lg hover:bg-white/5">Ir para o álbum</Link>}
      <div className="border-t border-white/10 mt-1 pt-1 px-3 py-1 text-[11px] tracking-widest text-neutral-500">ADICIONAR À PLAYLIST</div>
      {(library?.playlists||[]).length? library.playlists.map((p:any)=><button key={p.id} onClick={()=>act("add-to-playlist",{playlistId:p.id,trackId:track.id})} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 truncate">{p.name}</button>) : <p className="px-3 py-2 text-xs text-neutral-500">{user?"Você ainda não tem playlists.":"Faça login para usar playlists."}</p>}
      <button onClick={()=>{ const reason=prompt("Motivo da denúncia:"); if(reason) act("report",{targetType:"track",targetId:track.id,reason}); }} className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 flex gap-2 text-neutral-300"><Flag size={15}/> Denunciar</button>
    </div>}</div>
    {art&&<ShareCardModal kindLabel={("MÚSICA NA "+(app.catalog?.settings?.siteName||"SONAR")).toUpperCase()} title={track.title} subtitle={track.artist?.name||""} coverUrl={track.coverUrl||""} path={`/track/${track.id}`} initialFormat={art.format} initialAction={art.action} onClose={()=>setArt(null)}/>}
  </div>;
}
export function SectionTitle({title,href}:{title:string,href?:string}){ return <div className="flex items-end justify-between mt-10 mb-4"><h2 className="text-xl md:text-2xl font-bold tracking-tight">{title}</h2>{href&&<Link href={href} className="text-xs font-semibold text-neutral-400 hover:text-white tracking-wider">VER TUDO</Link>}</div>; }

export function Cards(){
  const {play}=useApp() as any;
  return {
    TrackCard:({t,queue}:{t:Track,queue:Track[]})=>(<div className="group w-[150px] md:w-[172px] shrink-0">
      <button onClick={()=>play(t,queue)} className="relative block w-full text-left"><img src={t.coverUrl} alt="" className="w-[150px] h-[150px] md:w-[172px] md:h-[172px] object-cover rounded-xl bg-neutral-800"/><span className="absolute bottom-2.5 right-2.5 w-10 h-10 rounded-full bg-white text-black grid place-items-center opacity-0 translate-y-1 group-hover:opacity-100 group-hover:translate-y-0 transition shadow-xl"><Play size={17} fill="currentColor" className="ml-0.5"/></span></button>
      <Link href={`/track/${t.id}`} className="block mt-2.5 text-sm font-semibold truncate hover:underline">{t.title}</Link><Link href={`/artist/${t.artistId}`} className="block text-xs text-neutral-400 truncate hover:text-white">{t.artist?.name}</Link></div>),
    ArtistCard:({a}:{a:any})=>(<Link href={`/artist/${a.id}`} className="group w-[150px] md:w-[172px] shrink-0 text-center"><img src={a.imageUrl} alt="" className="w-[150px] h-[150px] md:w-[172px] md:h-[172px] object-cover rounded-full bg-neutral-800 mx-auto"/><p className="mt-2.5 text-sm font-semibold truncate group-hover:underline">{a.name}</p><p className="text-xs text-neutral-400">{a.genre} • {(a.monthlyListeners/1000).toFixed(0)}k ouvintes/mês</p></Link>),
    AlbumCard:({a}:{a:any})=>(<Link href={`/album/${a.id}`} className="group w-[150px] md:w-[172px] shrink-0"><img src={a.coverUrl} alt="" className="w-[150px] h-[150px] md:w-[172px] md:h-[172px] object-cover rounded-xl bg-neutral-800"/><p className="mt-2.5 text-sm font-semibold truncate group-hover:underline">{a.title}</p><p className="text-xs text-neutral-400 truncate">{a.releaseDate?.slice(0,4)} • {a.artist?.name}</p></Link>),
    PlaylistCard:({p}:{p:any})=>(<Link href={`/playlist/${p.id}`} className="group w-[150px] md:w-[172px] shrink-0"><img src={p.coverUrl||"/icon.svg"} alt="" className="w-[150px] h-[150px] md:w-[172px] md:h-[172px] object-cover rounded-xl bg-neutral-800"/><p className="mt-2.5 text-sm font-semibold truncate group-hover:underline">{p.name}</p><p className="text-xs text-neutral-400 line-clamp-2">{p.description||`${p.trackCount||0} músicas`}</p></Link>),
  };
}


export type PromoFormat = "stories"|"feed";
export type PromoChartItem = {position:number,title:string,artist:string,coverUrl?:string,change?:number|null,isNew?:boolean};
export type PromoSpec = {format:PromoFormat,kindLabel:string,title:string,subtitle?:string,coverUrl?:string,path?:string,chartItems?:PromoChartItem[],styleText?:string,version?:number,siteName?:string};

async function loadImg(src?:string): Promise<HTMLImageElement|null>{
  if(!src) return null;
  return await new Promise((resolve)=>{ const im=new Image(); im.crossOrigin="anonymous"; im.onload=()=>resolve(im); im.onerror=()=>resolve(null); im.src=src; });
}
function wrapText(x:CanvasRenderingContext2D,text:string,max:number,linesMax=3){ const words=(text||"").split(" ").filter(Boolean); const lines:string[]=[]; let line=""; for(const w of words){ const t=line?line+" "+w:w; if(x.measureText(t).width>max&&line){ lines.push(line); line=w; if(lines.length===linesMax) return lines; } else line=t; } if(line&&lines.length<linesMax)lines.push(line); return lines; }

export function dataUrlToBlob(dataUrl:string): Blob {
  const [head, data = ""] = dataUrl.split(",");
  const mime = /data:([^;]+)/.exec(head)?.[1] || "image/png";
  const bin = atob(data);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

export async function generatePromoArt(spec:PromoSpec): Promise<string>{
  const format=spec.format; const W=1080, H=format==="stories"?1920:1350;
  const siteRaw=(spec.siteName||"Sonar"); const site=siteRaw.toLowerCase()==="sonar"?"Sonar":siteRaw; const siteUpper=site.toUpperCase(); const version=spec.version||0;
  const style=(spec.styleText||"").toLowerCase();
  const elegant=/elegan|sofistic|premium|chique/.test(style), dramatic=/dram|impact|forte|chamativ|agressiv/.test(style), minimal=/minimal|limp|simples|clean/.test(style);
  const cv=document.createElement("canvas"); cv.width=W; cv.height=H; const x=cv.getContext("2d")!;
  x.fillStyle="#050505"; x.fillRect(0,0,W,H);
  const cover=await loadImg(spec.coverUrl || spec.chartItems?.[0]?.coverUrl);
  if(cover && !minimal){ try{ x.save(); x.globalAlpha=dramatic?0.34:0.22; const sc=Math.max(W/cover.width,H/cover.height); const dw=cover.width*sc, dh=cover.height*sc; x.drawImage(cover,(W-dw)/2,(H-dh)/2,dw,dh); x.restore(); }catch{} }
  const grad=x.createLinearGradient(0,0,0,H); grad.addColorStop(0,"rgba(0,0,0,0.25)"); grad.addColorStop(0.5,"rgba(0,0,0,0.72)"); grad.addColorStop(1,"rgba(0,0,0,0.96)"); x.fillStyle=grad; x.fillRect(0,0,W,H);
  // decoracao muda a cada versao (sem mudar os dados)
  x.save(); x.strokeStyle="rgba(255,255,255,0.20)"; x.lineWidth=2;
  const decoX=[880,130,520][version%3], decoY=format==="stories"?250:190;
  if(!minimal){ for(let i=0;i<3;i++){ x.beginPath(); x.arc(decoX,decoY,70+i*38,0,Math.PI*2); x.stroke(); } }
  if(dramatic){ x.fillStyle="#ffffff"; x.fillRect(70,format==="stories"?205:165,180,10); }
  x.restore();
  // logo oficial (onda dentro do quadrado arredondado, igual a Opcao B)
  const drawBrandMark=(bx:number,by:number,size:number)=>{
    x.save();
    x.strokeStyle="#fff"; x.lineWidth=Math.max(2.5,size*0.05);
    x.beginPath(); x.roundRect(bx+size*0.03125,by+size*0.03125,size*0.9375,size*0.9375,size*0.28125); x.stroke();
    x.lineWidth=size*0.05625; x.lineCap="round";
    x.beginPath();
    x.moveTo(bx+size*0.25,by+size*0.59375);
    x.bezierCurveTo(bx+size*0.34375,by+size*0.59375,bx+size*0.34375,by+size*0.40625,bx+size*0.4375,by+size*0.40625);
    x.bezierCurveTo(bx+size*0.53125,by+size*0.40625,bx+size*0.53125,by+size*0.65625,bx+size*0.625,by+size*0.65625);
    x.bezierCurveTo(bx+size*0.71875,by+size*0.65625,bx+size*0.71875,by+size*0.34375,bx+size*0.8125,by+size*0.34375);
    x.stroke(); x.restore();
  };
  drawBrandMark(70,54,58);
  x.fillStyle="#fff"; x.font="800 38px Arial"; x.textAlign="left"; x.textBaseline="alphabetic"; x.fillText(site,146,100);
  x.fillStyle="#bdbdbd"; x.font="700 24px Arial"; x.fillText((spec.kindLabel||"").toUpperCase().slice(0,44),70,format==="stories"?190:158);

  const drawCoverBox=async(src:string|undefined,cx:number,cy:number,size:number,radius=34)=>{
    const im=await loadImg(src);
    x.save(); x.beginPath(); x.roundRect(cx,cy,size,size,radius); x.clip();
    if(im){ try{ const sc=Math.max(size/im.width,size/im.height); const dw=im.width*sc, dh=im.height*sc; x.drawImage(im,cx+(size-dw)/2,cy+(size-dh)/2,dw,dh);}catch{ x.fillStyle="#1d1d1d"; x.fillRect(cx,cy,size,size);} }
    else { x.fillStyle="#1d1d1d"; x.fillRect(cx,cy,size,size); drawBrandMark(cx+size/2-70,cy+size/2-70,140); }
    x.restore(); x.strokeStyle="rgba(255,255,255,0.25)"; x.lineWidth=2; x.beginPath(); x.roundRect(cx,cy,size,size,radius); x.stroke();
  };

  if(spec.chartItems && spec.chartItems.length){
    x.textAlign="left"; x.fillStyle="#fff"; x.font=elegant?"700 58px Georgia, serif":"900 62px Arial";
    const tLines=wrapText(x,spec.title,930,2); tLines.forEach((l,i)=>x.fillText(l,70,(format==="stories"?270:225)+i*70));
    if(spec.subtitle){ x.fillStyle="#c9c9c9"; x.font="500 30px Arial"; x.fillText(spec.subtitle.slice(0,64),70,(format==="stories"?270:225)+tLines.length*70+12); }
    const startY=(format==="stories"?430:390)+(tLines.length-1)*38;
    const rowH=format==="stories"?118:88; const maxRows=Math.min(spec.chartItems.length,10);
    for(let i=0;i<maxRows;i++){
      const it=spec.chartItems[i]; const y=startY+i*rowH;
      if(it.position<=3){ x.fillStyle="rgba(255,255,255,0.10)"; x.beginPath(); x.roundRect(58,y-8,964,rowH-14,22); x.fill(); }
      x.fillStyle="#fff"; x.font="900 "+(format==="stories"?54:42)+"px Arial"; x.textAlign="left"; x.fillText(String(it.position),78,y+(format==="stories"?62:48));
      await drawCoverBox(it.coverUrl,165,y,format==="stories"?82:58,16);
      x.fillStyle="#fff"; x.font="700 "+(format==="stories"?34:28)+"px Arial"; const tl=wrapText(x,it.title,format==="stories"?610:650,1); x.fillText(tl[0]||it.title,275,y+(format==="stories"?40:32));
      x.fillStyle="#bdbdbd"; x.font="500 "+(format==="stories"?28:24)+"px Arial"; x.fillText((it.artist||"").slice(0,44),275,y+(format==="stories"?76:62));
      let badge=""; if(it.isNew) badge="NOVO"; else if(typeof it.change==="number"&&it.change>0) badge="▲ "+it.change; else if(typeof it.change==="number"&&it.change<0) badge="▼ "+Math.abs(it.change);
      if(badge){ x.fillStyle="#fff"; x.font="900 22px Arial"; x.textAlign="right"; x.fillText(badge,990,y+(format==="stories"?58:44)); x.textAlign="left"; }
    }
  } else {
    const size=format==="stories"?(minimal?760:880):(minimal?700:820);
    const cx=(W-size)/2, cy=format==="stories"?285:235;
    await drawCoverBox(spec.coverUrl,cx,cy,size,38);
    const titleY=cy+size+(format==="stories"?105:82);
    x.textAlign="left"; x.fillStyle="#fff"; x.font=elegant?"700 64px Georgia, serif":(dramatic?"900 76px Arial":"900 66px Arial");
    const lines=wrapText(x,spec.title||"Sem título",930,3); lines.forEach((l,i)=>x.fillText(l,70,titleY+i*(elegant?74:80)));
    x.fillStyle="#c9c9c9"; x.font="500 38px Arial"; x.fillText((spec.subtitle||"").slice(0,62),70,titleY+lines.length*80+24);
  }

  if(spec.path){
    const url=(typeof window!=="undefined"?window.location.origin:"")+spec.path;
    const qrSize=format==="stories"?280:215; const qx=70, qy=H-qrSize-(format==="stories"?185:150);
    x.fillStyle="#fff"; x.beginPath(); x.roundRect(qx,qy,qrSize,qrSize,26); x.fill();
    const qr=await QRCode.toDataURL(url,{width:540,margin:1,color:{dark:"#000",light:"#fff"}});
    const qi=await loadImg(qr); if(qi) x.drawImage(qi,qx+16,qy+16,qrSize-32,qrSize-32);
    x.fillStyle="#fff"; x.font="800 "+(format==="stories"?36:30)+"px Arial"; x.textAlign="left";
    x.fillText("Aponte a câmera",qx+qrSize+38,qy+72);
    x.fillText("e ouça no "+site,qx+qrSize+38,qy+118);
    x.fillStyle="#a8a8a8"; x.font="500 "+(format==="stories"?28:24)+"px Arial"; x.fillText("Escaneie para abrir no app",qx+qrSize+38,qy+164);
  }
  x.fillStyle="#fff"; x.font="700 26px Arial"; x.textAlign="center";
  x.beginPath(); x.roundRect(W/2-235,H-92,470,58,29); x.strokeStyle="#fff"; x.lineWidth=2; x.stroke();
  x.fillText("Ouvir agora",W/2,H-62);
  return cv.toDataURL("image/png");
}

export function ShareCardModal({kindLabel,title,subtitle,coverUrl,path,onClose,initialFormat,chartItems,styleText,version=0}:{kindLabel:string,title:string,subtitle:string,coverUrl:string,path:string,onClose:()=>void,initialFormat?:PromoFormat,initialAction?:"share"|"download",chartItems?:PromoChartItem[],styleText?:string,version?:number}){
  const app=useApp() as any; const {catalog}=app;
  const siteRaw=(catalog?.settings?.siteName||"Sonar"); const site=siteRaw.toLowerCase()==="sonar"?"Sonar":siteRaw;
  const [format,setFormat]=useState<PromoFormat>(initialFormat||"stories");
  const [img,setImg]=useState(""); const [busy,setBusy]=useState(true);
  const generate=async(f:PromoFormat)=>{ setBusy(true); setImg(""); try{ const out=await generatePromoArt({format:f,kindLabel,title,subtitle,coverUrl,path,chartItems,styleText,version,siteName:site}); const blob=dataUrlToBlob(out); setImg(URL.createObjectURL(blob)); }catch(e){ console.error("art",e); } setBusy(false); };
  useEffect(()=>{ generate(format); },[format]); // eslint-disable-line
  const download=()=>{ if(!img) return; const a=document.createElement("a"); a.href=img; a.download=("sonar-"+format+"-"+(title||"arte").toLowerCase().replace(/[^a-z0-9]+/gi,"-")+".png"); document.body.appendChild(a); a.click(); a.remove(); app.showToast("Arte baixada. Agora é só postar."); };
  const shareFile=async()=>{ if(!img) return; const blob=await (await fetch(img)).blob(); const file=new File([blob],`sonar-${format}.png`,{type:"image/png"}); const nav:any=navigator; if(nav.canShare&&nav.canShare({files:[file]})){ try{ await nav.share({files:[file], title, text:`${title} — ${subtitle} na ${site}`}); return; }catch(e:any){ if(e?.name!=="AbortError") app.showToast("Não foi possível abrir o compartilhamento agora."); return; } } app.showToast("Este aparelho não compartilhou o arquivo direto — use Baixar imagem."); };
  return <div className="fixed inset-0 z-[85] bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-auto" onClick={onClose}>
    <div className="bg-neutral-900 border border-white/10 rounded-3xl p-5 w-full max-w-sm my-8" onClick={e=>e.stopPropagation()}>
      <div className="flex items-center justify-between"><h3 className="font-black">Arte para divulgar</h3><button onClick={onClose} className="text-neutral-400 hover:text-white"><X size={19}/></button></div>
      <p className="text-xs text-neutral-400 mt-1">Arte profissional com capa, título, artista e a marca {site}. O código leva direto ao app quando escaneado.</p>
      <div className="flex gap-2 mt-4">
        <button onClick={()=>setFormat("stories")} className={`flex-1 py-2.5 rounded-full text-sm font-bold ${format==="stories"?"bg-white text-black":"border border-white/25"}`}>Stories 9:16</button>
        <button onClick={()=>setFormat("feed")} className={`flex-1 py-2.5 rounded-full text-sm font-bold ${format==="feed"?"bg-white text-black":"border border-white/25"}`}>Feed 4:5</button>
      </div>
      <div className="mt-4 rounded-2xl overflow-hidden border border-white/10 bg-black grid place-items-center min-h-[280px]">
        {busy? <p className="text-sm text-neutral-500 py-16">Gerando sua arte...</p> : img? <img src={img} alt="Arte gerada" className="w-full"/> : <p className="text-sm text-neutral-500 py-16 px-4 text-center">Não foi possível gerar agora. Toque em tentar de novo.</p>}
      </div>
      {!busy&&!img&&<button onClick={()=>generate(format)} className="w-full mt-3 bg-white text-black font-bold py-3 rounded-full text-sm">Tentar de novo</button>}
      <div className="grid grid-cols-2 gap-2 mt-4">
        <button onClick={download} disabled={!img||busy} className="bg-white text-black font-bold py-3 rounded-full text-sm disabled:opacity-40">Baixar imagem</button>
        <button onClick={shareFile} disabled={!img||busy} className="border border-white/30 font-bold py-3 rounded-full text-sm disabled:opacity-40">Compartilhar</button>
      </div>
      <p className="text-[11px] text-neutral-500 mt-3">Toque em <b className="text-neutral-300">Compartilhar</b> ou <b className="text-neutral-300">Baixar imagem</b> — a arte já está pronta no formato escolhido.</p>
      <p className="text-[11px] text-neutral-500 mt-3">Publicação concluída só dentro do Instagram/WhatsApp: baixe ou compartilhe a arte e finalize por lá. O app não marca nada como postado sozinho.</p>
    </div>
  </div>;
}

export function FileUpload({kind,label,hint,value,onChange}:{kind:"audio"|"image"|"video",label:string,hint?:string,value:string,onChange:(url:string,duration?:number)=>void}){
  const idRef=React.useRef(`fu-${Math.random().toString(36).slice(2,9)}`);
  const [busy,setBusy]=useState(false); const [err,setErr]=useState(""); const [fileName,setFileName]=useState("");
  const handle=async(f:File)=>{ setErr(""); setBusy(true); setFileName(f.name);
    try{
      const fd=new FormData(); fd.append("file",f); fd.append("kind",kind);
      const r=await fetch("/api/upload",{method:"POST",body:fd}); const d=await r.json().catch(()=>({}));
      if(!r.ok){ setErr(d.error||"Erro ao enviar. Tente de novo."); setBusy(false); return; }
      if(kind==="audio"){
        const a=new Audio(); a.preload="metadata";
        a.onloadedmetadata=()=>{ onChange(d.url, Math.round(a.duration||0)); try{URL.revokeObjectURL(a.src);}catch{} setBusy(false); };
        a.onerror=()=>{ onChange(d.url, 0); setBusy(false); };
        a.src=URL.createObjectURL(f);
      } else if(kind==="video"){
        const v=document.createElement("video"); v.preload="metadata";
        v.onloadedmetadata=()=>{ onChange(d.url, Math.round(v.duration||0)); try{URL.revokeObjectURL(v.src);}catch{} setBusy(false); };
        v.onerror=()=>{ onChange(d.url, 0); setBusy(false); };
        v.src=URL.createObjectURL(f);
      } else { onChange(d.url); setBusy(false); }
    }catch{ setErr("Falha de conexão no envio. Tente de novo."); setBusy(false); }
  };
  return <div>
    <input id={idRef.current} type="file" accept={kind==="audio"?"audio/*,.mp3,.wav,.ogg,.m4a,.flac":kind==="video"?"video/*,.mp4,.webm,.mov,.m4v":"image/*"} className="hidden" onChange={e=>{ const f=e.target.files?.[0]; if(f) handle(f); e.target.value=""; }}/>
    <label htmlFor={idRef.current} className={`flex items-center gap-3.5 border border-dashed rounded-2xl px-4 py-4 cursor-pointer transition ${value?"border-white/40 bg-white/5":"border-white/25 hover:border-white/50"}`}>
      <span className="w-11 h-11 rounded-full bg-white text-black grid place-items-center shrink-0"><Upload size={19}/></span>
      <span className="flex-1 min-w-0">
        <span className="block text-sm font-bold">{busy?"Enviando...":value?"Trocar arquivo":label}</span>
        <span className="block text-xs text-neutral-400 truncate">{busy?"Aguarde, não feche esta tela": fileName || hint || (kind==="audio"?"MP3, WAV, OGG ou M4A — até 25MB":kind==="video"?"MP4, WEBM ou MOV — até 100MB":"JPG ou PNG — até 6MB")}</span>
      </span>
      {value&&kind==="image"&&<img src={value} alt="" className="w-11 h-11 rounded-lg object-cover bg-neutral-800 shrink-0"/>}
      {value&&kind!=="image"&&<span className="text-[10px] font-black border border-white/30 rounded-full px-2.5 py-1 shrink-0">OK</span>}
    </label>
    {value&&kind==="audio"&&<audio controls src={value} className="w-full mt-2.5 h-10"/>}
    {value&&kind==="video"&&<video controls playsInline preload="metadata" src={value} className="w-full mt-2.5 aspect-video max-h-64 rounded-xl bg-black object-contain"/>}
    {err&&<p className="text-xs mt-2 border border-white/20 bg-neutral-900 rounded-lg px-3 py-2">{err}</p>}
  </div>;
}

export function PlayAllButton({tracks,label="Reproduzir"}:{tracks:Track[],label?:string}){ const {play}=useApp() as any; if(!tracks.length) return null; return <button onClick={()=>play(tracks[0],tracks)} className="bg-white text-black font-bold px-6 py-3 rounded-full flex items-center gap-2 hover:scale-[1.03] transition text-sm"><Play size={17} fill="currentColor"/>{label}</button>; }
export function Loading(){ return <div className="px-4 md:px-8 py-16 text-center text-neutral-500 text-sm">Carregando...</div>; }
export function Empty({title,body}:{title:string,body:string}){ return <div className="border border-dashed border-white/15 rounded-2xl p-8 text-center"><Music2 className="mx-auto text-neutral-600 mb-3"/><p className="font-bold">{title}</p><p className="text-sm text-neutral-400 mt-1">{body}</p></div>; }
export { fmt };
