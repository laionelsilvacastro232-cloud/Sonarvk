import { db, pool } from "@/db";
import { artists, albums, tracks, users, siteSettings, playlists, playlistTracks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "./auth";

const IMG = {
  luna:"https://images.pexels.com/photos/33338736/pexels-photo-33338736.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  caio:"https://images.pexels.com/photos/33136738/pexels-photo-33136738.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  marina:"https://images.pexels.com/photos/28397702/pexels-photo-28397702.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  theo:"https://images.pexels.com/photos/33136892/pexels-photo-33136892.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  nina:"https://images.pexels.com/photos/33136893/pexels-photo-33136893.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  rafa:"https://images.pexels.com/photos/33418890/pexels-photo-33418890.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  concert:"https://images.pexels.com/photos/36675302/pexels-photo-36675302.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  concert2:"https://images.pexels.com/photos/30215324/pexels-photo-30215324.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  concert3:"https://images.pexels.com/photos/14870726/pexels-photo-14870726.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  concert4:"https://images.pexels.com/photos/20532119/pexels-photo-20532119.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  stage:"https://images.pexels.com/photos/2658312/pexels-photo-2658312.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  crowd:"https://images.pexels.com/photos/12265693/pexels-photo-12265693.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

// Cria as tabelas automaticamente na primeira execução (Neon/Vercel sem comandos)
const SCHEMA_SQL: string[] = [
  `CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, email TEXT NOT NULL UNIQUE, username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL, password_hash TEXT NOT NULL, bio TEXT DEFAULT '', avatar_url TEXT DEFAULT '', role TEXT NOT NULL DEFAULT 'user', suspended BOOLEAN NOT NULL DEFAULT false, history_private BOOLEAN NOT NULL DEFAULT false, reset_token TEXT, reset_expires TIMESTAMP, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS artists (id SERIAL PRIMARY KEY, name TEXT NOT NULL, bio TEXT DEFAULT '', image_url TEXT DEFAULT '', genre TEXT DEFAULT '', verified BOOLEAN NOT NULL DEFAULT true, monthly_listeners INTEGER NOT NULL DEFAULT 0, user_id INTEGER, status TEXT NOT NULL DEFAULT 'approved', created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS albums (id SERIAL PRIMARY KEY, title TEXT NOT NULL, artist_id INTEGER NOT NULL, cover_url TEXT DEFAULT '', release_date TEXT DEFAULT '2025-01-01', type TEXT NOT NULL DEFAULT 'album', genre TEXT DEFAULT '', published BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS tracks (id SERIAL PRIMARY KEY, title TEXT NOT NULL, artist_id INTEGER NOT NULL, album_id INTEGER, featuring TEXT DEFAULT '', cover_url TEXT DEFAULT '', audio_url TEXT NOT NULL, duration INTEGER NOT NULL DEFAULT 180, release_date TEXT DEFAULT '2025-01-01', genre TEXT DEFAULT '', credits TEXT DEFAULT '', lyrics TEXT DEFAULT '', lyrics_source TEXT DEFAULT '', lyrics_generated_at TIMESTAMP, video_url TEXT DEFAULT '', video_thumbnail_url TEXT DEFAULT '', plays INTEGER NOT NULL DEFAULT 0, published BOOLEAN NOT NULL DEFAULT true, featured BOOLEAN NOT NULL DEFAULT false, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS playlists (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL, description TEXT DEFAULT '', cover_url TEXT DEFAULT '', is_public BOOLEAN NOT NULL DEFAULT true, is_collaborative BOOLEAN NOT NULL DEFAULT false, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS playlist_tracks (id SERIAL PRIMARY KEY, playlist_id INTEGER NOT NULL, track_id INTEGER NOT NULL, added_by INTEGER, position INTEGER NOT NULL DEFAULT 0, added_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS favorites (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, track_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS artist_follows (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, artist_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS user_follows (id SERIAL PRIMARY KEY, follower_id INTEGER NOT NULL, following_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS album_saves (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, album_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS playlist_saves (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, playlist_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS history (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, track_id INTEGER NOT NULL, played_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS notifications (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, title TEXT NOT NULL, body TEXT DEFAULT '', read BOOLEAN NOT NULL DEFAULT false, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS reports (id SERIAL PRIMARY KEY, user_id INTEGER, target_type TEXT NOT NULL, target_id INTEGER NOT NULL, reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS site_settings (id SERIAL PRIMARY KEY, site_name TEXT NOT NULL DEFAULT 'SONAR', tagline TEXT NOT NULL DEFAULT '', logo_url TEXT DEFAULT '', hero_title TEXT DEFAULT '', hero_subtitle TEXT DEFAULT '', featured_track_ids TEXT DEFAULT '', featured_artist_ids TEXT DEFAULT '', featured_album_ids TEXT DEFAULT '', updated_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS audit_logs (id SERIAL PRIMARY KEY, admin_id INTEGER, action TEXT NOT NULL, detail TEXT DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS support_messages (id SERIAL PRIMARY KEY, conversation_id TEXT NOT NULL, user_id INTEGER, sender TEXT NOT NULL, body TEXT NOT NULL, read_by_admin BOOLEAN NOT NULL DEFAULT false, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS user_preferences (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL UNIQUE, theme TEXT NOT NULL DEFAULT 'original', favorite_genres TEXT DEFAULT '[]', onboarding_done BOOLEAN NOT NULL DEFAULT false, cookie_consent TEXT DEFAULT '', updated_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS chart_snapshots (id SERIAL PRIMARY KEY, track_id INTEGER NOT NULL, position INTEGER NOT NULL, plays INTEGER NOT NULL DEFAULT 0, snapshot_date TEXT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS support_tickets (id SERIAL PRIMARY KEY, code TEXT NOT NULL DEFAULT '', user_id INTEGER, conversation_id TEXT DEFAULT '', description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TIMESTAMP NOT NULL DEFAULT now(), updated_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE UNIQUE INDEX IF NOT EXISTS pt_unique ON playlist_tracks(playlist_id, track_id)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS fav_unique ON favorites(user_id, track_id)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS af_unique ON artist_follows(user_id, artist_id)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS uf_unique ON user_follows(follower_id, following_id)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS as_unique ON album_saves(user_id, album_id)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS ps_unique ON playlist_saves(user_id, playlist_id)`,
  `CREATE INDEX IF NOT EXISTS tracks_artist_idx ON tracks(artist_id)`,
  `CREATE INDEX IF NOT EXISTS tracks_album_idx ON tracks(album_id)`,
  `CREATE INDEX IF NOT EXISTS support_conv_idx ON support_messages(conversation_id)`,
  `CREATE INDEX IF NOT EXISTS chart_date_idx ON chart_snapshots(snapshot_date)`,
  `CREATE TABLE IF NOT EXISTS clip_likes (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, track_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS clip_comments (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, track_id INTEGER NOT NULL, body TEXT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS clip_reposts (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, track_id INTEGER NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE UNIQUE INDEX IF NOT EXISTS clip_like_unique ON clip_likes(user_id, track_id)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS clip_repost_unique ON clip_reposts(user_id, track_id)`,
  `CREATE INDEX IF NOT EXISTS clip_comments_track_idx ON clip_comments(track_id)`,
  `ALTER TABLE artists ADD COLUMN IF NOT EXISTS user_id INTEGER`,
  `ALTER TABLE artists ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'approved'`,
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_expires TIMESTAMP`,
  `ALTER TABLE users ADD COLUMN IF NOT EXISTS session_version INTEGER NOT NULL DEFAULT 1`,
  `ALTER TABLE tracks ADD COLUMN IF NOT EXISTS lyrics_source TEXT DEFAULT ''`,
  `ALTER TABLE tracks ADD COLUMN IF NOT EXISTS lyrics_generated_at TIMESTAMP`,
  `ALTER TABLE tracks ADD COLUMN IF NOT EXISTS video_url TEXT DEFAULT ''`,
  `ALTER TABLE tracks ADD COLUMN IF NOT EXISTS video_thumbnail_url TEXT DEFAULT ''`,
  `CREATE TABLE IF NOT EXISTS auth_events (id SERIAL PRIMARY KEY, user_id INTEGER, identifier TEXT DEFAULT '', event TEXT NOT NULL, success BOOLEAN NOT NULL DEFAULT false, ip TEXT DEFAULT '', user_agent TEXT DEFAULT '', detail TEXT DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS email_logs (id SERIAL PRIMARY KEY, user_id INTEGER, kind TEXT NOT NULL, provider TEXT NOT NULL DEFAULT 'none', status TEXT NOT NULL, error TEXT DEFAULT '', created_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE TABLE IF NOT EXISTS account_recovery_requests (id SERIAL PRIMARY KEY, code TEXT NOT NULL UNIQUE, user_id INTEGER, identifier TEXT NOT NULL, description TEXT NOT NULL, secret_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', admin_reason TEXT DEFAULT '', decided_by INTEGER, decided_at TIMESTAMP, expires_at TIMESTAMP, used_at TIMESTAMP, created_at TIMESTAMP NOT NULL DEFAULT now(), updated_at TIMESTAMP NOT NULL DEFAULT now())`,
  `CREATE INDEX IF NOT EXISTS auth_events_user_idx ON auth_events(user_id)`,
  `CREATE INDEX IF NOT EXISTS auth_events_created_idx ON auth_events(created_at)`,
  `CREATE INDEX IF NOT EXISTS email_logs_created_idx ON email_logs(created_at)`,
  `CREATE INDEX IF NOT EXISTS recovery_status_idx ON account_recovery_requests(status)`,
  `CREATE INDEX IF NOT EXISTS recovery_user_idx ON account_recovery_requests(user_id)`,
  `UPDATE artists SET genre='Indie/Alternativo' WHERE genre IN ('Pop Alternativo','Indie')`,
  `UPDATE artists SET genre='R&B/Soul' WHERE genre IN ('Soul / R&B','Soul','R&B')`,
  `UPDATE artists SET genre='Bossa Nova' WHERE genre IN ('Jazz / Bossa','Bossa')`,
  `UPDATE artists SET genre='Rock' WHERE genre='Rock Alternativo'`,
  `UPDATE albums SET genre='Indie/Alternativo' WHERE genre IN ('Pop Alternativo','Indie')`,
  `UPDATE albums SET genre='R&B/Soul' WHERE genre IN ('Soul / R&B','Soul','R&B')`,
  `UPDATE albums SET genre='Bossa Nova' WHERE genre IN ('Jazz / Bossa','Bossa')`,
  `UPDATE albums SET genre='Rock' WHERE genre='Rock Alternativo'`,
  `UPDATE tracks SET genre='Indie/Alternativo' WHERE genre IN ('Pop Alternativo','Indie')`,
  `UPDATE tracks SET genre='R&B/Soul' WHERE genre IN ('Soul / R&B','Soul','R&B')`,
  `UPDATE tracks SET genre='Bossa Nova' WHERE genre IN ('Jazz / Bossa','Bossa')`,
  `UPDATE tracks SET genre='Rock' WHERE genre='Rock Alternativo'`,
];
let schemaDone: Promise<void>|null=null;
export function ensureSchema(){
  if(!schemaDone) schemaDone = (async()=>{ for(const q of SCHEMA_SQL){ await pool.query(q); } })().catch(e=>{ console.error("schema",e); schemaDone=null; });
  return schemaDone;
}

let seeding: Promise<void>|null=null;
export function ensureSeed(){
  if(!seeding) seeding = (async()=>{ await ensureSchema(); await seed(); })().catch(e=>{ console.error("seed",e); seeding=null; });
  return seeding;
}
async function seed(){
  const existing = await db.select().from(tracks).limit(1);
  // settings
  const [s]=await db.select().from(siteSettings).limit(1);
  if(!s) await db.insert(siteSettings).values({siteName:"SONAR", tagline:"A nova era da música social", heroTitle:"Sua música. Sua comunidade. Sem ruído.", heroSubtitle:"Descubra artistas independentes, crie playlists, siga amigos e ouça em qualquer dispositivo — em preto e branco, com a sua identidade."});
  // Conta administradora principal: vem SOMENTE das variáveis de ambiente
  // ADMIN_EMAIL e ADMIN_PASSWORD (nunca senhas dentro do código-fonte).
  const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "").toLowerCase();
  const ADMIN_NAME = process.env.ADMIN_NAME || "Administrador";
  let adminId: number | undefined;
  if (ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    let [admin] = await db.select().from(users).where(eq(users.email, ADMIN_EMAIL)).limit(1);
    if (!admin) {
      const [a] = await db.insert(users).values({ email: ADMIN_EMAIL, username: "admin", displayName: ADMIN_NAME, passwordHash: await hashPassword(process.env.ADMIN_PASSWORD), role: "admin", bio: "Administrador da plataforma." }).returning();
      admin = a;
    } else if (admin.role !== "admin" || admin.suspended) {
      await db.update(users).set({ role: "admin", suspended: false }).where(eq(users.id, admin.id));
    }
    adminId = admin?.id;
  } else {
    const [anyAdmin] = await db.select().from(users).where(eq(users.role, "admin")).limit(1);
    adminId = anyAdmin?.id;
  }
  if(existing.length) return;

  const artistData=[
    {name:"Luna Serra", bio:"Cantora e compositora paulistana. Entre o pop alternativo e a MPB contemporânea, Luna transforma memórias em melodias luminosas.", imageUrl:IMG.luna, genre:"Indie/Alternativo", monthlyListeners:284000},
    {name:"Caio Noir", bio:"Produtor e guitarrista. Texturas lo-fi, batidas secas e refrões que ficam — o som das madrugadas da cidade.", imageUrl:IMG.caio, genre:"Indie/Alternativo", monthlyListeners:192000},
    {name:"Marina Vale", bio:"Voz marcante do soul brasileiro atual. Marina mistura groove, jazz e letras confessionais.", imageUrl:IMG.marina, genre:"R&B/Soul", monthlyListeners:341000},
    {name:"Théo Sax & Banda", bio:"Jazz moderno com alma clássica. Improviso, sopros e noites longas.", imageUrl:IMG.theo, genre:"Jazz", monthlyListeners:98000},
    {name:"Nina Prado", bio:"Saxofonista e compositora. Jazz, bossa e eletrônica em diálogo permanente.", imageUrl:IMG.nina, genre:"Bossa Nova", monthlyListeners:76000},
    {name:"Rafa Elétrico", bio:"Rock alternativo com guitarras altas e coração aberto. Ao vivo, é outra coisa.", imageUrl:IMG.rafa, genre:"Rock", monthlyListeners:156000},
  ];
  const insertedArtists:any[]=[];
  for(const a of artistData){ const [r]=await db.insert(artists).values(a).returning(); insertedArtists.push(r); }

  const albumData=[
    {title:"Maré Alta", artistId:insertedArtists[0].id, coverUrl:IMG.concert2, releaseDate:"2025-03-14", type:"album", genre:"Indie/Alternativo"},
    {title:"Cidade em Preto e Branco", artistId:insertedArtists[1].id, coverUrl:IMG.concert4, releaseDate:"2024-11-02", type:"album", genre:"Indie/Alternativo"},
    {title:"Veludo", artistId:insertedArtists[2].id, coverUrl:IMG.stage, releaseDate:"2025-05-20", type:"album", genre:"R&B/Soul"},
    {title:"Noite de Jazz — Ao Vivo", artistId:insertedArtists[3].id, coverUrl:IMG.concert, releaseDate:"2024-08-10", type:"album", genre:"Jazz"},
    {title:"Brisa", artistId:insertedArtists[4].id, coverUrl:IMG.crowd, releaseDate:"2025-01-18", type:"ep", genre:"Bossa Nova"},
    {title:"Voltagem", artistId:insertedArtists[5].id, coverUrl:IMG.concert3, releaseDate:"2025-06-06", type:"album", genre:"Rock"},
    {title:"Meia-Luz", artistId:insertedArtists[0].id, coverUrl:IMG.luna, releaseDate:"2025-07-01", type:"single", genre:"Indie/Alternativo"},
    {title:"Sinal Aberto", artistId:insertedArtists[5].id, coverUrl:IMG.rafa, releaseDate:"2025-02-11", type:"single", genre:"Rock"},
  ];
  const insertedAlbums:any[]=[];
  for(const a of albumData){ const [r]=await db.insert(albums).values(a).returning(); insertedAlbums.push(r); }

  // SoundHelix samples are authorized demo audio (T. Schürger) - real playable source
  const trackDefs=[
    ["Maré Alta",0,0,412000],["Farol",0,0,298000],["Meia-Luz",0,6,521000],["Cidade em Preto e Branco",1,1,367000],["Madrugada Sem Fim",1,1,289000],["Veludo",2,2,634000],["Pele & Vinil",2,2,412000],["Blue Note Paulista",3,3,203000],["Improviso Nº 5",3,3,178000],["Brisa da Manhã",4,4,156000],["Sax na Varanda",4,4,134000],["Voltagem",5,5,489000],["Sinal Aberto",5,7,377000],["Coração Elétrico",5,5,301000],["Marina Canta o Mar",2,2,265000],["Último Trem",1,1,198000],
  ] as const;
  const insertedTracks:any[]=[];
  for(let i=0;i<trackDefs.length;i++){
    const [title, ai, ali, plays]=trackDefs[i] as any;
    const album=insertedAlbums[ali]; const artist=insertedArtists[ai];
    const [r]=await db.insert(tracks).values({
      title, artistId:artist.id, albumId:album.id, coverUrl:album.coverUrl,
      audioUrl:`https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${i+1}.mp3`,
      duration: 240+ (i*17)%180, releaseDate: album.releaseDate, genre: album.genre,
      credits:`Composição: ${artist.name} • Produção: Estúdio SONAR • Fonte de áudio autorizada: SoundHelix (demonstração)`,
      lyrics:`${title} — letra demonstrativa do catálogo independente SONAR.\n\nVerso livre sobre a cidade, o mar e as luzes da noite.\n(Refrão) Canta comigo até o amanhecer.`,
      plays, featured: i%3===0,
    }).returning(); insertedTracks.push(r);
  }

  if(adminId){
    const playlistsData=[
      {name:"Essenciais SONAR", description:"A seleção editorial da semana — o melhor do catálogo independente.", coverUrl:IMG.concert, isPublic:true},
      {name:"Para Focar", description:"Jazz, lo-fi e texturas para trabalhar sem distrações.", coverUrl:IMG.crowd, isPublic:true},
      {name:"Noite na Cidade", description:"Indie e soul para dirigir, caminhar e pensar.", coverUrl:IMG.concert4, isPublic:true},
    ];
    for(let pi=0; pi<playlistsData.length; pi++){
      const [p]=await db.insert(playlists).values({userId:adminId, ...playlistsData[pi]}).returning();
      const slice = insertedTracks.slice(pi*3, pi*3+6);
      for(let i=0;i<slice.length;i++) await db.insert(playlistTracks).values({playlistId:p.id, trackId:slice[i].id, position:i, addedBy:adminId});
    }
  }
}

export async function serializeTracks(rows:any[]){
  if(!rows.length) return [];
  const allArtists=await db.select().from(artists);
  const allAlbums=await db.select().from(albums);
  const am=new Map(allArtists.map(a=>[a.id,a])); const alm=new Map(allAlbums.map(a=>[a.id,a]));
  return rows.map(t=>({...t, artist: am.get(t.artistId)||null, album: alm.get(t.albumId)||null}));
}
