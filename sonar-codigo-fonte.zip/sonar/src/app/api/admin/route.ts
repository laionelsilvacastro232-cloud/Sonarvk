import { NextResponse } from "next/server";
import { db } from "@/db";
import { tracks, artists, albums, playlists, users, history, reports, siteSettings, auditLogs, notifications, accountRecoveryRequests, authEvents, emailLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser, publicUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";
import { mailConfigured, mailProvider } from "@/lib/mail";
import { getAppOrigin } from "@/lib/app-url";
import { logAuthEvent } from "@/lib/security";

async function requireAdmin(){ const me=await getCurrentUser(); if(!me||me.role!=="admin") return null; return me; }
async function log(adminId:number, action:string, detail:string){ await db.insert(auditLogs).values({adminId, action, detail}); }

export async function GET(req: Request){
  await ensureSeed(); const me=await requireAdmin(); if(!me) return NextResponse.json({error:"Acesso restrito a administradores."},{status:403});
  const [allTracks, allArtists, allAlbums, allPlaylists, allUsers, hist, reps, logs, [settings], recoveryRows, authRows, emailRows] = await Promise.all([
    db.select().from(tracks).orderBy(desc(tracks.createdAt)), db.select().from(artists).orderBy(desc(artists.createdAt)),
    db.select().from(albums).orderBy(desc(albums.createdAt)), db.select().from(playlists).orderBy(desc(playlists.createdAt)),
    db.select().from(users).orderBy(desc(users.createdAt)), db.select().from(history), db.select().from(reports).orderBy(desc(reports.createdAt)),
    db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(50), db.select().from(siteSettings).limit(1),
    db.select().from(accountRecoveryRequests).orderBy(desc(accountRecoveryRequests.createdAt)).limit(100),
    db.select().from(authEvents).orderBy(desc(authEvents.createdAt)).limit(100),
    db.select().from(emailLogs).orderBy(desc(emailLogs.createdAt)).limit(100)
  ]);
  const usersById = new Map(allUsers.map((u:any)=>[u.id,u]));
  const recoveryRequests = recoveryRows.map((r:any)=>{
    const u:any = r.userId ? usersById.get(r.userId) : null;
    return {
      id:r.id, code:r.code, identifier:r.identifier, description:r.description, status:r.status, adminReason:r.adminReason||"",
      createdAt:r.createdAt, updatedAt:r.updatedAt, decidedAt:r.decidedAt, expiresAt:r.expiresAt, usedAt:r.usedAt,
      account: u ? {id:u.id, username:u.username, email:u.email, displayName:u.displayName, createdAt:u.createdAt, role:u.role, suspended:u.suspended} : null,
    };
  });
  const failedLogins24h = authRows.filter((e:any)=>!e.success && String(e.event).includes("login") && Date.now()-new Date(e.createdAt).getTime() < 24*60*60*1000).length;
  const googleConfigured = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
  const appleConfigured = Boolean(process.env.APPLE_CLIENT_ID && process.env.APPLE_TEAM_ID && process.env.APPLE_KEY_ID);
  const emailConfigured = mailConfigured();
  const transcriptionConfigured = Boolean(process.env.OPENAI_API_KEY || process.env.TRANSCRIPTION_API_KEY || process.env.WHISPER_API_KEY);
  const missing: string[] = [];
  if (!process.env.AUTH_SECRET) missing.push("AUTH_SECRET");
  if (!googleConfigured) missing.push("GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET");
  if (!emailConfigured) missing.push("SMTP_USER/SMTP_PASS ou RESEND_API_KEY");
  if (!transcriptionConfigured) missing.push("OPENAI_API_KEY (letra automática por IA)");
  if (!process.env.NEXT_PUBLIC_APP_URL) missing.push("NEXT_PUBLIC_APP_URL (recomendado em produção)");
  return NextResponse.json({
    stats:{tracks:allTracks.length, artists:allArtists.length, albums:allAlbums.length, playlists:allPlaylists.length, users:allUsers.length, plays:allTracks.reduce((s,t)=>s+(t.plays||0),0), playsLogged:hist.length, openReports:reps.filter(r=>r.status==="open").length},
    services:{
      database:{status:"connected", configured:Boolean(process.env.DATABASE_URL), detail:"PostgreSQL via DATABASE_URL (local, Neon ou Supabase)"},
      google:{status:googleConfigured?"configured":"pending", configured:googleConfigured, detail:`Redirect URI: ${getAppOrigin(req)}/api/auth/google/callback`},
      apple:{status:appleConfigured?"configured":"pending", configured:appleConfigured},
      email:{status:emailConfigured?"configured":"pending", configured:emailConfigured, detail:emailConfigured?`Provedor ativo: ${mailProvider()}`:"Configure SMTP_USER/SMTP_PASS ou RESEND_API_KEY/RESEND_FROM"},
      transcription:{status:transcriptionConfigured?"configured":"pending", configured:transcriptionConfigured, detail:transcriptionConfigured?`Modelo: ${process.env.OPENAI_TRANSCRIBE_MODEL || process.env.TRANSCRIPTION_MODEL || "gpt-4o-mini-transcribe"}`:"Configure OPENAI_API_KEY para transcrever os áudios"},
      authSecret:{status:process.env.AUTH_SECRET?"configured":"pending", configured:Boolean(process.env.AUTH_SECRET)},
      missing,
    },
    security:{failedLogins24h, events:authRows.map((e:any)=>({id:e.id,userId:e.userId,identifier:e.identifier,event:e.event,success:e.success,ip:e.ip,detail:e.detail,createdAt:e.createdAt})), emailLogs:emailRows},
    recoveryRequests,
    tracks:allTracks, artists:allArtists, albums:allAlbums,
    users:allUsers.map(publicUser), reports:reps, logs, settings
  });
}

export async function POST(req:Request){
  await ensureSeed(); const me=await requireAdmin(); if(!me) return NextResponse.json({error:"Acesso restrito a administradores."},{status:403});
  const b=await req.json().catch(()=>({})); const a=b.action;
  try{
    if(a==="upsert-track"){
      if(!b.id && (!b.title||!b.artistId||!b.audioUrl)) return NextResponse.json({error:"Para criar: título, artista e arquivo de áudio são obrigatórios."},{status:400});
      if(b.id){ const [old]=await db.select().from(tracks).where(eq(tracks.id,b.id)).limit(1); if(!old) return NextResponse.json({error:"Música não encontrada."},{status:404}); await db.update(tracks).set({title:b.title||old.title, artistId:b.artistId?+b.artistId:old.artistId, albumId:b.albumId!==undefined?(b.albumId?+b.albumId:null):old.albumId, coverUrl:b.coverUrl!==undefined?b.coverUrl:(old.coverUrl||""), audioUrl:b.audioUrl||old.audioUrl, duration:b.duration?+b.duration:old.duration, genre:b.genre!==undefined&&b.genre!==""?b.genre:(old.genre||""), credits:b.credits!==undefined?b.credits:(old.credits||""), published:b.published!==undefined?b.published:old.published, featured:b.featured!==undefined?!!b.featured:old.featured}).where(eq(tracks.id,b.id)); await log(me.id,"track.update",b.title||old.title); }
      else { await db.insert(tracks).values({title:b.title, artistId:+b.artistId, albumId:b.albumId?+b.albumId:null, coverUrl:b.coverUrl||"", audioUrl:b.audioUrl, duration:+(b.duration||180), genre:b.genre||"", credits:b.credits||"", published:b.published!==false, featured:!!b.featured}); await log(me.id,"track.create",b.title); }
    }
    else if(a==="delete-track"){ await db.delete(tracks).where(eq(tracks.id,b.id)); await log(me.id,"track.delete",String(b.id)); }
    else if(a==="upsert-artist"){
      if(!b.name) return NextResponse.json({error:"Nome do artista é obrigatório."},{status:400});
      if(b.id) await db.update(artists).set({name:b.name, bio:b.bio||"", imageUrl:b.imageUrl||"", genre:b.genre||"", verified:!!b.verified, monthlyListeners:+(b.monthlyListeners||0)}).where(eq(artists.id,b.id));
      else await db.insert(artists).values({name:b.name, bio:b.bio||"", imageUrl:b.imageUrl||"", genre:b.genre||"", verified:!!b.verified, monthlyListeners:+(b.monthlyListeners||0)});
      await log(me.id,"artist.upsert",b.name);
    }
    else if(a==="delete-artist"){ await db.delete(artists).where(eq(artists.id,b.id)); await log(me.id,"artist.delete",String(b.id)); }
    else if(a==="set-artist-status"){
      if(!["pending","approved","rejected"].includes(b.status)) return NextResponse.json({error:"Status inválido."},{status:400});
      const [art]=await db.update(artists).set({status:b.status, verified:b.status==="approved"}).where(eq(artists.id,b.id)).returning();
      if(art?.userId) await db.insert(notifications).values({userId:art.userId, title: b.status==="approved"?"Perfil de artista aprovado":"Status do perfil de artista atualizado", body: b.status==="approved"?`"${art.name}" foi aprovado! Você já pode enviar músicas.`:`O status de "${art.name}" agora é: ${b.status}.`});
      await log(me.id,"artist.status",`${b.id}:${b.status}`);
    }
    else if(a==="upsert-album"){
      if(!b.title||!b.artistId) return NextResponse.json({error:"Título e artista são obrigatórios."},{status:400});
      if(b.id) await db.update(albums).set({title:b.title, artistId:+b.artistId, coverUrl:b.coverUrl||"", releaseDate:b.releaseDate||"2025-01-01", type:b.type||"album", genre:b.genre||"", published:b.published!==false}).where(eq(albums.id,b.id));
      else await db.insert(albums).values({title:b.title, artistId:+b.artistId, coverUrl:b.coverUrl||"", releaseDate:b.releaseDate||"2025-01-01", type:b.type||"album", genre:b.genre||"", published:b.published!==false});
      await log(me.id,"album.upsert",b.title);
    }
    else if(a==="delete-album"){ await db.delete(albums).where(eq(albums.id,b.id)); await log(me.id,"album.delete",String(b.id)); }
    else if(a==="toggle-suspend"){ const [u]=await db.select().from(users).where(eq(users.id,b.id)).limit(1); if(u&&u.role!=="admin") await db.update(users).set({suspended:!u.suspended}).where(eq(users.id,b.id)); await log(me.id,"user.suspend",String(b.id)); }
    else if(a==="toggle-role"){ const [u]=await db.select().from(users).where(eq(users.id,b.id)).limit(1); if(u) await db.update(users).set({role:u.role==="admin"?"user":"admin"}).where(eq(users.id,b.id)); await log(me.id,"user.role",String(b.id)); }
    else if(a==="resolve-report"){ await db.update(reports).set({status:"resolved"}).where(eq(reports.id,b.id)); await log(me.id,"report.resolve",String(b.id)); }
    else if(a==="recovery-decision"){
      if(!["approved","rejected"].includes(b.decision)) return NextResponse.json({error:"Decisão inválida."},{status:400});
      const [r]=await db.select().from(accountRecoveryRequests).where(eq(accountRecoveryRequests.id,b.id)).limit(1);
      if(!r) return NextResponse.json({error:"Solicitação não encontrada."},{status:404});
      if(r.status==="completed") return NextResponse.json({error:"Solicitação já concluída."},{status:400});
      const reason=(b.reason||"").toString().slice(0,500);
      const expiresAt = b.decision==="approved" ? new Date(Date.now()+24*60*60*1000) : null;
      await db.update(accountRecoveryRequests).set({status:b.decision, adminReason:reason, decidedBy:me.id, decidedAt:new Date(), expiresAt, updatedAt:new Date()}).where(eq(accountRecoveryRequests.id,r.id));
      if(r.userId) await db.insert(notifications).values({userId:r.userId, title:`Recuperação de conta ${r.code}`, body: b.decision==="approved" ? "Sua solicitação foi aprovada. Use seu protocolo e código de acompanhamento em até 24 horas para criar a nova senha." : `Sua solicitação foi rejeitada${reason?`: ${reason}`:"."}`});
      await log(me.id, b.decision==="approved"?"recovery.approve":"recovery.reject", `${r.code}${reason?`: ${reason}`:""}`);
      await logAuthEvent({ userId:r.userId, identifier:r.identifier, event:b.decision==="approved"?"account_recovery_approved":"account_recovery_rejected", success:true, detail:r.code });
    }
    else if(a==="update-settings"){
      const [s]=await db.select().from(siteSettings).limit(1);
      const vals={siteName:b.siteName||"SONAR", tagline:b.tagline||"", logoUrl:b.logoUrl||"", heroTitle:b.heroTitle||"", heroSubtitle:b.heroSubtitle||"", featuredTrackIds:b.featuredTrackIds||"", updatedAt:new Date()};
      if(s) await db.update(siteSettings).set(vals).where(eq(siteSettings.id,s.id)); else await db.insert(siteSettings).values(vals);
      await log(me.id,"settings.update",b.siteName||"");
    }
    else return NextResponse.json({error:"Ação inválida."},{status:400});
    return NextResponse.json({ok:true});
  }catch(e:any){ console.error(e); return NextResponse.json({error:"Erro no painel. Verifique os dados."},{status:500}); }
}
