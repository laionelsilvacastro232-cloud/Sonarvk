import { NextResponse } from "next/server";
import { readFile, stat } from "fs/promises";
import path from "path";
import { createReadStream } from "fs";
import { Readable } from "stream";

// Entrega os arquivos enviados (musicas e imagens) com suporte a Range
// (necessario para a barra de progresso do player funcionar).
const TYPES: Record<string, string> = {
  mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", m4a: "audio/mp4", aac: "audio/aac", flac: "audio/flac",
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif", avif: "image/avif",
  mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime", m4v: "video/x-m4v",
};

export async function GET(req: Request, { params }: { params: Promise<{ path: string[] }> }) {
  const { path: parts } = await params;
  const safe = (parts || []).filter(p => p && !p.includes("..") && !p.includes("/") && !p.includes("\\"));
  if (!safe.length || safe.length !== (parts || []).length) return NextResponse.json({ error: "Arquivo invalido." }, { status: 400 });
  const filePath = path.join(process.cwd(), "public", "uploads", ...safe);
  const ext = (safe[safe.length - 1].split(".").pop() || "").toLowerCase();
  const type = TYPES[ext] || "application/octet-stream";
  try {
    const st = await stat(filePath);
    const total = st.size;
    const range = req.headers.get("range");
    const headers: Record<string, string> = { "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": "public, max-age=86400" };
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      if (m) {
        const start = m[1] ? parseInt(m[1], 10) : 0;
        const end = m[2] ? Math.min(parseInt(m[2], 10), total - 1) : total - 1;
        if (start <= end && start < total) {
          headers["Content-Range"] = `bytes ${start}-${end}/${total}`;
          headers["Content-Length"] = String(end - start + 1);
          const stream = createReadStream(filePath, { start, end });
          return new NextResponse(Readable.toWeb(stream) as any, { status: 206, headers });
        }
      }
    }
    headers["Content-Length"] = String(total);
    const buf = await readFile(filePath);
    return new NextResponse(buf as any, { status: 200, headers });
  } catch {
    return NextResponse.json({ error: "Arquivo nao encontrado." }, { status: 404 });
  }
}
