import { db } from "@/db";
import { sql } from "drizzle-orm";
import { ensureSeed } from "@/lib/catalog";
import { mailConfigured } from "@/lib/mail";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // Garante que as tabelas existam também em um banco PostgreSQL recém-criado
    // (Neon, Supabase ou local). Não retorna nenhuma credencial.
    await ensureSeed();
    const result: any = await db.execute(sql`
      select
        (select count(*)::int from users) as users,
        (select count(*)::int from artists) as artists,
        (select count(*)::int from tracks) as tracks,
        (select count(*)::int from albums) as albums,
        (select count(*)::int from playlists) as playlists
    `);
    const counts = result?.rows?.[0] || result?.[0] || {};

    return Response.json({
      ok: true,
      database: "connected",
      counts: {
        users: Number(counts.users || 0),
        artists: Number(counts.artists || 0),
        tracks: Number(counts.tracks || 0),
        albums: Number(counts.albums || 0),
        playlists: Number(counts.playlists || 0),
      },
      integrations: {
        google: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
        apple: Boolean(process.env.APPLE_CLIENT_ID && process.env.APPLE_TEAM_ID && process.env.APPLE_KEY_ID),
        email: mailConfigured(),
      },
    });
  } catch (error) {
    console.error("health database check failed", error instanceof Error ? error.message : "unknown error");
    return Response.json({ ok: false, database: "error" }, { status: 500 });
  }
}
