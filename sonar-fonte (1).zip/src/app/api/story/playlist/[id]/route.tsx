import { ImageResponse } from "next/og";
import { and, eq, count } from "drizzle-orm";
import { db } from "@/db";
import { playlists, playlistTracks, tracks, users } from "@/db/schema";

export const dynamic = "force-dynamic";

function escapeXml(s: string) {
  return s.replace(/[<>&'"]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" }[c]!));
}

/** Trunca texto em N linhas com reticências, para não estourar o card. */
function clamp(text: string, max: number) {
  const t = text.trim();
  return t.length > max ? t.slice(0, max - 1).trimEnd() + "…" : t;
}

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  const [pl] = await db
    .select({ id: playlists.id, name: playlists.name, description: playlists.description, coverUrl: playlists.coverUrl, editorial: playlists.editorial, ownerName: users.displayName })
    .from(playlists)
    .leftJoin(users, eq(users.id, playlists.ownerId))
    .where(and(eq(playlists.id, id), eq(playlists.isPublic, true)))
    .limit(1);

  if (!pl) {
    return new ImageResponse(
      (<div style={{ width: "100%", height: "100%", background: "#0a0a0a", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif", fontSize: 40 }}>Playlist indisponível</div>),
      { width: 1080, height: 1920 },
    );
  }

  const [{ n }] = await db.select({ n: count() }).from(playlistTracks).where(eq(playlistTracks.playlistId, id));
  const [top] = await db
    .select({ title: tracks.title })
    .from(playlistTracks)
    .innerJoin(tracks, eq(tracks.id, playlistTracks.trackId))
    .where(eq(playlistTracks.playlistId, id))
    .orderBy(playlistTracks.position)
    .limit(1);

  const by = pl.editorial ? "Curadoria da plataforma" : pl.ownerName ? `por ${pl.ownerName}` : "";
  const shortUrl = `/playlist/${pl.id}`;

  let cover: string | null = null;
  if (pl.coverUrl) {
    const res = await fetch(pl.coverUrl).catch(() => null);
    if (res && res.ok) {
      const buf = await res.arrayBuffer();
      const ct = res.headers.get("content-type") || "image/jpeg";
      cover = `data:${ct};base64,${Buffer.from(buf).toString("base64")}`;
    }
  }

  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", background: "#000", color: "#fff", display: "flex", flexDirection: "column", padding: 90, fontFamily: "sans-serif" }}>
        {/* marca */}
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <div style={{ width: 60, height: 60, borderRadius: 16, border: "3px solid #fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34, fontWeight: 800 }}>S</div>
          <div style={{ fontSize: 40, fontWeight: 800, letterSpacing: -1 }}>SonarBR</div>
        </div>

        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
          {/* capa */}
          <div style={{ width: 780, height: 780, borderRadius: 28, background: "#151515", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 40px 120px rgba(255,255,255,0.08)" }}>
            {cover ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={cover} width={780} height={780} style={{ objectFit: "cover" }} alt="" />
            ) : (
              <div style={{ fontSize: 240, fontWeight: 800, color: "#fff", opacity: 0.85 }}>{escapeXml(clamp(pl.name, 1).charAt(0).toUpperCase())}</div>
            )}
          </div>

          <div style={{ fontSize: 72, fontWeight: 800, letterSpacing: -2, marginTop: 60, textAlign: "center", maxWidth: 900 }}>
            {escapeXml(clamp(pl.name, 40))}
          </div>
          {pl.description && (
            <div style={{ fontSize: 34, color: "rgba(255,255,255,0.55)", marginTop: 24, textAlign: "center", maxWidth: 820 }}>
              {escapeXml(clamp(pl.description, 90))}
            </div>
          )}
          {by && (
            <div style={{ fontSize: 30, color: "rgba(255,255,255,0.45)", marginTop: 20 }}>{escapeXml(by)}</div>
          )}
        </div>

        {/* rodapé */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 30, color: "rgba(255,255,255,0.5)" }}>
            <span>{n} {n === 1 ? "faixa" : "faixas"}</span>
            {top ? <span>· comeca por &quot;{escapeXml(clamp(top.title, 28))}&quot;</span> : null}
          </div>
          <div style={{ fontSize: 34, fontWeight: 800, border: "3px solid #fff", borderRadius: 999, padding: "14px 30px" }}>Ouvir agora</div>
        </div>
        <div style={{ fontSize: 28, color: "rgba(255,255,255,0.4)", marginTop: 26, textAlign: "center", width: "100%" }}>{shortUrl}</div>
      </div>
    ),
    { width: 1080, height: 1920 },
  );
}
