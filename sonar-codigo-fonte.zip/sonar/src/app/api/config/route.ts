import { NextResponse } from "next/server";
import { mailConfigured } from "@/lib/mail";

// Expõe apenas estados públicos (nenhum valor secreto): informa ao aplicativo
// quais integrações estão prontas para uso.
export async function GET() {
  return NextResponse.json({
    database: Boolean(process.env.DATABASE_URL),
    google: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    apple: Boolean(process.env.APPLE_CLIENT_ID && process.env.APPLE_TEAM_ID && process.env.APPLE_KEY_ID),
    emailSending: mailConfigured(),
    lyricsAi: Boolean(process.env.OPENAI_API_KEY || process.env.TRANSCRIPTION_API_KEY || process.env.WHISPER_API_KEY),
  });
}
