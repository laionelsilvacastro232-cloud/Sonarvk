import { AccountRecoveryPage } from "@/components/pages";
export default function Page(){ return <AccountRecoveryPage/>; }
