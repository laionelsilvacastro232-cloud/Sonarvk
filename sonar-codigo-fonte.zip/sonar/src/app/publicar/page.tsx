import { DeployGitHubPage } from "@/components/pages";
export default function Page(){ return <DeployGitHubPage/>; }
