// Origem pública do aplicativo (usada no OAuth). Prioriza a URL fixa configurada
// e remove barras finais para montar a redirect_uri exatamente como cadastrada no Google.
export function getAppOrigin(req: Request) {
  const configured = (process.env.NEXT_PUBLIC_APP_URL || "").trim().replace(/\/+$/, "");
  if (configured) return configured;
  const url = new URL(req.url);
  const proto = (req.headers.get("x-forwarded-proto") || url.protocol.replace(":", "")).split(",")[0].trim();
  const host = (req.headers.get("x-forwarded-host") || req.headers.get("host") || url.host).split(",")[0].trim();
  return `${proto}://${host}`;
}

export function googleRedirectUri(req: Request) {
  return `${getAppOrigin(req)}/api/auth/google/callback`;
}
