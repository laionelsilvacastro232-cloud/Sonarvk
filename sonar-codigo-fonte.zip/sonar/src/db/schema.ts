import { pgTable, text, integer, boolean, timestamp, serial, uniqueIndex, index } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull(),
  passwordHash: text("password_hash").notNull(),
  bio: text("bio").default(""),
  avatarUrl: text("avatar_url").default(""),
  role: text("role").notNull().default("user"), // user | admin
  suspended: boolean("suspended").notNull().default(false),
  historyPrivate: boolean("history_private").notNull().default(false),
  resetToken: text("reset_token"),
  resetExpires: timestamp("reset_expires"),
  sessionVersion: integer("session_version").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const artists = pgTable("artists", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bio: text("bio").default(""),
  imageUrl: text("image_url").default(""),
  genre: text("genre").default(""),
  verified: boolean("verified").notNull().default(true),
  monthlyListeners: integer("monthly_listeners").notNull().default(0),
  userId: integer("user_id"),
  status: text("status").notNull().default("approved"), // pending | approved | rejected
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const albums = pgTable("albums", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artistId: integer("artist_id").notNull(),
  coverUrl: text("cover_url").default(""),
  releaseDate: text("release_date").default("2025-01-01"),
  type: text("type").notNull().default("album"), // album|single|ep
  genre: text("genre").default(""),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tracks = pgTable("tracks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  artistId: integer("artist_id").notNull(),
  albumId: integer("album_id"),
  featuring: text("featuring").default(""),
  coverUrl: text("cover_url").default(""),
  audioUrl: text("audio_url").notNull(),
  duration: integer("duration").notNull().default(180),
  releaseDate: text("release_date").default("2025-01-01"),
  genre: text("genre").default(""),
  credits: text("credits").default(""),
  lyrics: text("lyrics").default(""),
  lyricsSource: text("lyrics_source").default(""),
  lyricsGeneratedAt: timestamp("lyrics_generated_at"),
  videoUrl: text("video_url").default(""),
  videoThumbnailUrl: text("video_thumbnail_url").default(""),
  plays: integer("plays").notNull().default(0),
  published: boolean("published").notNull().default(true),
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[index("tracks_artist_idx").on(t.artistId), index("tracks_album_idx").on(t.albumId)]);

export const playlists = pgTable("playlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description").default(""),
  coverUrl: text("cover_url").default(""),
  isPublic: boolean("is_public").notNull().default(true),
  isCollaborative: boolean("is_collaborative").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const playlistTracks = pgTable("playlist_tracks", {
  id: serial("id").primaryKey(),
  playlistId: integer("playlist_id").notNull(),
  trackId: integer("track_id").notNull(),
  addedBy: integer("added_by"),
  position: integer("position").notNull().default(0),
  addedAt: timestamp("added_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("pt_unique").on(t.playlistId, t.trackId)]);

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  trackId: integer("track_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("fav_unique").on(t.userId, t.trackId)]);

export const artistFollows = pgTable("artist_follows", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  artistId: integer("artist_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("af_unique").on(t.userId, t.artistId)]);

export const userFollows = pgTable("user_follows", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").notNull(),
  followingId: integer("following_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("uf_unique").on(t.followerId, t.followingId)]);

export const albumSaves = pgTable("album_saves", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  albumId: integer("album_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("as_unique").on(t.userId, t.albumId)]);

export const playlistSaves = pgTable("playlist_saves", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  playlistId: integer("playlist_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("ps_unique").on(t.userId, t.playlistId)]);

export const history = pgTable("history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  trackId: integer("track_id").notNull(),
  playedAt: timestamp("played_at").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  body: text("body").default(""),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  targetType: text("target_type").notNull(),
  targetId: integer("target_id").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  siteName: text("site_name").notNull().default("SONAR"),
  tagline: text("tagline").notNull().default("A nova era da música social"),
  logoUrl: text("logo_url").default(""),
  heroTitle: text("hero_title").default("Sua música. Sua comunidade. Sem ruído."),
  heroSubtitle: text("hero_subtitle").default("Descubra artistas independentes, crie playlists e ouça em qualquer dispositivo."),
  featuredTrackIds: text("featured_track_ids").default(""),
  featuredArtistIds: text("featured_artist_ids").default(""),
  featuredAlbumIds: text("featured_album_ids").default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const supportMessages = pgTable("support_messages", {
  id: serial("id").primaryKey(),
  conversationId: text("conversation_id").notNull(),
  userId: integer("user_id"),
  sender: text("sender").notNull(), // user | support
  body: text("body").notNull(),
  readByAdmin: boolean("read_by_admin").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[index("support_conv_idx").on(t.conversationId)]);

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id"),
  action: text("action").notNull(),
  detail: text("detail").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  theme: text("theme").notNull().default("original"),
  favoriteGenres: text("favorite_genres").default("[]"),
  onboardingDone: boolean("onboarding_done").notNull().default(false),
  cookieConsent: text("cookie_consent").default(""),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chartSnapshots = pgTable("chart_snapshots", {
  id: serial("id").primaryKey(),
  trackId: integer("track_id").notNull(),
  position: integer("position").notNull(),
  plays: integer("plays").notNull().default(0),
  snapshotDate: text("snapshot_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[index("chart_date_idx").on(t.snapshotDate)]);

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().default(""),
  userId: integer("user_id"),
  conversationId: text("conversation_id").default(""),
  description: text("description").notNull(),
  status: text("status").notNull().default("open"), // open | in_progress | resolved
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});


export const authEvents = pgTable("auth_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  identifier: text("identifier").default(""),
  event: text("event").notNull(),
  success: boolean("success").notNull().default(false),
  ip: text("ip").default(""),
  userAgent: text("user_agent").default(""),
  detail: text("detail").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[index("auth_events_user_idx").on(t.userId), index("auth_events_created_idx").on(t.createdAt)]);

export const emailLogs = pgTable("email_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  kind: text("kind").notNull(),
  provider: text("provider").notNull().default("none"),
  status: text("status").notNull(), // sent | failed | not_configured
  error: text("error").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[index("email_logs_created_idx").on(t.createdAt)]);

export const accountRecoveryRequests = pgTable("account_recovery_requests", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  userId: integer("user_id"),
  identifier: text("identifier").notNull(),
  description: text("description").notNull(),
  secretHash: text("secret_hash").notNull(),
  status: text("status").notNull().default("pending"), // pending | approved | rejected | completed
  adminReason: text("admin_reason").default(""),
  decidedBy: integer("decided_by"),
  decidedAt: timestamp("decided_at"),
  expiresAt: timestamp("expires_at"),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (t)=>[index("recovery_status_idx").on(t.status), index("recovery_user_idx").on(t.userId)]);

export const clipLikes = pgTable("clip_likes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  trackId: integer("track_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("clip_like_unique").on(t.userId, t.trackId)]);

export const clipComments = pgTable("clip_comments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  trackId: integer("track_id").notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[index("clip_comments_track_idx").on(t.trackId)]);

export const clipReposts = pgTable("clip_reposts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  trackId: integer("track_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t)=>[uniqueIndex("clip_repost_unique").on(t.userId, t.trackId)]);
