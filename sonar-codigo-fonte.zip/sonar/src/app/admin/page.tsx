import { AdminPage } from "@/components/pages";
export default function Page(){ return <AdminPage/>; }
