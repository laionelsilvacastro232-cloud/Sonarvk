import { NextResponse } from "next/server";
import { db } from "@/db";
import { supportMessages, users, reports, siteSettings, notifications, supportTickets } from "@/db/schema";
import { eq, desc, asc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";

type Action = { label: string; href: string };
function botReply(raw: string, site: string, first: string): { text: string; intent: string; actions?: Action[] } {
  const m = " " + raw.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "") + " ";
  const oi = first ? `, ${first}` : "";
  if (/\b(oi|ola|eae|salve|opa)\b/.test(m) && m.length < 30) return { intent: "greet", text: `Oi${oi}! Tudo bem? Eu sou da Equipe de Suporte da ${site}. Me conta o que você precisa: conta e senha, playlists, publicar música como artista, charts ou qualquer outra dúvida. Estou por aqui.` };
  if (/(bom dia|boa tarde|boa noite)/.test(m)) return { intent: "greet", text: `Oi${oi}! Que bom te ver por aqui. Como posso te ajudar hoje? Posso falar de conta, playlists, músicas, cores do app ou sobre ser artista na ${site}.` };
  if (/(esqueci|recuperar|redefinir|trocar).*(senha)|(senha).*(esquec|perdi|nao lembro)|nao consigo (entrar|logar)|nao entra|sem acesso|bloquead|por que nao consigo entrar|porque nao consigo entrar/.test(m)) return { intent: "password", actions: [{ label: "Recuperar minha senha", href: "/login" }, { label: "Criar conta", href: "/register" }], text: `Sem problema, a gente resolve${oi}. Na tela de login, toque em "Esqueci minha senha", digite seu e-mail e você recebe um código de 6 dígitos (vale 15 minutos, olhe o spam também). Com o código você cria uma senha nova ali mesmo — sem precisar de ninguém da equipe. Se o e-mail não chegar em 2 minutinhos, abra um chamado aqui embaixo que a gente verifica.` };
  if (/conta de artista|criar.*artista|cadastro.*artista|ser artista|conta.*artista/.test(m) || /\bartista\b/.test(m) || /(public|posta|envia|subi|coloca).{0,40}(musica|faixa|som)/.test(m) || /(musica|faixa).{0,40}(public|posta|envia|aplicativo|app)/.test(m)) return { intent: "artist", actions: [{ label: "Criar conta de artista", href: "/seja-artista" }, { label: "Minha área do artista", href: "/area-artista" }], text: `Boa! É assim: crie sua conta, depois vá em "Sou artista", preencha nome artístico, gênero, foto e bio. Seu perfil é ativado na hora. Na "Área do artista" você envia suas faixas com capa e letra, e elas são publicadas imediatamente — sem revisão do administrador. Toque em um botão aqui embaixo para ir direto.` };
  if (/(seguir|seguidor)/.test(m)) return { intent: "social", actions: [{ label: "Buscar artistas e pessoas", href: "/search" }, { label: "Meu perfil", href: "/profile" }], text: `É facinho: na página do artista, toque em "Seguir". Para seguir pessoas, use a busca na aba "Pessoas" e toque em Seguir no perfil dela. Quem você segue aparece no seu perfil, e as playlists públicas ficam visíveis para a comunidade.` };
  if (/(cor |cores|tema|rosa|verde|azul|amarelo|aparencia)/.test(m)) return { intent: "theme", actions: [{ label: "Abrir Configurações", href: "/settings" }], text: `Dá sim! Vá em Configurações > Aparência e escolha: SONAR original, Rosa, Verde, Azul ou Amarelo. A cor muda na hora em todo o app e fica salva na sua conta para as próximas visitas.` };
  if (/chart|ranking|top |parada|mais ouvidas|em alta/.test(m)) return { intent: "charts", actions: [{ label: "Ver os Charts", href: "/charts" }], text: `Os Charts ficam no menu "Charts". Lá você vê o ranking de músicas e de artistas calculado pelas reproduções reais da ${site}, com posição atual, posição anterior, subidas e quedas — dá para filtrar por gênero. Toque no botão para abrir.` };
  if (/(alter|mud|trocar).*(preferencia|genero|gosto|cadastro|perfil|nome|foto|bio)/.test(m) || /preferencia/.test(m)) return { intent: "prefs", actions: [{ label: "Abrir Configurações", href: "/settings" }, { label: "Meu perfil", href: "/profile" }], text: `Em Configurações você altera nome, foto, bio, a cor do app, seus gêneros favoritos e a privacidade do histórico. Tudo salva na sua conta na hora. Os gêneros que você escolhe ajudam a ${site} a te mostrar coisas do seu gosto.` };
  if (/playlist/.test(m)) return { intent: "playlist", actions: [{ label: "Minha Biblioteca", href: "/library" }], text: `Playlist é facinho${oi}: abra sua Biblioteca e toque em "Nova playlist". Para adicionar músicas, toque nos três pontinhos (•••) de qualquer faixa e escolha a playlist. Dá para deixar pública ou privada, duplicar e compartilhar o link.` };
  if (/(gratis|gratuito|preco|custa|pagar|premium|assinatura|plano)/.test(m)) return { intent: "price", text: `Pode ficar tranquilo: a ${site} é gratuita. Você cria a conta, ouve, monta playlists e, se for artista, publica sem pagar nada. Sem pegadinha.` };
  if (/(bug|erro|trav|nao toca|nao funciona|nao abre|nao carrega|falha|problema)/.test(m)) return { intent: "bug", text: `Poxa, sinto muito por isso${oi}. Já registrei seu relato aqui. Enquanto isso, tenta fechar e abrir o app e conferir sua internet. Se continuar, toque em "Abrir chamado" aqui embaixo e descreva o que acontece — sua conversa fica salva com número e status para a equipe acompanhar.` };
  if (/(quem e|voce e|e robo|e bot|e humano|pessoa de verdade|atendente)/.test(m)) return { intent: "who", text: `Eu sou da Equipe de Suporte da ${site} e estou aqui para te ajudar de verdade: respondo sobre conta, senha, playlists, publicação de músicas, charts e uso do app. Se o seu caso precisar de análise, abra um chamado: ele fica registrado com histórico e a equipe responde por aqui.` };
  if (/(favorit|coracao|curtir|salvar musica)/.test(m)) return { intent: "fav", actions: [{ label: "Minhas favoritas", href: "/library/favorites" }], text: `Para salvar uma música, toque no coração ao lado dela. Tudo que você favorita fica juntinho em Biblioteca > Favoritas, salvo na sua conta para qualquer aparelho.` };
  if (/(letra)/.test(m)) return { intent: "lyrics", text: `A letra aparece na tela expandida do player: é só tocar na barrinha da música lá embaixo que ela abre grandona, com letra, créditos e fila. Boa cantoria!` };
  if (/(obrigad|valeu|brigad)/.test(m)) return { intent: "thanks", text: `Por nada${oi}! Foi um prazer. Se precisar de qualquer outra coisa, é só chamar aqui. Boa música!` };
  if (/(tchau|ate mais|fui)/.test(m)) return { intent: "bye", text: `Até mais${oi}! Qualquer coisa, estou por aqui. Aproveita o som!` };
  if (/historico/.test(m)) return { intent: "history", actions: [{ label: "Meu histórico", href: "/history" }], text: `Seu histórico fica no menu "Histórico": ele registra só o que você realmente ouviu. Dá para remover itens, limpar tudo e até pausar o registro em Configurações (histórico privado).` };
  if (/como (cri|faz|uso|come)|primeiros passos|comecar|novo aqui|cadastro|criar conta/.test(m)) return { intent: "start", actions: [{ label: "Criar conta gratuita", href: "/register" }, { label: "Ver os Charts", href: "/charts" }], text: `Bem-vindo(a) à ${site}${oi}! Crie sua conta grátis em menos de um minuto (só nome, e-mail e senha). Depois escolha seus gêneros e artistas favoritos, ouça pelo player, favorite com o coração e monte playlists na Biblioteca. Se você faz música, em "Sou artista" você publica suas faixas.` };
  return { intent: "fallback", actions: [{ label: "Ver os Charts", href: "/charts" }, { label: "Minha Biblioteca", href: "/library" }], text: `Entendi${oi}. Consigo te ajudar com: recuperar senha, entrar na conta, criar playlists, favoritar músicas, publicar como artista, charts, cores do app e seguidores. Me conta um pouquinho mais — ou toque em "Abrir chamado" que a equipe pega seu caso com número e acompanhamento.` };
}

async function convIdFor(req: Request, me: any) {
  const url = new URL(req.url);
  const c = url.searchParams.get("c") || "";
  if (me) return `u-${me.id}`;
  if (/^g-[a-zA-Z0-9-]{6,}$/.test(c)) return c;
  return null;
}

export async function GET(req: Request) {
  await ensureSeed();
  const me = await getCurrentUser();
  const url = new URL(req.url);
  if (url.searchParams.get("tickets") === "all") {
    if (!me || me.role !== "admin") return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
    const ts = await db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt)).limit(200);
    const us = await db.select().from(users); const um = new Map(us.map(u => [u.id, u]));
    return NextResponse.json({ tickets: ts.map(t => ({ ...t, userName: t.userId ? (um.get(t.userId)?.displayName || "Usuário") : "Visitante", userEmail: t.userId ? (um.get(t.userId)?.email || "") : "" })) });
  }
  if (url.searchParams.get("tickets") === "mine") {
    if (!me) return NextResponse.json({ tickets: [] });
    const ts = await db.select().from(supportTickets).where(eq(supportTickets.userId, me.id)).orderBy(desc(supportTickets.createdAt)).limit(30);
    return NextResponse.json({ tickets: ts });
  }
  if (url.searchParams.get("all") === "1") {
    if (!me || me.role !== "admin") return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
    const rows = await db.select().from(supportMessages).orderBy(desc(supportMessages.createdAt)).limit(600);
    const map = new Map<string, any>();
    for (const r of rows) {
      if (!map.has(r.conversationId)) map.set(r.conversationId, { conversationId: r.conversationId, userId: r.userId, last: r.body, lastAt: r.createdAt, unread: 0, total: 0 });
      const c = map.get(r.conversationId); c.total++;
      if (r.sender === "user" && !r.readByAdmin) c.unread++;
    }
    const us = await db.select().from(users);
    const um = new Map(us.map(u => [u.id, u]));
    const convs = [...map.values()].map(c => ({ ...c, userName: c.userId ? (um.get(c.userId)?.displayName || "Usuário") : "Visitante", userEmail: c.userId ? (um.get(c.userId)?.email || "") : "" }));
    return NextResponse.json({ conversations: convs });
  }
  const conv = await convIdFor(req, me);
  if (!conv) return NextResponse.json({ conversationId: null, messages: [] });
  const target = url.searchParams.get("conversation");
  const convId = (me?.role === "admin" && target) ? target : conv;
  const msgs = await db.select().from(supportMessages).where(eq(supportMessages.conversationId, convId)).orderBy(asc(supportMessages.createdAt)).limit(300);
  if (me?.role === "admin" && target) await db.update(supportMessages).set({ readByAdmin: true }).where(eq(supportMessages.conversationId, convId));
  return NextResponse.json({ conversationId: convId, messages: msgs });
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getCurrentUser();
  const b = await req.json().catch(() => ({}));

  if (b.action === "ticket") {
    const description = (b.description || "").trim();
    if (description.length < 5) return NextResponse.json({ error: "Descreva seu problema em algumas palavras." }, { status: 400 });
    const convId = me ? `u-${me.id}` : (/^g-[a-zA-Z0-9-]{6,}$/.test(b.conversationId || "") ? b.conversationId : "");
    const [t] = await db.insert(supportTickets).values({ userId: me?.id || null, conversationId: convId, description: description.slice(0, 1000), status: "open", code: "" }).returning();
    const code = `SUP-${String(t.id).padStart(4, "0")}`;
    await db.update(supportTickets).set({ code }).where(eq(supportTickets.id, t.id));
    if (convId) await db.insert(supportMessages).values({ conversationId: convId, userId: me?.id || null, sender: "user", body: `Chamado ${code} aberto: ${description}`.slice(0, 900), readByAdmin: false });
    const admins = await db.select().from(users).where(eq(users.role, "admin"));
    for (const a of admins) await db.insert(notifications).values({ userId: a.id, title: `Novo chamado ${code}`, body: description.slice(0, 120) });
    return NextResponse.json({ ok: true, ticket: { ...t, code } });
  }
  if (b.action === "ticket-status") {
    if (!me || me.role !== "admin") return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
    if (!["open", "in_progress", "resolved"].includes(b.status)) return NextResponse.json({ error: "Status inválido." }, { status: 400 });
    const [t] = await db.update(supportTickets).set({ status: b.status, updatedAt: new Date() }).where(eq(supportTickets.id, b.ticketId)).returning();
    if (t?.userId) await db.insert(notifications).values({ userId: t.userId, title: `Chamado ${t.code} atualizado`, body: `Status: ${b.status === "resolved" ? "resolvido" : b.status === "in_progress" ? "em andamento" : "aberto"}. Confira em Suporte.` });
    return NextResponse.json({ ok: true, ticket: t });
  }

  const body = (b.body || "").trim();
  if (!body) return NextResponse.json({ error: "Escreva uma mensagem." }, { status: 400 });
  if (body.length > 2000) return NextResponse.json({ error: "Mensagem muito longa." }, { status: 400 });

  if (b.conversationId && me?.role === "admin") {
    const [msg] = await db.insert(supportMessages).values({ conversationId: b.conversationId, userId: null, sender: "support", body, readByAdmin: true }).returning();
    const targetUserId = b.conversationId.startsWith("u-") ? +b.conversationId.slice(2) : null;
    if (targetUserId) await db.insert(notifications).values({ userId: targetUserId, title: "Equipe de Suporte respondeu você", body: body.slice(0, 120) });
    return NextResponse.json({ ok: true, message: msg });
  }

  const convId = me ? `u-${me.id}` : (/^g-[a-zA-Z0-9-]{6,}$/.test(b.conversationId || "") ? b.conversationId : null);
  if (!convId) return NextResponse.json({ error: "Conversa inválida. Recarregue a página." }, { status: 400 });
  const [userMsg] = await db.insert(supportMessages).values({ conversationId: convId, userId: me?.id || null, sender: "user", body, readByAdmin: false }).returning();
  const [s] = await db.select().from(siteSettings).limit(1);
  const site = s?.siteName || "SONAR";
  const first = me?.displayName?.split(" ")[0] || "";
  const reply = botReply(body, site, first);
  const [botMsg] = await db.insert(supportMessages).values({ conversationId: convId, userId: null, sender: "support", body: reply.text, readByAdmin: true }).returning();
  if (reply.intent === "bug") await db.insert(reports).values({ userId: me?.id || null, targetType: "support", targetId: 0, reason: body.slice(0, 300), status: "open" });
  return NextResponse.json({ ok: true, conversationId: convId, messages: [userMsg, { ...botMsg, actions: reply.actions || [] }] });
}
