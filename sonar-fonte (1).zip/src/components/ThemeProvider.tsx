"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type ThemeId = "original" | "rosa" | "verde" | "azul" | "amarelo";

export const THEMES: { id: ThemeId; label: string; swatch: string }[] = [
  { id: "original", label: "SonarBR", swatch: "#ffffff" },
  { id: "rosa", label: "Rosa", swatch: "#ff5fa2" },
  { id: "verde", label: "Verde", swatch: "#34d17a" },
  { id: "azul", label: "Azul", swatch: "#4d96ff" },
  { id: "amarelo", label: "Amarelo", swatch: "#f5c518" },
];

const STORAGE_KEY = "sonar:theme";
type Ctx = { theme: ThemeId; setTheme: (t: ThemeId) => void; };
const ThemeCtx = createContext<Ctx>({ theme: "original", setTheme: () => {} });
export const useTheme = () => useContext(ThemeCtx);

/** Aplica o tema no <html data-theme> e persiste localmente (e no banco, quando logado). */
export function ThemeProvider({ initial, children }: { initial?: ThemeId | null; children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeId>("original");

  // 1) preferência do servidor (usuário logado) > localStorage > original
  useEffect(() => {
    let t: ThemeId = "original";
    if (initial && THEMES.some((x) => x.id === initial)) t = initial;
    else {
      const ls = localStorage.getItem(STORAGE_KEY) as ThemeId | null;
      if (ls && THEMES.some((x) => x.id === ls)) t = ls;
    }
    setThemeState(t);
    document.documentElement.setAttribute("data-theme", t);
  }, [initial]);

  const setTheme = useCallback((t: ThemeId) => {
    setThemeState(t);
    document.documentElement.setAttribute("data-theme", t);
    try { localStorage.setItem(STORAGE_KEY, t); } catch {}
    // persiste no banco em segundo plano (server action), silencioso
    import("@/app/actions").then((m) => m.saveThemePreference(t)).catch(() => {});
  }, []);

  const value = useMemo(() => ({ theme, setTheme }), [theme, setTheme]);
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

/** Seletor de cor inline (usado em Configurações e no onboarding). */
export function ThemeSwitcher({ compact = false }: { compact?: boolean }) {
  const { theme, setTheme } = useTheme();
  return (
    <div className={compact ? "flex gap-2" : "grid grid-cols-2 gap-2 sm:grid-cols-3"}>
      {THEMES.map((t) => (
        <button
          key={t.id}
          onClick={() => setTheme(t.id)}
          aria-pressed={theme === t.id}
          className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-sm font-semibold transition ${
            theme === t.id ? "border-[var(--accent)] bg-[color:var(--accent)/0.1]" : "border-[color:var(--border)] hover-soft"
          }`}
        >
          <span className="h-4 w-4 rounded-full ring-1 ring-white/20" style={{ background: t.swatch }} />
          {t.label}
        </button>
      ))}
    </div>
  );
}
