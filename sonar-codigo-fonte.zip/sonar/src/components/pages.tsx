"use client";
import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Play, Heart, Share2, Plus, Search, Trash2, Edit3, Check, X, Shield, BarChart3, Users, Music2, Disc, ListMusic, Clock, LogOut, Flag, Lock, Eye, Sparkles, UserPlus, Settings as SettingsIcon, Mic2, Upload, Send, LifeBuoy, Clapperboard, MessageCircle, Repeat2, Volume2, VolumeX } from "lucide-react";
import { useApp, TrackRow, SectionTitle, Cards, PlayAllButton, Loading, Empty, fmt, Track, ShareCardModal, FileUpload, generatePromoArt, dataUrlToBlob, SonarLogo, SonarBrandMark } from "./platform";
import { CANONICAL_GENRES } from "@/lib/genres";
import JSZip from "jszip";

const RowScroll=({children}:{children:React.ReactNode})=><div className="flex gap-4 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0 scrollbar-none">{children}</div>;


export function HeroSpotlight({tracks}:{tracks:Track[]}){
  const {play}=useApp() as any; const [idx,setIdx]=useState(0); const [fade,setFade]=useState(true);
  const list=(tracks||[]).filter(Boolean);
  const safeIdx=list.length? idx%list.length : 0; const t=list[safeIdx];
  useEffect(()=>{ if(list.length<=1) return; const id=setInterval(()=>{ setFade(false); setTimeout(()=>{ setIdx(prev=>{ let n=Math.floor(Math.random()*list.length); if(n===prev&&list.length>1) n=(n+1)%list.length; return n; }); setFade(true); },260); },60000); return ()=>clearInterval(id); },[list.length]); // troca a cada 1 minuto
  if(!t) return null;
  const go=(d:number)=>{ setFade(false); setTimeout(()=>{ setIdx((safeIdx+d+list.length)%list.length); setFade(true); },180); };
  return <section className="relative mt-6 md:mt-8 rounded-3xl overflow-hidden border border-white/10 min-h-[380px] md:min-h-[430px] bg-neutral-900">
    <div key={t.id} className={`absolute inset-0 transition-opacity duration-500 ${fade?"opacity-100":"opacity-0"}`}>
      <img src={t.coverUrl||"/icon.svg"} alt="" className="absolute inset-0 w-full h-full object-cover"/>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/45 to-black/10"/>
      <div className="absolute inset-x-0 bottom-0 p-6 md:p-10 max-w-3xl">
        <p className="text-[11px] font-black tracking-[0.3em] text-neutral-300">DESTAQUE MUSICAL</p>
        <h2 className="text-4xl md:text-6xl font-black leading-[0.95] tracking-tight mt-3">{t.title}</h2>
        <p className="text-lg md:text-xl text-neutral-200 mt-2 font-semibold">{t.artist?.name}</p>
        <p className="text-sm text-neutral-400 mt-1.5">{t.genre}{t.album?.title?` • ${t.album.title}`:""} • {(t.plays/1000).toFixed(0)}k reproduções</p>
        <button onClick={()=>play(t,list)} className="mt-6 bg-white text-black font-black px-7 py-3.5 rounded-full flex items-center gap-2.5 hover:scale-[1.03] transition text-sm"><Play size={18} fill="currentColor"/> Ouvir agora</button>
      </div>
    </div>
    {list.length>1&&<><div className="absolute top-5 right-5 flex gap-2"><button onClick={()=>go(-1)} className="w-10 h-10 rounded-full bg-black/55 border border-white/25 grid place-items-center font-black">‹</button><button onClick={()=>go(1)} className="w-10 h-10 rounded-full bg-black/55 border border-white/25 grid place-items-center font-black">›</button></div>
    <div className="absolute bottom-5 right-6 flex gap-1.5">{list.slice(0,8).map((x,i)=><button key={x.id} onClick={()=>setIdx(i)} className={`h-1.5 rounded-full transition-all ${i===safeIdx?"w-7 bg-white":"w-2.5 bg-white/35"}`}/>)}</div></>}
  </section>;
}

export function LandingPage(){
  const {catalog}=useApp() as any;
  const rawName=(catalog?.settings?.siteName||"Sonar");
  const name=rawName.toLowerCase()==="sonar"?"Sonar":rawName;
  const tagline=catalog?.settings?.tagline||"A música que você ouve, as pessoas que você segue.";
  const logoUrl=catalog?.settings?.logoUrl||"";
  return <div className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-black px-6 py-10 text-white">
    <div className="pointer-events-none absolute inset-x-0 top-0 h-[42dvh] opacity-60 blur-[90px]" style={{background:"radial-gradient(50% 60% at 70% 0%, rgba(255,255,255,0.35), transparent 70%)"}}/>
    <div className="relative w-full max-w-[330px] text-center">
      <div className="mb-7 flex items-center justify-center gap-3"><SonarBrandMark size={60}/></div>
      {logoUrl ? <img src={logoUrl} alt={name} className="mx-auto mb-6 h-16 w-auto object-contain"/> : <p className="mb-6 text-2xl font-extrabold tracking-tight">{name}</p>}
      <h1 className="text-[23px] font-bold leading-snug tracking-tight">Suas músicas<br/>favoritas em um<br/>único lugar.</h1>
      <p className="mx-auto mt-4 max-w-[260px] text-[13px] leading-relaxed text-neutral-500">{tagline}</p>
      <div className="mt-9 flex flex-col gap-2.5">
        <Link href="/login" className="flex h-11 w-full items-center justify-center rounded-[13px] bg-white text-[17px] font-medium text-black transition active:scale-[0.98]">Entrar</Link>
        <Link href="/register" className="flex h-11 w-full items-center justify-center rounded-[13px] border border-white/25 bg-transparent text-[17px] font-medium transition hover:bg-white/10 active:scale-[0.98]">Criar conta</Link>
        <Link href="/seja-artista" className="flex h-11 w-full items-center justify-center gap-2 rounded-[13px] border border-white/25 bg-transparent text-[17px] font-medium transition hover:bg-white/10 active:scale-[0.98]"><Mic2 size={19}/> Sou artista</Link>
      </div>
      <p className="mt-9 text-[11px] uppercase tracking-[0.14em] text-neutral-600">Mais de música</p>
      <div className="mt-3 flex flex-wrap justify-center gap-x-4 gap-y-1 text-[13px] text-neutral-400">
        <Link href="/search" className="hover:text-white">Explorar</Link>
        <Link href="/search" className="hover:text-white">Buscar</Link>
        <Link href="/sobre" className="hover:text-white">Sobre</Link>
        <Link href="/terms" className="hover:text-white">Termos</Link>
        <Link href="/privacy" className="hover:text-white">Privacidade</Link>
      </div>
    </div>
  </div>;
}

const GenreSelect=({value,onChange,className}:{value:string,onChange:(v:string)=>void,className?:string})=>(
  <select value={value||""} onChange={e=>onChange(e.target.value)} className={className||"w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none focus:border-white/50 text-sm"}>
    <option value="">Selecionar gênero</option>
    {CANONICAL_GENRES.map(g=><option key={g} value={g}>{g}</option>)}
    {value&&!(CANONICAL_GENRES as readonly string[]).includes(value)&&<option value={value}>{value}</option>}
  </select>);

export function HomePage(){
  const {catalog,user,library,play}=useApp() as any; const {TrackCard,ArtistCard,AlbumCard,PlaylistCard}=Cards();
  if(user===undefined) return <Loading/>;
  if(!user) return <LandingPage/>;
  if(!catalog) return <Loading/>;
  const tracks:Track[]=catalog.tracks||[]; const s=catalog.settings||{};
  const featured=tracks.filter(t=>t.featured); const recent=[...tracks].slice(-6).reverse(); const popular=[...tracks].sort((a,b)=>b.plays-a.plays).slice(0,8);
  const continueListening = library?.history?.slice(0,6).map((h:any)=>h.track).filter(Boolean) || [];
  return <div className="px-4 md:px-8 max-w-[1500px] mx-auto">
    <HeroSpotlight tracks={(featured.length?featured:popular)}/>

    {continueListening.length>0&&<><SectionTitle title="Continue ouvindo"/><RowScroll>{continueListening.map((t:Track)=><TrackCard key={t.id} t={t} queue={continueListening}/>)}</RowScroll></>}
    {user&&library?.playlists?.length>0&&<><SectionTitle title="Suas playlists" href="/library"/><RowScroll>{library.playlists.map((p:any)=><PlaylistCard key={p.id} p={p}/>)}</RowScroll></>}

    <SectionTitle title="Charts SONAR" href="/charts"/>
    <div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2 max-w-3xl">
      {popular.slice(0,5).map((t:Track,i:number)=><div key={t.id} className="flex items-center gap-3 px-3 py-2 rounded-xl hover:bg-white/5">
        <span className="w-7 text-center text-lg font-black">{i+1}</span>
        <button onClick={()=>play(t,popular)} className="shrink-0"><img src={t.coverUrl||"/icon.svg"} alt="" className="w-10 h-10 rounded object-cover bg-neutral-800"/></button>
        <div className="flex-1 min-w-0"><Link href={`/track/${t.id}`} className="block text-sm font-semibold truncate hover:underline">{t.title}</Link><Link href={`/artist/${t.artistId}`} className="block text-xs text-neutral-400 truncate">{t.artist?.name}</Link></div>
        <span className="text-xs text-neutral-500">{(t.plays/1000).toFixed(0)}k plays</span>
      </div>)}
      <Link href="/charts" className="block text-center text-sm font-bold py-3 border-t border-white/10 mt-1">Ver Charts completos (músicas, artistas e lançamentos)</Link>
    </div>

    <div id="em-alta"><SectionTitle title="Em alta agora" href="/search"/></div>
    <RowScroll>{popular.map(t=><TrackCard key={t.id} t={t} queue={popular}/>)}</RowScroll>

    <SectionTitle title="Lançamentos e singles"/>
    <RowScroll>{(catalog.albums||[]).map((a:any)=><AlbumCard key={a.id} a={a}/>)}</RowScroll>

    <SectionTitle title="Artistas para conhecer"/>
    <RowScroll>{(catalog.artists||[]).map((a:any)=><ArtistCard key={a.id} a={a}/>)}</RowScroll>

    <SectionTitle title="Playlists editoriais"/>
    <RowScroll>{(catalog.playlists||[]).map((p:any)=><PlaylistCard key={p.id} p={p}/>)}</RowScroll>

    <SectionTitle title="Descobertas da semana"/>
    <div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{recent.map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={recent} index={i}/>)}</div>

    <SectionTitle title="Gêneros"/>
    <div className="flex flex-wrap gap-2.5">{(catalog.genres||[]).map((g:string)=><Link key={g} href={`/search?genre=${encodeURIComponent(g)}`} className="px-5 py-3 rounded-full border border-white/15 bg-neutral-900 font-semibold text-sm hover:bg-white hover:text-black transition">{g}</Link>)}</div>
  </div>;
}

export function SearchPage(){
  const params=useSearchParams(); const initial=params.get("q")||""; const genreParam=params.get("genre")||"";
  const [q,setQ]=useState(initial); const [data,setData]=useState<any>(null); const [loading,setLoading]=useState(false); const [filter,setFilter]=useState("all"); const [hist,setHist]=useState<string[]>([]);
  const {TrackCard,ArtistCard,AlbumCard,PlaylistCard}=Cards(); const {play}=useApp() as any;
  useEffect(()=>{ try{ setHist(JSON.parse(localStorage.getItem("noir_search_hist")||"[]")); }catch{} },[]);
  useEffect(()=>{ setQ(initial); },[initial]);
  useEffect(()=>{ const t=setTimeout(async()=>{ setLoading(true); const url=q?`/api/catalog?q=${encodeURIComponent(q)}`: genreParam?`/api/catalog?genre=${encodeURIComponent(genreParam)}`:"/api/catalog"; const r=await fetch(url); setData(await r.json()); setLoading(false); if(q){ const nh=[q,...hist.filter(h=>h!==q)].slice(0,8); setHist(nh); localStorage.setItem("noir_search_hist",JSON.stringify(nh)); } },350); return ()=>clearTimeout(t); },[q,genreParam]); // eslint-disable-line
  const tracks=data?.tracks||[];
  return <div className="px-4 md:px-8 max-w-[1500px] mx-auto pt-6">
    <h1 className="text-3xl font-black tracking-tight">Buscar</h1>
    <div className="relative mt-5 max-w-2xl"><Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-500" size={18}/><input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="Músicas, artistas, álbuns, playlists, pessoas..." className="w-full bg-neutral-900 border border-white/15 rounded-full pl-11 pr-4 py-3.5 outline-none focus:border-white/50"/></div>
    {hist.length>0&&!q&&<div className="mt-4 flex flex-wrap items-center gap-2"><span className="text-xs text-neutral-500 font-semibold">Recentes:</span>{hist.map(h=><button key={h} onClick={()=>setQ(h)} className="text-xs bg-neutral-900 border border-white/10 px-3 py-1.5 rounded-full">{h}</button>)}<button onClick={()=>{setHist([]); localStorage.removeItem("noir_search_hist");}} className="text-xs text-neutral-400 underline">Limpar histórico</button></div>}
    <div className="flex gap-2 mt-6 overflow-x-auto pb-1">{[["all","Tudo"],["tracks","Músicas"],["artists","Artistas"],["albums","Álbuns"],["playlists","Playlists"],["users","Pessoas"]].map(([k,l])=><button key={k} onClick={()=>setFilter(k)} className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap ${filter===k?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>{l}</button>)}</div>
    {loading&&<Loading/>}
    {!loading&&data&&<>
      {tracks.length===0&&data.artists.length===0&&<div className="mt-8"><Empty title="Nada encontrado" body={`Nenhum resultado para "${q}". Tente outro termo ou explore os gêneros.`}/></div>}
      {(filter==="all"||filter==="tracks")&&tracks.length>0&&<><SectionTitle title="Músicas"/><div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{tracks.slice(0,12).map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={tracks} index={i}/>)}</div></>}
      {(filter==="all"||filter==="artists")&&data.artists.length>0&&<><SectionTitle title="Artistas"/><RowScroll>{data.artists.map((a:any)=><ArtistCard key={a.id} a={a}/>)}</RowScroll></>}
      {(filter==="all"||filter==="albums")&&data.albums.length>0&&<><SectionTitle title="Álbuns, EPs e singles"/><RowScroll>{data.albums.map((a:any)=><AlbumCard key={a.id} a={a}/>)}</RowScroll></>}
      {(filter==="all"||filter==="playlists")&&data.playlists.length>0&&<><SectionTitle title="Playlists"/><RowScroll>{data.playlists.map((p:any)=><PlaylistCard key={p.id} p={p}/>)}</RowScroll></>}
      {(filter==="all"||filter==="users")&&data.users?.length>0&&<><SectionTitle title="Pessoas"/><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{data.users.map((u:any)=><Link key={u.id} href={`/user/${u.id}`} className="flex gap-3 items-center bg-neutral-900 border border-white/10 rounded-2xl p-4"><span className="w-11 h-11 rounded-full bg-white text-black grid place-items-center font-bold overflow-hidden">{u.avatarUrl?<img src={u.avatarUrl} alt="" className="w-full h-full object-cover"/>:u.displayName[0]}</span><span><span className="block font-semibold text-sm">{u.displayName}</span><span className="block text-xs text-neutral-400">@{u.username}</span></span></Link>)}</div></>}
    </>}
  </div>;
}

export function LibraryPage(){
  const {user,library,refreshLibrary}=useApp() as any; const params=useSearchParams(); const router=useRouter();
  const [name,setName]=useState(""); const [desc,setDesc]=useState(""); const [isPublic,setIsPublic]=useState(true); const [showForm,setShowForm]=useState(params.get("new")==="1"); const [tab,setTab]=useState("playlists"); const [sort,setSort]=useState("recent");
  useEffect(()=>{ setShowForm(params.get("new")==="1"); },[params]);
  if(user===undefined) return <Loading/>;
  if(!user) return <div className="px-4 md:px-8 pt-10 max-w-xl mx-auto text-center"><h1 className="text-3xl font-black">Sua biblioteca, em qualquer lugar</h1><p className="text-neutral-400 mt-3">Entre para ver favoritos, playlists, artistas seguidos e histórico — tudo salvo na sua conta.</p><Link href="/login" className="inline-block mt-6 bg-white text-black font-bold px-7 py-3 rounded-full">Entrar</Link></div>;
  if(!library) return <Loading/>;
  const create=async()=>{ if(!name.trim()) return; const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"create-playlist",name,description:desc,isPublic})}); const d=await r.json(); if(r.ok){ setName(""); setDesc(""); setShowForm(false); refreshLibrary(); if(d.playlist) router.push(`/playlist/${d.playlist.id}`);} };
  const favs=[...library.favorites||[]]; if(sort==="plays") favs.sort((a,b)=>b.plays-a.plays); if(sort==="az") favs.sort((a,b)=>a.title.localeCompare(b.title));
  return <div className="px-4 md:px-8 max-w-[1500px] mx-auto pt-6">
    <div className="flex flex-wrap items-center justify-between gap-3"><h1 className="text-3xl font-black tracking-tight">Sua Biblioteca</h1><button onClick={()=>setShowForm(!showForm)} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm flex gap-2 items-center"><Plus size={16}/> Nova playlist</button></div>
    {showForm&&<div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5 max-w-xl space-y-3"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Nome da playlist" className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none"/><textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder="Descrição (opcional)" className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none"/><label className="flex gap-2 text-sm text-neutral-300 items-center"><input type="checkbox" checked={isPublic} onChange={e=>setIsPublic(e.target.checked)} className="accent-white"/> Playlist pública</label><button onClick={create} className="bg-white text-black font-bold px-6 py-2.5 rounded-full text-sm">Criar playlist</button></div>}
    <div className="flex gap-2 mt-7 overflow-x-auto">{[["playlists","Playlists"],["favorites","Favoritas"],["artists","Artistas"],["albums","Álbuns salvos"],["history","Recentes"]].map(([k,l])=><button key={k} onClick={()=>setTab(k)} className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap ${tab===k?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>{l}</button>)}
    <select value={sort} onChange={e=>setSort(e.target.value)} className="ml-auto bg-neutral-900 border border-white/10 rounded-full px-3 py-2 text-sm"><option value="recent">Recentes</option><option value="plays">Mais ouvidas</option><option value="az">A–Z</option></select></div>

    {tab==="playlists"&&<div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">
      <Link href="/library/favorites" className="block"><div className="aspect-square rounded-xl bg-white text-black p-5 flex flex-col justify-end"><Heart fill="#000"/><p className="font-black text-xl mt-2 leading-tight">Músicas<br/>Favoritas</p><p className="text-xs font-semibold opacity-60">{library.favoriteIds?.length||0} músicas</p></div></Link>
      {[...library.playlists, ...(library.savedPlaylists||[])].map((p:any)=><Link key={p.id} href={`/playlist/${p.id}`}><img src={p.coverUrl||"/icon.svg"} alt="" className="aspect-square w-full object-cover rounded-xl bg-neutral-800"/><p className="mt-2 text-sm font-semibold truncate">{p.name}</p><p className="text-xs text-neutral-400">{p.trackCount} músicas • {p.isPublic?"Pública":"Privada"}</p></Link>)}
    </div>}
    {tab==="favorites"&&<>{favs.length?<div className="mt-6 bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{favs.map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={favs} index={i}/>)}</div>:<div className="mt-6"><Empty title="Nenhuma favorita ainda" body="Toque no coração de qualquer música para ela aparecer aqui."/></div>}</>}
    {tab==="artists"&&<div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">{library.followedArtistIds?.length? library.followedArtistIds.map((id:number)=>{ const a=(useAppCatalogArtists(id)); return a? <Link key={id} href={`/artist/${id}`} className="text-center"><img src={a.imageUrl} alt="" className="aspect-square w-full object-cover rounded-full bg-neutral-800"/><p className="mt-2 text-sm font-semibold">{a.name}</p></Link>:null; }):<Empty title="Você não segue artistas" body="Siga artistas para acompanhar lançamentos."/>}</div>}
    {tab==="albums"&&<AlbumSavedList ids={library.savedAlbumIds||[]}/>}
    {tab==="history"&&<div className="mt-6">{library.history?.length?<div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{library.history.slice(0,15).map((h:any)=><TrackRow key={h.id} track={h.track} queue={library.history.map((x:any)=>x.track)}/>)}</div>:<Empty title="Sem histórico" body="As músicas que você ouvir aparecerão aqui."/>}<Link href="/history" className="inline-block mt-4 text-sm font-semibold underline">Ver histórico completo</Link></div>}
  </div>;
}
function useAppCatalogArtists(id:number){ const {catalog}=useApp() as any; return catalog?.artists?.find((a:any)=>a.id===id); }
function AlbumSavedList({ids}:{ids:number[]}){ const {catalog}=useApp() as any; const albums=(catalog?.albums||[]).filter((a:any)=>ids.includes(a.id)); if(!albums.length) return <div className="mt-6"><Empty title="Nenhum álbum salvo" body="Salve álbuns na página do álbum para encontrá-los aqui."/></div>; return <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">{albums.map((a:any)=><Link key={a.id} href={`/album/${a.id}`}><img src={a.coverUrl} alt="" className="aspect-square w-full object-cover rounded-xl bg-neutral-800"/><p className="mt-2 text-sm font-semibold truncate">{a.title}</p><p className="text-xs text-neutral-400">{a.artist?.name}</p></Link>)}</div>; }

export function FavoritesPage(){ const {library,user}=useApp() as any; if(user===undefined||(user&&!library)) return <Loading/>; if(!user) return <div className="p-8 text-center"><Link href="/login" className="underline">Faça login</Link> para ver suas favoritas.</div>; const favs=library.favorites||[]; return <div className="px-4 md:px-8 max-w-[1200px] mx-auto pt-8"><h1 className="text-4xl font-black flex items-center gap-3"><Heart fill="#fff"/> Músicas Favoritas</h1><p className="text-neutral-400 mt-2">{favs.length} músicas</p><div className="mt-6 flex gap-3"><PlayAllButton tracks={favs}/></div>{favs.length?<div className="mt-6 bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{favs.map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={favs} index={i}/>)}</div>:<div className="mt-6"><Empty title="Nenhuma favorita" body="Use o coração para salvar músicas."/></div>}</div>; }

export function ArtistPage({id}:{id:number}){
  const {catalog,user,library,refreshLibrary}=useApp() as any; const app=useApp() as any;
  if(!catalog) return <Loading/>; const artist=catalog.artists.find((a:any)=>a.id===id); if(!artist) return <div className="p-8">Artista não encontrado.</div>;
  const tracks=catalog.tracks.filter((t:Track)=>t.artistId===id); const albums=catalog.albums.filter((a:any)=>a.artistId===id); const related=catalog.artists.filter((a:any)=>a.id!==id && a.genre===artist.genre);
  const following=library?.followedArtistIds?.includes(id);
  const {AlbumCard,ArtistCard}=Cards();
  const toggleFollow=async()=>{ if(!user){ location.href="/login"; return; } const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"toggle-follow-artist",artistId:id})}); const d=await r.json(); if(d.library) refreshLibrary(); };
  const share=async()=>{ if(navigator.share) await navigator.share({title:artist.name,url:location.href}).catch(()=>{}); else { app.showToast("Compartilhamento direto não suportado neste aparelho."); } };
  return <div>
    <div className="relative h-[320px] md:h-[380px]"><img src={artist.imageUrl} alt="" className="absolute inset-0 w-full h-full object-cover"/><div className="absolute inset-0 bg-black/55"/><div className="absolute bottom-0 left-0 right-0 px-4 md:px-8 pb-7 max-w-[1500px] mx-auto">{artist.verified&&<p className="text-xs font-bold tracking-widest flex items-center gap-1.5"><Check size={14} className="bg-white text-black rounded-full p-0.5"/> ARTISTA VERIFICADO</p>}<h1 className="text-5xl md:text-7xl font-black tracking-tight mt-2">{artist.name}</h1><p className="text-neutral-300 mt-2">{(artist.monthlyListeners/1000).toFixed(0)} mil ouvintes mensais • {artist.genre}</p></div></div>
    <div className="px-4 md:px-8 max-w-[1500px] mx-auto">
      <div className="flex flex-wrap items-center gap-3 mt-6"><PlayAllButton tracks={tracks}/><button onClick={toggleFollow} className={`px-6 py-3 rounded-full font-bold text-sm border ${following?"bg-white text-black border-white":"border-white/30"}`}>{following?"Seguindo":"Seguir"}</button><button onClick={share} className="p-3 rounded-full border border-white/20"><Share2 size={17}/></button></div>
      <SectionTitle title="Populares"/><div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2 max-w-3xl">{tracks.slice(0,5).map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={tracks} index={i}/>)}</div>
      {tracks.some((t:Track)=>t.videoUrl)&&<><SectionTitle title="Videoclipes"/><div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{tracks.filter((t:Track)=>t.videoUrl).map((t:Track)=><div key={t.id} className="bg-neutral-900 border border-white/10 rounded-2xl overflow-hidden"><video controls playsInline preload="metadata" poster={t.videoThumbnailUrl||t.coverUrl||undefined} src={t.videoUrl} className="w-full aspect-video bg-black object-contain"/><div className="p-3.5"><Link href={`/track/${t.id}`} className="block text-sm font-semibold truncate hover:underline">{t.title}</Link><p className="text-xs text-neutral-400">{artist.name}</p></div></div>)}</div></>}
      <SectionTitle title="Discografia"/><RowScroll>{albums.map((a:any)=><AlbumCard key={a.id} a={a}/>)}</RowScroll>
      {albums.length===0&&<Empty title="Sem lançamentos" body="Este artista ainda não publicou álbuns."/>}
      <SectionTitle title="Todas as músicas"/><div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{tracks.map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={tracks} index={i}/>)}</div>
      <SectionTitle title="Sobre"/><div className="bg-neutral-900 border border-white/10 rounded-2xl p-6 max-w-3xl"><p className="text-neutral-300 leading-relaxed">{artist.bio||"Biografia em breve."}</p></div>
      {related.length>0&&<><SectionTitle title="Artistas relacionados"/><RowScroll>{related.map((a:any)=><ArtistCard key={a.id} a={a}/>)}</RowScroll></>}
    </div>
  </div>;
}

export function AlbumPage({id}:{id:number}){
  const {catalog,user,library,refreshLibrary}=useApp() as any; const app=useApp() as any;
  if(!catalog) return <Loading/>; const album=catalog.albums.find((a:any)=>a.id===id); if(!album) return <div className="p-8">Álbum não encontrado.</div>;
  const tracks=catalog.tracks.filter((t:Track)=>t.albumId===id); const total=tracks.reduce((s:number,t:Track)=>s+t.duration,0); const saved=library?.savedAlbumIds?.includes(id);
  const toggleSave=async()=>{ if(!user){ location.href="/login"; return; } const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"toggle-save-album",albumId:id})}); const d=await r.json(); if(d.library) refreshLibrary(); app.showToast(saved?"Removido da biblioteca.":"Álbum salvo."); };
  const share=async()=>{ if(navigator.share) await navigator.share({title:album.title,url:location.href}).catch(()=>{}); else { app.showToast("Compartilhamento direto não suportado neste aparelho."); } };
  return <div className="px-4 md:px-8 max-w-[1500px] mx-auto pt-6 md:pt-10">
    <div className="flex flex-col md:flex-row gap-6 md:items-end"><img src={album.coverUrl} alt="" className="w-56 h-56 md:w-64 md:h-64 object-cover rounded-2xl shadow-2xl"/><div><p className="text-xs font-bold tracking-[0.25em] text-neutral-400 uppercase">{album.type}</p><h1 className="text-4xl md:text-6xl font-black tracking-tight mt-2">{album.title}</h1><p className="mt-3 text-neutral-300"><Link href={`/artist/${album.artistId}`} className="font-semibold text-white hover:underline">{album.artist?.name}</Link> • {album.releaseDate} • {tracks.length} músicas, {fmt(total)}</p></div></div>
    <div className="flex gap-3 mt-7"><PlayAllButton tracks={tracks}/><button onClick={toggleSave} className={`px-6 py-3 rounded-full font-bold text-sm border ${saved?"bg-white text-black":"border-white/30"}`}>{saved?"Salvo":"Salvar"}</button><button onClick={share} className="p-3 rounded-full border border-white/20"><Share2 size={17}/></button></div>
    <div className="mt-7 bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{tracks.map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={tracks} index={i}/>)}</div>
    <p className="text-xs text-neutral-500 mt-5">© {album.releaseDate?.slice(0,4)} {album.artist?.name} • Distribuído via SONAR • Gênero: {album.genre}</p>
  </div>;
}

export function PlaylistPage({id}:{id:number}){
  const {catalog,user,library,refreshLibrary,refreshCatalog}=useApp() as any; const app=useApp() as any; const router=useRouter();
  const [local,setLocal]=useState<any>(null); const [editing,setEditing]=useState(false); const [name,setName]=useState(""); const [desc,setDesc]=useState(""); const [isPublic,setIsPublic]=useState(true); const [shareCard,setShareCard]=useState(false);
  const load=async()=>{ const r=await fetch("/api/catalog"); const d=await r.json(); setLocal(d.playlists.find((p:any)=>p.id===id)||null); };
  useEffect(()=>{ load(); },[id]); // eslint-disable-line
  if(!catalog&&!local) return <Loading/>;
  const playlist=local || catalog?.playlists?.find((p:any)=>p.id===id);
  // own playlists may be private and not in public catalog; check library
  const ownPlaylist=library?.playlists?.find((p:any)=>p.id===id); const effective=playlist||ownPlaylist;
  if(!effective) return <div className="px-4 md:px-8 pt-10"><Empty title="Playlist não encontrada ou privada" body="Ela pode ser privada ou ter sido removida."/></div>;
  const allTracks:Track[]=catalog?.tracks||[]; const tracks=(effective.trackIds||[]).map((tid:number)=>allTracks.find(t=>t.id===tid)).filter(Boolean); const total=tracks.reduce((s:number,t:Track)=>s+t.duration,0);
  const mine=user && effective.userId===user.id;
  const act=async(action:string,extra:any={},msg="Feito.")=>{ const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,...extra})}); const d=await r.json(); if(!r.ok) app.showToast(d.error||"Erro"); else { app.showToast(msg); refreshLibrary(); load(); refreshCatalog(); if(d.playlist) router.push(`/playlist/${d.playlist.id}`); } };
  return <div className="px-4 md:px-8 max-w-[1500px] mx-auto pt-6 md:pt-10">
    <div className="flex flex-col md:flex-row gap-6 md:items-end"><img src={effective.coverUrl||"/icon.svg"} alt="" className="w-56 h-56 object-cover rounded-2xl bg-neutral-800"/><div><p className="text-xs font-bold tracking-[0.25em] text-neutral-400">PLAYLIST {effective.isPublic?"PÚBLICA":"PRIVADA"}{effective.isCollaborative?" • COLABORATIVA":""}</p><h1 className="text-4xl md:text-6xl font-black tracking-tight mt-2">{effective.name}</h1><p className="text-neutral-400 mt-2 max-w-xl">{effective.description}</p><p className="text-sm text-neutral-300 mt-2">{effective.ownerName||user?.displayName} • {tracks.length} músicas, {fmt(total)}</p></div></div>
    <div className="flex flex-wrap gap-3 mt-7"><PlayAllButton tracks={tracks}/>{!mine&&user&&<button onClick={()=>act("toggle-save-playlist",{playlistId:id},"Biblioteca atualizada.")} className="px-6 py-3 rounded-full border border-white/30 font-bold text-sm">Salvar playlist</button>}
    {mine&&<><button onClick={()=>{setEditing(!editing); setName(effective.name); setDesc(effective.description||""); setIsPublic(effective.isPublic);}} className="px-5 py-3 rounded-full border border-white/30 font-bold text-sm flex gap-2"><Edit3 size={15}/> Editar</button><button onClick={()=>{ if(confirm("Excluir esta playlist?")) act("delete-playlist",{playlistId:id},"Playlist excluída."); }} className="px-5 py-3 rounded-full border border-white/30 font-bold text-sm flex gap-2"><Trash2 size={15}/> Excluir</button></>}
    <button onClick={()=>act("duplicate-playlist",{playlistId:id},"Playlist duplicada.")} className="px-5 py-3 rounded-full border border-white/30 font-bold text-sm">Duplicar</button>
    <button onClick={()=>setShareCard(true)} className="px-5 py-3 rounded-full border border-white/30 font-bold text-sm">Cartão p/ Stories</button><button onClick={async()=>{ if(navigator.share) await navigator.share({title:effective.name,url:location.href}).catch(()=>{}); else { app.showToast("Compartilhamento direto não suportado neste aparelho."); } }} className="p-3 rounded-full border border-white/20"><Share2 size={17}/></button></div>{shareCard&&<ShareCardModal kindLabel={("MINHA PLAYLIST NA "+(catalog?.settings?.siteName||"SONAR")).toUpperCase()} title={effective.name} subtitle={(effective.ownerName||"Playlist")+" • "+tracks.length+" músicas"} coverUrl={effective.coverUrl||""} path={`/playlist/${id}`} onClose={()=>setShareCard(false)}/>}
    {editing&&<div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5 max-w-xl space-y-3"><input value={name} onChange={e=>setName(e.target.value)} className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none"/><textarea value={desc} onChange={e=>setDesc(e.target.value)} className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none" placeholder="Descrição"/><label className="flex gap-2 text-sm items-center"><input type="checkbox" checked={isPublic} onChange={e=>setIsPublic(e.target.checked)} className="accent-white"/> Pública</label><button onClick={()=>{ act("update-playlist",{playlistId:id,name,description:desc,isPublic},"Playlist atualizada."); setEditing(false); }} className="bg-white text-black font-bold px-6 py-2.5 rounded-full text-sm">Salvar alterações</button></div>}
    {!effective.isPublic&&<p className="mt-5 text-xs text-neutral-500 border border-white/10 rounded-xl px-3.5 py-2.5">Playlist privada: o cartão e o link só abrem para você. Torne-a pública em Editar para compartilhar com todo mundo.</p>}
    <div className="mt-7 bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{tracks.length? tracks.map((t:Track,i:number)=><div key={t.id} className="flex items-center"><div className="flex-1"><TrackRow track={t} queue={tracks} index={i}/></div>{mine&&<button onClick={()=>act("remove-from-playlist",{playlistId:id,trackId:t.id},"Removida.")} className="text-neutral-500 hover:text-white px-2"><X size={16}/></button>}</div>) : <Empty title="Playlist vazia" body="Adicione músicas pelo menu ••• de qualquer faixa."/>}</div>
  </div>;
}

export function TrackPage({id}:{id:number}){
  const app=useApp() as any; const {catalog}=app; const app2Toast=()=>app.showToast("Compartilhamento direto não suportado neste aparelho."); const [art,setArt]=useState<any>(null); if(!catalog) return <Loading/>; const track=catalog.tracks.find((t:Track)=>t.id===id); if(!track) return <div className="p-8">Música não encontrada.</div>;
  const related=catalog.tracks.filter((t:Track)=>t.id!==id && (t.artistId===track.artistId||t.genre===track.genre)).slice(0,6); const queue=[track,...related];
  return <div className="px-4 md:px-8 max-w-[1100px] mx-auto pt-8">
    <div className="flex flex-col md:flex-row gap-6 md:items-end"><img src={track.coverUrl} alt="" className="w-56 h-56 object-cover rounded-2xl"/><div><p className="text-xs font-bold tracking-[0.25em] text-neutral-400">MÚSICA</p><h1 className="text-4xl md:text-6xl font-black mt-2">{track.title}</h1><p className="mt-3"><Link href={`/artist/${track.artistId}`} className="font-semibold hover:underline">{track.artist?.name}</Link> <span className="text-neutral-400">• {track.album?.title} • {track.releaseDate} • {fmt(track.duration)}</span></p></div></div>
    <div className="mt-7 flex flex-wrap gap-3"><PlayAllButton tracks={queue} label="Reproduzir"/>
    <button onClick={async()=>{ const url=location.href; if(navigator.share) await navigator.share({title:track.title,text:`${track.title} — ${track.artist?.name||""}`,url}).catch(()=>{}); else app2Toast(); }} className="px-6 py-3 rounded-full border border-white/30 font-bold text-sm">Compartilhar</button>
    <button onClick={()=>setArt({format:"stories",action:"share"})} className="px-5 py-3 rounded-full border border-white/30 font-bold text-sm">Stories 9:16</button>
    <button onClick={()=>setArt({format:"feed",action:"share"})} className="px-5 py-3 rounded-full border border-white/30 font-bold text-sm">Feed 4:5</button>
    <button onClick={()=>setArt({format:"stories",action:"download"})} className="px-5 py-3 rounded-full border border-white/20 font-bold text-sm">Baixar Stories</button>
    <button onClick={()=>setArt({format:"feed",action:"download"})} className="px-5 py-3 rounded-full border border-white/20 font-bold text-sm">Baixar Feed</button></div>
    {art&&track&&<ShareCardModal kindLabel={"MÚSICA NA "+(catalog?.settings?.siteName||"SONAR").toUpperCase()} title={track.title} subtitle={track.artist?.name||""} coverUrl={track.coverUrl||""} path={`/track/${id}`} initialFormat={art.format} initialAction={art.action} onClose={()=>setArt(null)}/>}
    <div className="mt-7 bg-neutral-900/60 border border-white/10 rounded-2xl p-2"><TrackRow track={track} queue={queue}/></div>
    {track.videoUrl&&<div className="mt-6 bg-neutral-900 border border-white/10 rounded-2xl overflow-hidden"><div className="px-5 pt-5"><h2 className="font-bold">Videoclipe</h2><p className="text-xs text-neutral-400 mt-1">{track.title} — {track.artist?.name}</p></div><video controls playsInline preload="metadata" poster={track.videoThumbnailUrl||track.coverUrl||undefined} src={track.videoUrl} className="w-full aspect-video bg-black object-contain mt-4"/></div>}
    {track.lyrics&&<div className="mt-6 bg-neutral-900 border border-white/10 rounded-2xl p-6"><h2 className="font-bold mb-3">Letra</h2><p className="whitespace-pre-line text-neutral-300 leading-relaxed">{track.lyrics}</p></div>}
    {track.credits&&<p className="text-sm text-neutral-500 mt-5">{track.credits}</p>}
    <SectionTitle title="Relacionadas"/><div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{related.map((t:Track,i:number)=><TrackRow key={t.id} track={t} queue={queue} index={i}/>)}</div>
  </div>;
}

export function HistoryPage(){
  const {library,user,refreshLibrary}=useApp() as any; const app=useApp() as any;
  if(user===undefined) return <Loading/>; if(!user) return <div className="p-8 text-center">Faça <Link href="/login" className="underline">login</Link> para ver seu histórico.</div>; if(!library) return <Loading/>;
  const act=async(action:string,extra:any={})=>{ await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,...extra})}); refreshLibrary(); };
  return <div className="px-4 md:px-8 max-w-[1100px] mx-auto pt-8"><div className="flex justify-between items-center flex-wrap gap-3"><div><h1 className="text-3xl font-black">Histórico</h1><p className="text-neutral-400 text-sm mt-1">Registrado apenas quando uma música é reproduzida.</p></div>{library.history.length>0&&<button onClick={()=>{ if(confirm("Limpar todo o histórico?")) act("clear-history"); }} className="border border-white/25 px-5 py-2.5 rounded-full text-sm font-bold">Limpar histórico</button>}</div>
  {library.history.length? <div className="mt-6 bg-neutral-900/60 border border-white/10 rounded-2xl p-2">{library.history.map((h:any)=><div key={h.id} className="flex items-center"><div className="flex-1"><TrackRow track={h.track} queue={library.history.map((x:any)=>x.track)}/></div><span className="hidden md:block text-xs text-neutral-500 w-36">{new Date(h.playedAt).toLocaleString("pt-BR")}</span><button onClick={()=>act("remove-history",{historyId:h.id})} className="text-neutral-500 hover:text-white px-2"><Trash2 size={15}/></button></div>)}</div> : <div className="mt-6"><Empty title="Nada por aqui" body="Ouça uma música e ela aparecerá no histórico."/></div>}
  </div>;
}

export function ProfilePage(){
  const {user,library,catalog,setUser}=useApp() as any; const router=useRouter();
  if(user===undefined) return <Loading/>; if(!user) { return <div className="px-4 pt-10 text-center"><h1 className="text-3xl font-black">Seu perfil musical</h1><p className="text-neutral-400 mt-2">Entre para gerenciar perfil, seguidores e playlists públicas.</p><Link href="/login" className="inline-block mt-6 bg-white text-black font-bold px-7 py-3 rounded-full">Entrar</Link></div>; }
  const myPublic=(library?.playlists||[]).filter((p:any)=>p.isPublic);
  return <div className="px-4 md:px-8 max-w-[1200px] mx-auto pt-8">
    <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center"><span className="w-28 h-28 rounded-full bg-white text-black grid place-items-center text-4xl font-black overflow-hidden shrink-0">{user.avatarUrl?<img src={user.avatarUrl} alt="" className="w-full h-full object-cover"/>:user.displayName[0]}</span><div><p className="text-xs tracking-[0.25em] font-bold text-neutral-400">PERFIL</p><h1 className="text-4xl md:text-5xl font-black mt-1">{user.displayName}</h1><p className="text-neutral-400">@{user.username} • {library?.followerCount||0} seguidores • {library?.followingCount||0} seguindo</p>{user.bio&&<p className="text-neutral-300 mt-2 max-w-lg">{user.bio}</p>}</div><Link href="/settings" className="sm:ml-auto border border-white/25 px-5 py-2.5 rounded-full text-sm font-bold">Editar perfil</Link></div>
    <Link href="/area-artista" className="mt-8 flex flex-wrap items-center gap-4 bg-neutral-900 border border-white/10 rounded-2xl p-5 hover:border-white/35 transition"><span className="w-11 h-11 rounded-full bg-white text-black grid place-items-center"><Mic2 size={19}/></span><span className="flex-1 min-w-[210px]"><span className="block font-bold">Estúdio do Artista</span><span className="block text-sm text-neutral-400 mt-0.5">Publicar músicas, álbuns e videoclipes, gerar letras e editar seu perfil.</span></span><span className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm">Abrir estúdio</span></Link>
    {user.role==="admin"&&<Link href="/admin" className="mt-3 flex flex-wrap items-center gap-4 bg-white text-black rounded-2xl p-5"><span className="w-11 h-11 rounded-full bg-black text-white grid place-items-center"><Shield size={19}/></span><span className="flex-1 min-w-[210px]"><span className="block font-bold">Painel Admin</span><span className="block text-sm text-neutral-600 mt-0.5">Usuários, músicas, aprovações, suporte e configurações do Sonar.</span></span><span className="bg-black text-white font-bold px-5 py-2.5 rounded-full text-sm">Abrir painel</span></Link>}
    <SectionTitle title="Playlists públicas"/><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">{myPublic.length? myPublic.map((p:any)=><Link key={p.id} href={`/playlist/${p.id}`}><img src={p.coverUrl||"/icon.svg"} alt="" className="aspect-square w-full object-cover rounded-xl bg-neutral-800"/><p className="mt-2 text-sm font-semibold truncate">{p.name}</p><p className="text-xs text-neutral-400">{p.trackCount} músicas</p></Link>):<Empty title="Nenhuma playlist pública" body="Crie uma playlist pública para ela aparecer no seu perfil."/>}</div>
    <SectionTitle title="Artistas que você segue"/><div className="flex flex-wrap gap-3">{(library?.followedArtistIds||[]).map((id:number)=>{ const a=catalog?.artists?.find((x:any)=>x.id===id); return a?<Link key={id} href={`/artist/${id}`} className="flex items-center gap-2 bg-neutral-900 border border-white/10 rounded-full pl-1.5 pr-4 py-1.5"><img src={a.imageUrl} alt="" className="w-8 h-8 rounded-full object-cover"/><span className="text-sm font-semibold">{a.name}</span></Link>:null; })}{!library?.followedArtistIds?.length&&<p className="text-sm text-neutral-500">Você ainda não segue artistas.</p>}</div>
  </div>;
}

export function UserPage({id}:{id:number}){
  const {catalog,user,library,refreshLibrary}=useApp() as any; const [target,setTarget]=useState<any>(null);
  useEffect(()=>{ (async()=>{ const r=await fetch(`/api/catalog?q=`); const d=await r.json(); /* users only via search; fallback fetch search by id not available, use catalog users empty */ })(); },[id]);
  // Use search endpoint trick: we fetch all users via catalog search with empty? Instead use profile from playlists owner? Simpler: show via API search all
  useEffect(()=>{ (async()=>{ const r=await fetch("/api/users"); if(r.ok){ const d=await r.json(); setTarget(d.users.find((u:any)=>u.id===id)); } })(); },[id]);
  if(!target) return <Loading/>;
  const following=library?.followingIds?.includes(id);
  const toggle=async()=>{ if(!user){ location.href="/login"; return; } const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"toggle-follow-user",userId:id})}); const d=await r.json(); if(d.library) refreshLibrary(); };
  const publics=(catalog?.playlists||[]).filter((p:any)=>p.userId===id);
  return <div className="px-4 md:px-8 max-w-[1200px] mx-auto pt-8"><div className="flex gap-6 items-center flex-wrap"><span className="w-24 h-24 rounded-full bg-white text-black grid place-items-center text-3xl font-black overflow-hidden">{target.avatarUrl?<img src={target.avatarUrl} alt="" className="w-full h-full object-cover"/>:target.displayName[0]}</span><div><h1 className="text-4xl font-black">{target.displayName}</h1><p className="text-neutral-400">@{target.username}</p>{target.bio&&<p className="text-neutral-300 mt-1">{target.bio}</p>}</div>{user&&user.id!==id&&<button onClick={toggle} className={`px-6 py-2.5 rounded-full font-bold text-sm ${following?"bg-white text-black":"border border-white/30"}`}>{following?"Seguindo":"Seguir"}</button>}</div>
  <SectionTitle title="Playlists públicas"/><div className="grid grid-cols-2 sm:grid-cols-4 gap-4">{publics.length?publics.map((p:any)=><Link key={p.id} href={`/playlist/${p.id}`}><img src={p.coverUrl||"/icon.svg"} alt="" className="aspect-square w-full object-cover rounded-xl bg-neutral-800"/><p className="mt-2 text-sm font-semibold">{p.name}</p></Link>):<Empty title="Sem playlists públicas" body="Este usuário ainda não publicou playlists."/>}</div></div>;
}

export function SettingsPage(){
  const {user,setUser,theme,setTheme,catalog}=useApp() as any; const app=useApp() as any; const router=useRouter();
  const [displayName,setDisplayName]=useState(""); const [bio,setBio]=useState(""); const [avatarUrl,setAvatarUrl]=useState(""); const [historyPrivate,setHistoryPrivate]=useState(false); const [cur,setCur]=useState(""); const [next,setNext]=useState(""); const [msg,setMsg]=useState(""); const [favGenres,setFavGenres]=useState<string[]>([]);
  useEffect(()=>{ (async()=>{ try{ const r=await fetch("/api/prefs"); const d=await r.json(); try{ setFavGenres(JSON.parse(d.prefs?.favoriteGenres||"[]")); }catch{} }catch{} })(); },[]);
  const savePrefs=async()=>{ const r=await fetch("/api/prefs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({favoriteGenres:favGenres})}); setMsg(r.ok?"Preferências salvas.":"Erro ao salvar preferências."); };
  useEffect(()=>{ if(user){ setDisplayName(user.displayName||""); setBio(user.bio||""); setAvatarUrl(user.avatarUrl||""); setHistoryPrivate(!!user.historyPrivate); } },[user]);
  if(user===undefined) return <Loading/>; if(!user) return <div className="p-8 text-center">Faça <Link href="/login" className="underline">login</Link>.</div>;
  const save=async()=>{ const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"update-profile",displayName,bio,avatarUrl,historyPrivate})}); const d=await r.json(); if(r.ok){ setUser(d.user); setMsg("Perfil salvo."); } else setMsg(d.error); };
  const changePass=async()=>{ const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"change-password",current:cur,next})}); const d=await r.json(); setMsg(r.ok?"Senha alterada.":d.error); };
  const logout=async()=>{ await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"logout"})}); setUser(null); router.push("/"); };
  const logoutAll=async()=>{ if(!confirm("Sair de todos os dispositivos? Você precisará entrar de novo neste aparelho também.")) return; await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"logout-all"})}); try{ localStorage.removeItem("sonar_token"); }catch{} setUser(null); router.push("/login"); };
  return <div className="px-4 md:px-8 max-w-2xl mx-auto pt-8"><h1 className="text-3xl font-black">Configurações</h1>
    <div className="mt-6 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-3"><h2 className="font-bold">Perfil</h2>
    <label className="block text-xs text-neutral-400">Nome de exibição<input value={displayName} onChange={e=>setDisplayName(e.target.value)} className="mt-1 w-full bg-black border border-white/15 rounded-xl px-4 py-3 text-white outline-none"/></label>
    <label className="block text-xs text-neutral-400">Foto (URL)<input value={avatarUrl} onChange={e=>setAvatarUrl(e.target.value)} placeholder="https://..." className="mt-1 w-full bg-black border border-white/15 rounded-xl px-4 py-3 text-white outline-none"/></label>
    <label className="block text-xs text-neutral-400">Biografia<textarea value={bio} onChange={e=>setBio(e.target.value)} className="mt-1 w-full bg-black border border-white/15 rounded-xl px-4 py-3 text-white outline-none"/></label>
    <label className="flex gap-2 text-sm items-center"><input type="checkbox" checked={historyPrivate} onChange={e=>setHistoryPrivate(e.target.checked)} className="accent-white"/> Histórico privado (não registrar reproduções)</label>
    <button onClick={save} className="bg-white text-black font-bold px-6 py-2.5 rounded-full text-sm">Salvar perfil</button></div>
    <div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-3"><h2 className="font-bold flex gap-2 items-center"><Lock size={16}/> Alterar senha</h2>
    <input type="password" value={cur} onChange={e=>setCur(e.target.value)} placeholder="Senha atual" className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none"/><input type="password" value={next} onChange={e=>setNext(e.target.value)} placeholder="Nova senha" className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none"/><button onClick={changePass} className="border border-white/30 font-bold px-6 py-2.5 rounded-full text-sm">Alterar senha</button></div>
    
    <div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5"><h2 className="font-bold">Aparência</h2><p className="text-xs text-neutral-400 mt-1">A cor muda na hora em todo o aplicativo e fica salva na sua conta.</p><div className="flex flex-wrap gap-2.5 mt-3">{([["original","SONAR original","#ffffff"],["rosa","Rosa","#f9a8d4"],["verde","Verde","#4ade80"],["azul","Azul","#60a5fa"],["amarelo","Amarelo","#facc15"]] as any[]).map(([k,l,c])=><button key={k} onClick={()=>setTheme(k)} className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-semibold ${theme===k?"bg-white text-black border-white":"border-white/20"}`}><span className="w-4 h-4 rounded-full border border-black/20" style={{background:c}}/>{l}</button>)}</div>
    <h3 className="font-bold mt-6 text-sm">Meus gêneros favoritos</h3><div className="flex flex-wrap gap-2 mt-2.5">{(catalog?.genres||[]).map((g:string)=>{ const on=favGenres.includes(g); return <button key={g} onClick={()=>setFavGenres(on?favGenres.filter(x=>x!==g):[...favGenres,g])} className={`px-4 py-2 rounded-full text-sm font-semibold border ${on?"bg-white text-black border-white":"border-white/20"}`}>{g}</button>; })}</div>
    <button onClick={savePrefs} className="mt-4 border border-white/30 font-bold px-6 py-2.5 rounded-full text-sm">Salvar preferências</button>
    <button onClick={()=>window.dispatchEvent(new Event("sonar:cookies"))} className="ml-2 mt-4 border border-white/30 font-bold px-6 py-2.5 rounded-full text-sm">Cookies e privacidade</button></div>
{msg&&<p className="mt-4 text-sm bg-white text-black px-4 py-2.5 rounded-xl font-semibold">{msg}</p>}
    <div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5"><h2 className="font-bold">Sobre</h2><Link href="/sobre" className="inline-block mt-2 text-sm font-semibold underline underline-offset-4">Sobre o aplicativo</Link><p className="text-xs text-neutral-500 mt-1.5">Conheça a origem do projeto, nossa relação com a comunidade de Avakin Life e o aviso de independência.</p></div>
    <div className="mt-5 flex flex-wrap gap-3"><button onClick={logout} className="border border-white/25 px-6 py-2.5 rounded-full text-sm font-bold flex gap-2"><LogOut size={15}/> Sair da conta</button><button onClick={logoutAll} className="border border-white/25 px-6 py-2.5 rounded-full text-sm font-bold">Sair de todos os dispositivos</button>
    <button onClick={async()=>{ if(confirm("Excluir sua conta permanentemente?")){ await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"delete-account"})}); setUser(null); router.push("/"); } }} className="border border-white/25 px-6 py-2.5 rounded-full text-sm font-bold text-neutral-300">Excluir conta</button></div>
  </div>;
}

export function AuthPage({mode}:{mode:"login"|"register"}){
  const {setUser,catalog}=useApp() as any; const router=useRouter();
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [displayName,setDisplayName]=useState(""); const [err,setErr]=useState("");
  const searchP=useSearchParams();
  const [forgot,setForgot]=useState(false); const [code,setCode]=useState(""); const [newPass,setNewPass]=useState(""); const [note,setNote]=useState(""); const [sent,setSent]=useState(false); const [sending,setSending]=useState(false); const [success,setSuccess]=useState("");
  useEffect(()=>{ const er=searchP.get("erro"); if(er) setErr(er); },[]); // eslint-disable-line
  const submit=async(e:any)=>{ e.preventDefault(); setErr(""); setSuccess(""); const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(mode==="login"?{action:"login",email,password}:{action:"register",email,password,displayName})}); const d=await r.json(); if(!r.ok){ setErr(d.error||"Erro"); return; } setUser(d.user); if(d.token){ try{ localStorage.setItem("sonar_token", d.token); }catch{} } router.push(mode==="register"?"/bem-vindo":"/"); };
  const doForgot=async()=>{ setErr(""); setSuccess(""); setNote(""); setSending(true); try{ const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"forgot",email})}); const d=await r.json().catch(()=>({})); if(!r.ok){ setErr(d.error||"Não foi possível enviar o link agora."); setSent(false); } else { setSent(true); setNote(d.note||"Se este e-mail tiver uma conta, o link foi enviado."); } }catch{ setErr("Erro de conexão. Confira sua internet e tente novamente."); setSent(false); } setSending(false); };
  const doReset=async()=>{ setErr(""); setSuccess(""); const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"reset",email,code,password:newPass})}); const d=await r.json().catch(()=>({})); if(!r.ok) setErr(d.error||"Código inválido ou expirado."); else { setForgot(false); setSent(false); setCode(""); setNewPass(""); setPassword(""); setSuccess("Senha redefinida. Entre com a nova senha."); } };
  const label="mb-1.5 block text-[0.78rem] font-bold text-neutral-400";
  const field="w-full rounded-[0.6rem] border border-white/20 bg-[#181818] px-3.5 py-2.5 text-[0.92rem] text-white outline-none transition focus:border-white placeholder:text-neutral-600";
  const primary="h-11 w-full rounded-full bg-white px-6 text-[0.9rem] font-bold text-black transition hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50";
  const tagline=catalog?.settings?.tagline||"A música que você ouve, as pessoas que você segue.";
  const siteName=(catalog?.settings?.siteName||"Sonar");
  return <div className="relative flex min-h-dvh flex-col items-center overflow-hidden bg-black px-6 py-10 text-white">
    <div className="pointer-events-none absolute -right-32 -top-32 h-[460px] w-[460px] animate-drift rounded-full opacity-60 blur-[80px]" style={{background:"radial-gradient(circle, rgba(255,255,255,0.25), transparent 70%)"}}/>
    <div className="pointer-events-none absolute -bottom-40 -left-32 h-[420px] w-[420px] animate-drift rounded-full opacity-35 blur-[90px]" style={{background:"radial-gradient(circle, rgba(255,255,255,0.2), transparent 70%)",animationDelay:"-7s"}}/>
    <div className="relative flex w-full max-w-[380px] flex-1 flex-col justify-center">
      <div className="mb-8 flex justify-center"><SonarLogo size={48}/></div>
      {!forgot?<>
        <h1 className={`text-center text-[28px] font-extrabold leading-tight tracking-tight ${mode==="register"?"mb-2":"mb-8"}`}>{mode==="login"?tagline:"Criar conta"}</h1>
        {mode==="register"&&<p className="mb-8 text-center text-sm text-neutral-500">Salve músicas, monte playlists e siga artistas e amigos.</p>}
        <form onSubmit={submit} className="space-y-4">
          {mode==="register"&&<div><label className={label} htmlFor="auth-name">Nome de exibição</label><input id="auth-name" required value={displayName} onChange={e=>setDisplayName(e.target.value)} autoComplete="name" className={field}/></div>}
          <div><label className={label} htmlFor="auth-email">E-mail</label><input id="auth-email" required type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" className={field}/></div>
          <div><label className={label} htmlFor="auth-password">Senha</label><input id="auth-password" required type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete={mode==="login"?"current-password":"new-password"} className={field}/></div>
          {err&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm text-neutral-100">{err}</p>}
          {success&&<p role="status" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-neutral-200">{success}</p>}
          <button className={primary}>{mode==="login"?"Entrar":"Criar conta"}</button>
          {mode==="login"
            ? <div className="flex justify-between text-sm text-neutral-500"><button type="button" onClick={()=>{setForgot(true); setErr("");}} className="underline hover:text-white">Esqueci minha senha</button><Link href="/register" className="underline hover:text-white">Criar conta</Link></div>
            : <><p className="text-center text-sm text-neutral-500">Já tem conta? <Link href="/login" className="underline hover:text-white">Entrar</Link></p><p className="text-center text-sm"><Link href="/seja-artista" className="text-neutral-500 underline hover:text-white">Sou artista</Link></p><p className="text-center text-xs"><Link href="/recuperar-conta" className="text-neutral-600 underline hover:text-white">Não consigo acessar meu e-mail</Link></p></>}
        </form>
      </>:<>
        <h1 className="mb-8 text-center text-[28px] font-extrabold leading-tight tracking-tight">Recuperar senha</h1>
        <div className="space-y-4">
          <div><label className={label} htmlFor="recover-email">E-mail da conta</label><input id="recover-email" type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" className={field}/></div>
          {err&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm text-neutral-100">{err}</p>}
          {note&&<p role="status" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-neutral-200">{note}</p>}
          <button type="button" onClick={doForgot} disabled={sending} className={primary}>{sending?"Enviando…":sent?"Reenviar link":"Enviar link seguro"}</button>
          {sent&&<p className="text-xs leading-relaxed text-neutral-500">Abra a mensagem no seu e-mail e toque em <b className="text-neutral-200">Criar nova senha</b>. O link expira em 30 minutos e só funciona uma vez.</p>}
          <p className="text-center text-sm"><Link href="/recuperar-conta" className="text-neutral-500 underline hover:text-white">Não consigo acessar meu e-mail</Link></p><p className="text-center text-sm"><button type="button" onClick={()=>{setForgot(false); setErr("");}} className="text-neutral-500 underline hover:text-white">Voltar para entrar</button></p>
        </div>
      </>}
    </div>
    <footer className="relative mt-10 flex flex-wrap justify-center gap-5 text-xs text-neutral-600">
      <span>© {new Date().getFullYear()} {siteName.toLowerCase()==="sonar"?"Sonar":siteName}</span>
      <Link href="/sobre" className="hover:text-white">Sobre o aplicativo</Link>
      <Link href="/terms" className="hover:text-white">Termos</Link>
      <Link href="/privacy" className="hover:text-white">Privacidade</Link>
    </footer>
  </div>;
}

export function ArtistJoinPage(){
  const {user,setUser,catalog}=useApp() as any; const router=useRouter();
  const [checked,setChecked]=useState(false); const [hasArtist,setHasArtist]=useState(false);
  const [msg,setMsg]=useState(""); const [err,setErr]=useState(""); const [busy,setBusy]=useState(false);
  const [displayName,setDisplayName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [name,setName]=useState(""); const [genre,setGenre]=useState(""); const [bio,setBio]=useState(""); const [imageUrl,setImageUrl]=useState("");
  // Quem já é artista vai direto para a área do artista (sem ver o cadastro de novo)
  useEffect(()=>{ (async()=>{
    if(user===undefined) return;
    if(!user){ setChecked(true); return; }
    try{ const r=await fetch("/api/artist"); const d=await r.json(); if(d.artist){ setHasArtist(true); router.replace("/area-artista"); return; } }catch{}
    setChecked(true);
  })(); },[user]); // eslint-disable-line
  const handleMain=async(e:any)=>{ e.preventDefault(); setErr(""); setMsg(""); setBusy(true);
    try{
      let artistName=name.trim();
      if(!user){
        if(!displayName.trim()||!email.trim()||password.length<6){ setErr("Preencha seu nome, e-mail e uma senha (mínimo 6 caracteres)."); setBusy(false); return; }
        const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"register",displayName,email,password})});
        const d=await r.json(); if(!r.ok){ setErr(d.error||"Erro ao criar a conta."); setBusy(false); return; } setUser(d.user);
        if(d.token){ try{ localStorage.setItem("sonar_token", d.token); }catch{} }
        artistName=displayName.trim();
      }
      if(!artistName){ setErr("Informe seu nome artístico."); setBusy(false); return; }
      const r=await fetch("/api/artist",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"create-artist",name:artistName,genre,bio,imageUrl})});
      const d=await r.json(); if(!r.ok){ setErr(d.error||"Erro ao criar o perfil de artista."); setBusy(false); return; }
      router.push("/area-artista"); // autenticado e encaminhado automaticamente
    }catch{ setErr("Erro de conexão. Verifique sua internet e tente novamente."); }
    setBusy(false);
  };
  const label="mb-1.5 block text-[0.78rem] font-bold text-neutral-400";
  const field="w-full rounded-[0.6rem] border border-white/20 bg-[#181818] px-3.5 py-2.5 text-[0.92rem] text-white outline-none transition focus:border-white placeholder:text-neutral-600";
  const primary="h-11 w-full rounded-full bg-white px-6 text-[0.9rem] font-bold text-black transition hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50";
  const siteName=(catalog?.settings?.siteName||"Sonar");
  const shell=(children:any)=><div className="relative flex min-h-dvh flex-col items-center overflow-hidden bg-black px-6 py-10 text-white">
    <div className="pointer-events-none absolute -right-32 -top-32 h-[460px] w-[460px] animate-drift rounded-full opacity-60 blur-[80px]" style={{background:"radial-gradient(circle, rgba(255,255,255,0.25), transparent 70%)"}}/>
    <div className="pointer-events-none absolute -bottom-40 -left-32 h-[420px] w-[420px] animate-drift rounded-full opacity-35 blur-[90px]" style={{background:"radial-gradient(circle, rgba(255,255,255,0.2), transparent 70%)",animationDelay:"-7s"}}/>
    <div className="relative flex w-full max-w-[380px] flex-1 flex-col justify-center">
      <div className="mb-8 flex justify-center"><SonarLogo size={48}/></div>
      {children}
    </div>
    <footer className="relative mt-10 flex flex-wrap justify-center gap-5 text-xs text-neutral-600">
      <span>© {new Date().getFullYear()} {siteName.toLowerCase()==="sonar"?"Sonar":siteName}</span>
      <Link href="/sobre" className="hover:text-white">Sobre o aplicativo</Link>
      <Link href="/terms" className="hover:text-white">Termos</Link>
      <Link href="/privacy" className="hover:text-white">Privacidade</Link>
    </footer>
  </div>;
  if(user===undefined||!checked) return shell(<p className="text-center text-sm text-neutral-500">Carregando…</p>);
  return shell(<>
    <h1 className="mb-2 text-center text-[28px] font-extrabold leading-tight tracking-tight">Conta de artista</h1>
    <p className="mb-8 text-center text-sm text-neutral-500">{user?"Crie seu perfil para abrir o estúdio.":"Crie sua conta e abra seu estúdio para publicar suas faixas."}</p>
    <form onSubmit={handleMain} className="space-y-4">
      {!user?<>
        <div><label className={label} htmlFor="artist-name">Nome de exibição</label><input id="artist-name" required value={displayName} onChange={e=>setDisplayName(e.target.value)} autoComplete="name" className={field}/></div>
        <div><label className={label} htmlFor="artist-email">E-mail</label><input id="artist-email" required type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" className={field}/></div>
        <div><label className={label} htmlFor="artist-password">Senha</label><input id="artist-password" required type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="new-password" className={field}/></div>
      </>:<>
        <div><label className={label} htmlFor="artist-stage-name">Nome artístico</label><input id="artist-stage-name" required value={name} onChange={e=>setName(e.target.value)} className={field}/></div>
      </>}
      {err&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm text-neutral-100">{err}</p>}
      <button disabled={busy} className={primary}>{busy?"Criando…":user?"Criar perfil de artista":"Criar conta de artista"}</button>
      {!user&&<p className="text-center text-sm text-neutral-500">Já tem conta? <Link href="/login" className="underline hover:text-white">Entrar</Link></p>}
      {user&&<p className="text-center text-sm"><Link href="/area-artista" className="text-neutral-500 underline hover:text-white">Ir para o estúdio</Link></p>}
    </form>
  </>);
}

export function ArtistAreaPage(){
  const {user,refreshCatalog}=useApp() as any; const router=useRouter();
  const [data,setData]=useState<any>(null); const [loading,setLoading]=useState(true); const [msg,setMsg]=useState(""); const [err,setErr]=useState("");
  const [tab,setTab]=useState<"publicar"|"musicas"|"albuns"|"videoclipes"|"perfil">("publicar");
  const [pf,setPf]=useState<any>({name:"",genre:"",imageUrl:"",bio:""});
  const today=new Date().toISOString().slice(0,10);
  const emptyTrack={title:"",audioUrl:"",coverUrl:"",genre:"",duration:0,lyrics:"",lyricsSource:"",albumId:"",featuring:"",releaseDate:today,videoUrl:"",videoThumbnailUrl:""};
  const [tf,setTf]=useState<any>(emptyTrack);
  const [editId,setEditId]=useState<number|null>(null);
  const emptyAlbum={id:null,title:"",coverUrl:"",releaseDate:today,type:"album",genre:""};
  const [af,setAf]=useState<any>(emptyAlbum); const [albumTrackIds,setAlbumTrackIds]=useState<number[]>([]);
  const [videoForm,setVideoForm]=useState<any>({trackId:"",videoUrl:"",videoThumbnailUrl:""});
  const [clipForm,setClipForm]=useState<any>({title:"",audioUrl:"",coverUrl:"",genre:"",duration:0,videoUrl:"",videoThumbnailUrl:""});
  const [generating,setGenerating]=useState(false);
  const input="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none focus:border-white/50 text-sm";
  const load=async()=>{ try{ const r=await fetch("/api/artist"); if(r.status===401){ router.replace("/login"); return; } const d=await r.json(); setData(d); if(d.artist) setPf({name:d.artist.name,genre:d.artist.genre||"",imageUrl:d.artist.imageUrl||"",bio:d.artist.bio||""}); }catch{ setErr("Erro de conexão ao carregar sua área."); } setLoading(false); };
  useEffect(()=>{ load(); },[]); // eslint-disable-line
  if(user===undefined||loading) return <Loading/>;
  if(!user) return <div className="px-4 pt-10 text-center"><h1 className="text-3xl font-black">Área do artista</h1><p className="text-neutral-400 mt-2">Faça login para acessar.</p><Link href="/login" className="inline-block mt-6 bg-white text-black font-bold px-7 py-3 rounded-full">Entrar</Link></div>;
  if(!data?.artist) return <div className="px-4 pt-10 text-center max-w-lg mx-auto"><h1 className="text-3xl font-black">Você ainda não é artista</h1><p className="text-neutral-400 mt-2">Sua conta é de ouvinte. Crie seu perfil de artista para publicar músicas, álbuns e videoclipes.</p><Link href="/seja-artista" className="inline-block mt-6 bg-white text-black font-bold px-7 py-3 rounded-full">Criar perfil de artista</Link></div>;
  const artist=data.artist; const tracks:any[]=data.tracks||[]; const albums:any[]=data.albums||[]; const videos=tracks.filter((t:any)=>t.videoUrl);
  const ai=data.aiLyrics||{}; const statusLabel="PERFIL ATIVO";
  const post=async(action:string,body:any={})=>{ setErr(""); setMsg(""); const r=await fetch("/api/artist",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,...body})}); const d=await r.json().catch(()=>({})); if(!r.ok){ setErr(d.error||"Erro ao salvar."); return null; } setMsg(d.message||"Salvo."); setData((prev:any)=>({...prev,...d,tracks:d.tracks||prev?.tracks,albums:d.albums||prev?.albums,artist:d.artist||prev?.artist})); refreshCatalog(); return d; };
  const resetForm=()=>{ setTf({...emptyTrack,releaseDate:today}); setEditId(null); };
  const submitTrack=async()=>{
    if(!tf.title.trim()){ setErr("Dê um título para a música."); return; }
    if(!tf.audioUrl){ setErr("Envie o arquivo da música (toque em \"Enviar arquivo da música\")."); return; }
    const payload={...tf,albumId:tf.albumId?Number(tf.albumId):null};
    const d=await post(editId?"update-track":"submit-track", editId?{trackId:editId,...payload}:{...payload});
    if(d){ resetForm(); setTab("musicas"); load(); }
  };
  const generateLyrics=async()=>{
    if(!tf.audioUrl){ setErr("Envie primeiro o arquivo de áudio para a IA ouvir a música."); return; }
    setErr(""); setMsg(""); setGenerating(true);
    try{
      const r=await fetch("/api/artist",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"generate-lyrics",audioUrl:tf.audioUrl,language:"pt"})});
      const d=await r.json().catch(()=>({}));
      if(!r.ok){ setErr(d.error||"Não foi possível gerar a letra agora."); return; }
      setTf((prev:any)=>({...prev,lyrics:d.lyrics,lyricsSource:"ai"}));
      setMsg("Letra gerada a partir do áudio. Confira e edite se precisar antes de publicar.");
    }catch{ setErr("Erro de conexão ao gerar a letra. Tente novamente."); }
    setGenerating(false);
  };
  const resetAlbumForm=()=>{ setAf({...emptyAlbum,releaseDate:today}); setAlbumTrackIds([]); };
  const saveAlbum=async()=>{
    if(!af.title.trim()){ setErr("Dê um título ao álbum, EP ou single."); return; }
    const d=await post("save-album",{...af,trackIds:albumTrackIds});
    if(d){ resetAlbumForm(); load(); }
  };
  const editAlbum=(album:any)=>{ setAf({id:album.id,title:album.title,coverUrl:album.coverUrl||"",releaseDate:album.releaseDate||today,type:album.type||"album",genre:album.genre||""}); setAlbumTrackIds(tracks.filter((t:any)=>t.albumId===album.id).map((t:any)=>t.id)); setTab("albuns"); window.scrollTo({top:0,behavior:"smooth"}); };
  const chooseVideoTrack=(track:any)=>{ setVideoForm({trackId:track?.id||"",videoUrl:track?.videoUrl||"",videoThumbnailUrl:track?.videoThumbnailUrl||track?.coverUrl||""}); };
  const publishClipNow=async()=>{
    if(!clipForm.title.trim()){ setErr("Dê um título para o clipe."); return; }
    if(!clipForm.audioUrl){ setErr("Envie o arquivo da música do clipe."); return; }
    if(!clipForm.videoUrl){ setErr("Envie o arquivo do vídeo do clipe."); return; }
    const d=await post("submit-track",{...clipForm,lyrics:"",lyricsSource:""});
    if(d){ setClipForm({title:"",audioUrl:"",coverUrl:"",genre:"",duration:0,videoUrl:"",videoThumbnailUrl:""}); setMsg("Clipe publicado! Ele já está no feed de Clipes."); load(); }
  };
  const saveVideo=async()=>{
    if(!videoForm.trackId){ setErr("Escolha a música do videoclipe."); return; }
    if(!videoForm.videoUrl){ setErr("Envie o arquivo do videoclipe."); return; }
    const d=await post("set-track-video",videoForm);
    if(d){ load(); }
  };
  const tabBtn=(k:any,l:string)=> <button key={k} onClick={()=>setTab(k)} className={`flex-1 sm:flex-none px-5 py-2.5 rounded-full text-sm font-bold whitespace-nowrap ${tab===k?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>{l}</button>;
  return <div className="px-4 md:px-8 max-w-6xl mx-auto pt-6">
    <div className="flex flex-wrap items-center gap-4">
      <span className="w-14 h-14 rounded-full bg-white text-black grid place-items-center font-black text-xl overflow-hidden shrink-0">{artist.imageUrl?<img src={artist.imageUrl} alt="" className="w-full h-full object-cover"/>:artist.name[0]}</span>
      <div className="flex-1 min-w-[180px]"><p className="text-[11px] font-bold tracking-[0.3em] text-neutral-400">ESTÚDIO DO ARTISTA</p><h1 className="text-2xl md:text-3xl font-black truncate">{artist.name}</h1><p className="text-xs text-neutral-400">@{user.username}{artist.genre?` • ${artist.genre}`:""} • Publique músicas, álbuns e videoclipes</p></div>
      <span className="text-[11px] font-black tracking-wider px-3 py-1.5 rounded-full border bg-white text-black border-white">{statusLabel}</span>
      <Link href={`/artist/${artist.id}`} className="border border-white/30 font-bold px-4 py-2 rounded-full text-xs">Ver página pública</Link>
    </div>
    <div className="flex gap-2 mt-5 overflow-x-auto pb-1 scrollbar-none">{tabBtn("publicar", editId?"Editando música":"Publicar música")}{tabBtn("musicas",`Minhas músicas (${tracks.length})`)}{tabBtn("albuns",`Álbuns (${albums.length})`)}{tabBtn("videoclipes",`Videoclipes (${videos.length})`)}{tabBtn("perfil","Meu perfil")}</div>
    {msg&&<p className="mt-4 text-sm bg-white text-black px-4 py-3 rounded-xl font-semibold">{msg}</p>}
    {err&&<p className="mt-4 text-sm border border-white/20 bg-neutral-900 px-4 py-3 rounded-xl">{err}</p>}

    {tab==="publicar"&&<div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-4 max-w-3xl">
      <h2 className="font-bold flex items-center gap-2"><Upload size={16}/> {editId?"Editar música":"Publicar nova música"}</h2>
      <p className="text-xs text-neutral-300 border border-white/15 bg-white/5 rounded-xl px-3.5 py-2.5">Publicação imediata: ao publicar, a música entra no ar na hora e aparece na sua página, na busca e nos charts.</p>

      <div><p className="text-xs font-bold text-neutral-400 mb-2">1. ARQUIVO DA MÚSICA *</p>
      <FileUpload kind="audio" label="Enviar arquivo da música" hint="Toque e escolha o MP3 do seu celular ou computador" value={tf.audioUrl} onChange={(url,dur)=>setTf({...tf,audioUrl:url,duration:dur||tf.duration,lyricsSource:tf.lyricsSource})}/></div>

      <div className="grid sm:grid-cols-2 gap-3">
        <div><p className="text-xs font-bold text-neutral-400 mb-2">2. TÍTULO *</p><input value={tf.title} onChange={e=>setTf({...tf,title:e.target.value})} placeholder="Nome da música" className={input}/></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">PARTICIPAÇÃO (FEAT.)</p><input value={tf.featuring} onChange={e=>setTf({...tf,featuring:e.target.value})} placeholder="Ex.: feat. Outro Artista" className={input}/></div>
      </div>

      <div><p className="text-xs font-bold text-neutral-400 mb-2">3. CAPA (imagem)</p>
      <FileUpload kind="image" label="Enviar capa" hint="Imagem quadrada fica melhor" value={tf.coverUrl} onChange={(url)=>setTf({...tf,coverUrl:url})}/></div>

      <div className="grid sm:grid-cols-3 gap-3">
        <div><p className="text-xs font-bold text-neutral-400 mb-2">GÊNERO</p><GenreSelect value={tf.genre} onChange={v=>setTf({...tf,genre:v})} className={input}/></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">LANÇAMENTO</p><input type="date" value={tf.releaseDate} onChange={e=>setTf({...tf,releaseDate:e.target.value})} className={input}/></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">DURAÇÃO</p><div className="bg-black border border-white/15 rounded-xl px-4 py-3 text-sm text-neutral-300">{tf.duration>0?fmt(tf.duration):"automática"}</div></div>
      </div>

      <div><p className="text-xs font-bold text-neutral-400 mb-2">ÁLBUM / EP (opcional)</p>
        <select value={tf.albumId} onChange={e=>setTf({...tf,albumId:e.target.value})} className={input}><option value="">Música avulsa (sem álbum)</option>{albums.map((album:any)=><option key={album.id} value={album.id}>{album.title} ({album.type})</option>)}</select>
        <p className="text-[11px] text-neutral-500 mt-1.5">Para criar o álbum primeiro, abra a aba Álbuns. Depois volte aqui e vincule as faixas.</p>
      </div>

      <div className="border border-white/10 rounded-2xl p-4 space-y-3 bg-black/40">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex-1 min-w-[220px]"><p className="text-xs font-bold text-neutral-300 flex items-center gap-2"><Sparkles size={14}/> LETRA DA MÚSICA</p>
          <p className="text-[11px] text-neutral-500 mt-1">{ai.configured?`IA pronta (${ai.provider} • ${ai.model}). Ela transcreve os vocais do áudio enviado.`:"IA pendente de configuração no servidor: falta OPENAI_API_KEY. A letra manual continua funcionando."}</p></div>
          <button type="button" onClick={generateLyrics} disabled={!ai.configured||generating||!tf.audioUrl} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-xs disabled:opacity-40">{generating?"Ouvindo o áudio…":"Gerar letra com IA"}</button>
        </div>
        {!ai.configured&&<p className="text-[11px] text-neutral-500">Quando o administrador configurar a chave, este botão passa a gerar a letra real a partir do seu arquivo. Sem a chave, o Sonar não inventa letra.</p>}
        <textarea value={tf.lyrics} onChange={e=>setTf({...tf,lyrics:e.target.value,lyricsSource:tf.lyricsSource==="ai"?"ai":"manual"})} placeholder="A letra gerada aparecerá aqui — ou escreva/cole a letra manualmente" rows={7} className={input}/>
        {tf.lyricsSource==="ai"&&<p className="text-[11px] text-neutral-400">Origem: letra transcrita por IA a partir do áudio. Revise nomes e trechos antes de publicar.</p>}
      </div>

      <div className="border border-white/10 rounded-2xl p-4 space-y-3 bg-black/40">
        <p className="text-xs font-bold text-neutral-300">VIDEOCLIPE (opcional)</p>
        <FileUpload kind="video" label="Enviar videoclipe" hint="MP4, WEBM ou MOV — aparece na música e na sua página" value={tf.videoUrl} onChange={(url)=>setTf({...tf,videoUrl:url})}/>
        {tf.videoUrl&&<><p className="text-xs font-bold text-neutral-400">CAPA DO VÍDEO (opcional)</p><FileUpload kind="image" label="Enviar capa do vídeo" hint="Se não enviar, usa a capa da música" value={tf.videoThumbnailUrl} onChange={(url)=>setTf({...tf,videoThumbnailUrl:url})}/></>}
      </div>

      <div className="flex gap-2 flex-wrap"><button onClick={submitTrack} className="bg-white text-black font-bold px-7 py-3 rounded-full text-sm">{editId?"Salvar alterações":"Publicar música"}</button>{editId&&<button onClick={resetForm} className="border border-white/30 font-bold px-5 py-3 rounded-full text-sm">Cancelar edição</button>}</div>
      <p className="text-[11px] text-neutral-500">Ao publicar, você declara que a música e o vídeo são seus ou que tem autorização para usá-los.</p>
    </div>}

    {tab==="musicas"&&<div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-4 max-w-4xl">
      <h2 className="font-bold px-1">Minhas publicações ({tracks.length})</h2>
      <div className="mt-3 space-y-2">{tracks.length? tracks.map((t:any)=><div key={t.id} className="flex flex-wrap items-center gap-3 bg-black border border-white/10 rounded-xl px-3 py-2.5">
        <img src={t.coverUrl||"/icon.svg"} alt="" className="w-10 h-10 rounded object-cover bg-neutral-800"/>
        <div className="flex-1 min-w-[170px]"><p className="text-sm font-semibold truncate">{t.title}</p><p className="text-xs text-neutral-400">{t.genre||artist.genre||""}{t.albumId?` • ${albums.find((a:any)=>a.id===t.albumId)?.title||"Álbum"}`:" • Avulsa"} • {t.plays} plays{t.videoUrl?" • Videoclipe":""}{t.lyricsSource==="ai"?" • Letra por IA":""}</p></div>
        <span className={`text-[10px] font-black tracking-wider px-2.5 py-1 rounded-full border ${t.published?"bg-white text-black border-white":"border-white/30 text-neutral-300"}`}>{t.published?"NO AR":"FORA DO AR"}</span>
        <Link href={`/track/${t.id}`} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Ver</Link>
        <button onClick={()=>{setEditId(t.id); setTf({title:t.title,audioUrl:t.audioUrl,coverUrl:t.coverUrl||"",genre:t.genre||"",duration:t.duration,lyrics:t.lyrics||"",lyricsSource:t.lyricsSource||"",albumId:t.albumId||"",featuring:t.featuring||"",releaseDate:t.releaseDate||today,videoUrl:t.videoUrl||"",videoThumbnailUrl:t.videoThumbnailUrl||""}); setTab("publicar"); window.scrollTo({top:0,behavior:"smooth"});}} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Editar</button>
        <button onClick={async()=>{ if(confirm("Excluir esta publicação?")) await post("delete-track",{trackId:t.id}); }} className="text-neutral-400 hover:text-white"><Trash2 size={15}/></button>
      </div>):<div className="py-6"><Empty title="Nenhuma música ainda" body="Toque em Publicar música e envie o arquivo da sua primeira faixa."/></div>}</div>
    </div>}

    {tab==="albuns"&&<div className="mt-5 grid lg:grid-cols-[420px,1fr] gap-5 max-w-6xl">
      <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-4 h-fit">
        <h2 className="font-bold flex items-center gap-2"><Disc size={16}/> {af.id?"Editar álbum":"Publicar álbum / EP / single"}</h2>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">TÍTULO *</p><input value={af.title} onChange={e=>setAf({...af,title:e.target.value})} placeholder="Nome do álbum" className={input}/></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">CAPA</p><FileUpload kind="image" label="Enviar capa do álbum" hint="Imagem quadrada fica melhor" value={af.coverUrl} onChange={(url)=>setAf({...af,coverUrl:url})}/></div>
        <div className="grid grid-cols-2 gap-3">
          <div><p className="text-xs font-bold text-neutral-400 mb-2">TIPO</p><select value={af.type} onChange={e=>setAf({...af,type:e.target.value})} className={input}><option value="album">Álbum</option><option value="ep">EP</option><option value="single">Single</option></select></div>
          <div><p className="text-xs font-bold text-neutral-400 mb-2">LANÇAMENTO</p><input type="date" value={af.releaseDate} onChange={e=>setAf({...af,releaseDate:e.target.value})} className={input}/></div>
        </div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">GÊNERO</p><GenreSelect value={af.genre} onChange={v=>setAf({...af,genre:v})} className={input}/></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">MÚSICAS DO ÁLBUM</p>
          {tracks.length?<div className="max-h-56 overflow-auto space-y-1.5 border border-white/10 rounded-xl p-2 bg-black/40">{tracks.map((t:any)=><label key={t.id} className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm hover:bg-white/5 cursor-pointer"><input type="checkbox" checked={albumTrackIds.includes(t.id)} onChange={e=>setAlbumTrackIds(e.target.checked?[...albumTrackIds,t.id]:albumTrackIds.filter((id:number)=>id!==t.id))} className="accent-white"/><span className="flex-1 truncate">{t.title}</span>{t.albumId&&t.albumId!==af.id&&<span className="text-[10px] text-neutral-500">em outro álbum</span>}</label>)}</div>
          :<p className="text-xs text-neutral-500 border border-dashed border-white/15 rounded-xl px-3 py-3">Publique as músicas primeiro na aba Publicar música; depois volte aqui e marque as faixas do álbum.</p>}
        </div>
        <div className="flex gap-2 flex-wrap"><button onClick={saveAlbum} className="bg-white text-black font-bold px-6 py-3 rounded-full text-sm">{af.id?"Salvar álbum":"Publicar álbum"}</button>{af.id&&<button onClick={resetAlbumForm} className="border border-white/30 font-bold px-5 py-3 rounded-full text-sm">Cancelar</button>}</div>
      </div>
      <div className="bg-neutral-900 border border-white/10 rounded-2xl p-4 h-fit">
        <h2 className="font-bold px-1">Meus álbuns ({albums.length})</h2>
        <div className="mt-3 space-y-2">{albums.length? albums.map((album:any)=>{ const count=tracks.filter((t:any)=>t.albumId===album.id).length; return <div key={album.id} className="flex flex-wrap items-center gap-3 bg-black border border-white/10 rounded-xl px-3 py-2.5">
          <img src={album.coverUrl||"/icon.svg"} alt="" className="w-11 h-11 rounded object-cover bg-neutral-800"/>
          <div className="flex-1 min-w-[170px]"><p className="text-sm font-semibold truncate">{album.title}</p><p className="text-xs text-neutral-400 uppercase">{album.type} • {album.releaseDate} • {count} música(s)</p></div>
          <Link href={`/album/${album.id}`} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Ver</Link>
          <button onClick={()=>editAlbum(album)} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Editar</button>
          <button onClick={async()=>{ if(confirm("Excluir este álbum? As músicas serão mantidas como avulsas.")){ await post("delete-album",{albumId:album.id}); resetAlbumForm(); load(); } }} className="text-neutral-400 hover:text-white"><Trash2 size={15}/></button>
        </div>; }):<Empty title="Nenhum álbum ainda" body="Crie um álbum, envie a capa e marque as músicas que fazem parte dele."/>}</div>
      </div>
    </div>}

    {tab==="videoclipes"&&<div className="mt-5 space-y-5 max-w-6xl">
      <div className="bg-white text-black rounded-2xl p-5 space-y-4 max-w-2xl">
        <h2 className="font-black flex items-center gap-2"><Clapperboard size={17}/> Publicar clipe agora (um passo só)</h2>
        <p className="text-xs text-neutral-600 leading-relaxed">Envie a música + o vídeo e publique: o clipe entra na hora no feed de Clipes, em tela cheia, para todo mundo deslizar, curtir e comentar.</p>
        <div><p className="text-xs font-bold text-neutral-500 mb-2">TÍTULO DO CLIPE *</p><input value={clipForm.title} onChange={e=>setClipForm({...clipForm,title:e.target.value})} placeholder="Nome da música/clipe" className="w-full bg-white border border-black/20 rounded-xl px-4 py-3 outline-none focus:border-black text-sm text-black"/></div>
        <div><p className="text-xs font-bold text-neutral-500 mb-2">ARQUIVO DA MÚSICA *</p><FileUpload kind="audio" label="Enviar música" hint="MP3 do seu celular ou computador" value={clipForm.audioUrl} onChange={(url,dur)=>setClipForm({...clipForm,audioUrl:url,duration:dur||clipForm.duration})}/></div>
        <div><p className="text-xs font-bold text-neutral-500 mb-2">ARQUIVO DO VÍDEO *</p><FileUpload kind="video" label="Enviar vídeo do clipe" hint="MP4, WEBM ou MOV — até 100MB" value={clipForm.videoUrl} onChange={(url)=>setClipForm({...clipForm,videoUrl:url})}/></div>
        <div><p className="text-xs font-bold text-neutral-500 mb-2">CAPA (opcional)</p><FileUpload kind="image" label="Enviar capa" hint="Aparece na música e no clipe" value={clipForm.coverUrl} onChange={(url)=>setClipForm({...clipForm,coverUrl:url})}/></div>
        <div><p className="text-xs font-bold text-neutral-500 mb-2">GÊNERO</p><GenreSelect value={clipForm.genre} onChange={v=>setClipForm({...clipForm,genre:v})} className="w-full bg-white border border-black/20 rounded-xl px-4 py-3 outline-none text-sm text-black"/></div>
        <div className="flex gap-2 flex-wrap"><button onClick={publishClipNow} className="bg-black text-white font-bold px-7 py-3 rounded-full text-sm">Publicar clipe</button><Link href="/clipes" className="border border-black/25 font-bold px-6 py-3 rounded-full text-sm">Ver feed de Clipes</Link></div>
      </div>
      <div className="grid lg:grid-cols-[420px,1fr] gap-5">
      <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-4 h-fit">
        <h2 className="font-bold">Vincular clipe a uma música já publicada</h2>
        <p className="text-xs text-neutral-400 leading-relaxed">O videoclipe fica vinculado a uma música sua e aparece na página da música e na sua página de artista.</p>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">MÚSICA *</p><select value={videoForm.trackId} onChange={e=>chooseVideoTrack(tracks.find((t:any)=>t.id===Number(e.target.value)))} className={input}><option value="">Escolha uma música…</option>{tracks.map((t:any)=><option key={t.id} value={t.id}>{t.title}</option>)}</select></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">ARQUIVO DO VIDEOCLIPE *</p><FileUpload kind="video" label="Enviar videoclipe" hint="MP4, WEBM ou MOV — até 100MB" value={videoForm.videoUrl} onChange={(url)=>setVideoForm({...videoForm,videoUrl:url})}/></div>
        <div><p className="text-xs font-bold text-neutral-400 mb-2">CAPA DO VÍDEO</p><FileUpload kind="image" label="Enviar capa do vídeo" hint="Se não enviar, usa a capa da música" value={videoForm.videoThumbnailUrl} onChange={(url)=>setVideoForm({...videoForm,videoThumbnailUrl:url})}/></div>
        <button onClick={saveVideo} className="bg-white text-black font-bold px-6 py-3 rounded-full text-sm">Publicar videoclipe</button>
      </div>
      <div className="bg-neutral-900 border border-white/10 rounded-2xl p-4 h-fit">
        <h2 className="font-bold px-1">Meus videoclipes ({videos.length})</h2>
        <div className="mt-3 grid sm:grid-cols-2 gap-3">{videos.length? videos.map((t:any)=><div key={t.id} className="bg-black border border-white/10 rounded-2xl overflow-hidden">
          <video controls playsInline preload="metadata" poster={t.videoThumbnailUrl||t.coverUrl||undefined} src={t.videoUrl} className="w-full aspect-video bg-black object-contain"/>
          <div className="p-3.5"><p className="text-sm font-semibold truncate">{t.title}</p><p className="text-xs text-neutral-400 truncate">{artist.name}</p>
          <div className="flex gap-2 mt-3"><Link href={`/track/${t.id}`} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Ver música</Link><button onClick={()=>{chooseVideoTrack(t); window.scrollTo({top:0,behavior:"smooth"});}} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Trocar vídeo</button><button onClick={async()=>{ if(confirm("Remover este videoclipe?")) await post("set-track-video",{trackId:t.id,videoUrl:""}); }} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-semibold">Remover</button></div></div>
        </div>):<Empty title="Nenhum videoclipe ainda" body="Escolha uma música publicada e envie o arquivo do clipe."/>}</div>
      </div>
      </div>
    </div>}

    {tab==="perfil"&&<div className="mt-5 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-4 max-w-2xl">
      <h2 className="font-bold flex items-center gap-2"><Edit3 size={16}/> Meu perfil de artista</h2>
      <div><p className="text-xs font-bold text-neutral-400 mb-2">FOTO DE PERFIL</p>
      <FileUpload kind="image" label="Enviar foto" hint="Aparece na sua página de artista" value={pf.imageUrl} onChange={(url)=>setPf({...pf,imageUrl:url})}/></div>
      <div className="grid sm:grid-cols-2 gap-3"><input value={pf.name} onChange={e=>setPf({...pf,name:e.target.value})} placeholder="Nome artístico" className={input}/><GenreSelect value={pf.genre} onChange={v=>setPf({...pf,genre:v})} className={input}/></div>
      <textarea value={pf.bio} onChange={e=>setPf({...pf,bio:e.target.value})} placeholder="Biografia — conte sua história" rows={4} className={input}/>
      <button onClick={()=>post("update-artist",pf)} className="bg-white text-black font-bold px-7 py-3 rounded-full text-sm">Salvar perfil</button>
    </div>}
  </div>;
}

export function AboutPage(){
  const router=useRouter();
  const features=[
    {icon:Music2,t:"Descoberta musical",d:"Página inicial com músicas em alta, lançamentos, playlists editoriais, gêneros e descobertas da semana."},
    {icon:Search,t:"Pesquisa de músicas e artistas",d:"Busque músicas, artistas, álbuns, playlists e pessoas, com filtros e resultados organizados."},
    {icon:Play,t:"Player completo",d:"Reprodução real com fila, modo aleatório, repetição, volume, barra de progresso e tela expandida com letra e créditos."},
    {icon:ListMusic,t:"Playlists",d:"Crie, edite, duplique e compartilhe playlists — públicas, privadas ou colaborativas."},
    {icon:Disc,t:"Biblioteca musical",d:"Álbuns salvos, artistas seguidos e conteúdos recentes, guardados na sua conta em qualquer aparelho."},
    {icon:Heart,t:"Músicas favoritas",d:"Favorite as músicas que você ama e acesse sua coleção quando quiser."},
    {icon:Users,t:"Perfis e comunidade",d:"Perfil próprio, seguidores, descoberta de outros usuários, playlists públicas e notificações."},
    {icon:Mic2,t:"Ferramentas para artistas",d:"Crie seu perfil de artista, tenha uma página pública e publique suas músicas na hora."},
  ];
  return <div className="px-4 md:px-8 max-w-4xl mx-auto pt-8">
    <button onClick={()=>router.back()} className="text-sm font-semibold text-neutral-400 hover:text-white">Voltar</button>
    <p className="text-[11px] font-bold tracking-[0.3em] text-neutral-400 mt-6">SOBRE O APLICATIVO</p>
    <h1 className="text-4xl md:text-5xl font-black tracking-tight mt-3 leading-[1.05]">Música feita pela comunidade, para a comunidade.</h1>
    <p className="text-neutral-400 mt-4 leading-relaxed text-lg max-w-2xl">A SONAR nasceu dentro da comunidade de Avakin Life: um espaço próprio para quem vive a música — ouvindo, descobrindo, compartilhando e criando.</p>

    <section className="mt-12">
      <h2 className="text-2xl font-bold tracking-tight">Sobre o projeto</h2>
      <div className="mt-4 space-y-4 text-neutral-300 leading-relaxed text-[15px]">
        <p>Este aplicativo é um projeto independente, criado por membros da comunidade de Avakin Life para reunir pessoas que compartilham o interesse por música, artistas e experiências musicais.</p>
        <p>Nosso objetivo é oferecer um espaço musical desenvolvido especialmente para a comunidade, permitindo que os usuários descubram músicas, organizem suas playlists e compartilhem seu interesse pela música.</p>
        <p>Acreditamos que a música aproxima pessoas e que a comunidade de Avakin Life também pode ter seu próprio espaço para essa paixão.</p>
      </div>
    </section>

    <section className="mt-10 bg-neutral-900 border border-white/15 border-l-4 border-l-white rounded-3xl p-6 md:p-8">
      <p className="text-[11px] font-bold tracking-[0.3em] text-neutral-400">AVISO IMPORTANTE</p>
      <h2 className="text-2xl md:text-3xl font-black mt-2 flex items-center gap-2.5"><Shield size={24}/> Somos independentes</h2>
      <div className="mt-4 space-y-4 text-neutral-300 leading-relaxed text-[15px]">
        <p>Este aplicativo é um projeto independente, desenvolvido por membros da comunidade de Avakin Life.</p>
        <p>Não somos um aplicativo oficial do Avakin Life e não fazemos parte da equipe responsável pelo desenvolvimento do jogo.</p>
        <p>O Avakin Life é desenvolvido e publicado pela Lockwood Publishing. Não somos representantes da Lockwood Publishing, não temos vínculo oficial com a empresa e não afirmamos possuir seu apoio, autorização ou patrocínio.</p>
        <p>Avakin Life e Lockwood Publishing são nomes pertencentes aos seus respectivos titulares.</p>
        <p>Este projeto é uma iniciativa comunitária e independente, criada para pessoas que compartilham interesses em comum.</p>
      </div>
    </section>

    <section className="mt-12">
      <h2 className="text-2xl font-bold tracking-tight">O que você encontra aqui</h2>
      <p className="text-neutral-400 mt-2 text-[15px]">Somente recursos reais e já disponíveis na plataforma:</p>
      <div className="grid sm:grid-cols-2 gap-3 mt-6">
        {features.map(f=><div key={f.t} className="bg-neutral-900 border border-white/10 rounded-2xl p-5"><f.icon size={20}/><h3 className="font-bold mt-3">{f.t}</h3><p className="text-sm text-neutral-400 mt-1.5 leading-relaxed">{f.d}</p></div>)}
      </div>
    </section>

    <section className="mt-12">
      <h2 className="text-2xl font-bold tracking-tight">Feito para você</h2>
      <div className="grid md:grid-cols-3 gap-3 mt-6">
        <div className="border border-white/10 rounded-2xl p-6"><h3 className="font-bold">Ouvintes</h3><p className="text-sm text-neutral-400 mt-1.5 leading-relaxed">Descubra músicas e artistas, monte sua biblioteca e ouça em qualquer dispositivo.</p></div>
        <div className="border border-white/10 rounded-2xl p-6"><h3 className="font-bold">Artistas</h3><p className="text-sm text-neutral-400 mt-1.5 leading-relaxed">Crie seu perfil, publique suas músicas e seja descoberto pela comunidade.</p></div>
        <div className="border border-white/10 rounded-2xl p-6"><h3 className="font-bold">Comunidade</h3><p className="text-sm text-neutral-400 mt-1.5 leading-relaxed">Siga pessoas, compartilhe playlists públicas e viva a música junto com outros membros.</p></div>
      </div>
    </section>

    <section className="mt-12 mb-4 text-center border border-white/10 rounded-3xl py-12 px-6">
      <h2 className="text-3xl font-black">Faça parte dessa comunidade</h2>
      <p className="text-neutral-400 mt-2">Crie sua conta gratuita ou cadastre-se como artista e comece agora.</p>
      <div className="flex justify-center gap-3 mt-7 flex-wrap"><Link href="/register" className="bg-white text-black font-bold px-7 py-3.5 rounded-full text-sm">Criar conta gratuita</Link><Link href="/seja-artista" className="border border-white/30 font-bold px-7 py-3.5 rounded-full text-sm">Cadastrar como artista</Link></div>
    </section>
    <p className="text-center text-xs text-neutral-600 pb-4">SONAR — Versão 1.0 • Aplicativo web progressivo (PWA): funciona no celular, tablet e computador.</p>
  </div>;
}


export function SupportPage(){
  const {user,catalog}=useApp() as any; const [msgs,setMsgs]=useState<any[]>([]); const [input,setInput]=useState(""); const [convId,setConvId]=useState(""); const [typing,setTyping]=useState(false); const [sending,setSending]=useState(false); const [tickets,setTickets]=useState<any[]>([]); const [showTicket,setShowTicket]=useState(false); const [ticketText,setTicketText]=useState(""); const [ticketMsg,setTicketMsg]=useState("");
  const loadTickets=async()=>{ if(!user) return; try{ const r=await fetch("/api/support?tickets=mine"); const d=await r.json(); setTickets(d.tickets||[]); }catch{} };
  useEffect(()=>{ loadTickets(); },[user]); // eslint-disable-line
  const site=catalog?.settings?.siteName||"SONAR";
  const bottomRef=React.useRef<HTMLDivElement>(null);
  const getConv=()=>{ try{ let c=localStorage.getItem("noir_support_conv"); if(!c){ c="g-"+(crypto.randomUUID?crypto.randomUUID():String(Date.now())); localStorage.setItem("noir_support_conv",c); } return c; }catch{ return "g-visita"; } };
  const fetchMsgs=async()=>{ try{ const c=user? "" : getConv(); const r=await fetch("/api/support"+(c?`?c=${c}`:"")); const d=await r.json(); if(d.conversationId) setConvId(d.conversationId); if(Array.isArray(d.messages)) setMsgs(d.messages); }catch{} };
  useEffect(()=>{ fetchMsgs(); },[user]); // eslint-disable-line
  useEffect(()=>{ const i=setInterval(fetchMsgs, 5000); return ()=>clearInterval(i); },[user]); // eslint-disable-line
  useEffect(()=>{ bottomRef.current?.scrollIntoView({behavior:"smooth"}); },[msgs,typing]);
  const send=async(text?:string)=>{ const body=(text??input).trim(); if(!body||sending) return; setInput(""); setSending(true);
    setMsgs(prev=>[...prev,{id:"tmp-"+Date.now(),sender:"user",body,createdAt:new Date().toISOString()}]);
    try{ const r=await fetch("/api/support",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({body, conversationId: user? undefined : getConv()})}); const d=await r.json();
      if(r.ok&&d.messages){ setTyping(true); setTimeout(()=>{ setMsgs(prev=>[...prev.filter(m=>!String(m.id).startsWith("tmp-")), d.messages[1]]); setTyping(false); fetchMsgs(); }, 900); }
      else fetchMsgs();
    }catch{ fetchMsgs(); }
    setSending(false);
  };
  const chips=["Oi, preciso de ajuda","Esqueci minha senha","Como publico uma música?","Como crio uma playlist?","A SONAR é grátis?","Quero reportar um problema"];
  return <div className="px-4 md:px-8 max-w-3xl mx-auto pt-6 flex flex-col min-h-[70vh]">
    <div className="flex items-center gap-3.5">
      <span className="w-12 h-12 rounded-full bg-white text-black grid place-items-center"><LifeBuoy size={22}/></span>
      <div className="flex-1"><h1 className="text-xl font-black">Equipe de Suporte {site}</h1><p className="text-xs text-neutral-400 flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-white inline-block"/> Equipe de Suporte • responde na hora e abre chamados</p></div>
    </div>
    {!user&&<p className="mt-4 text-xs text-neutral-500 border border-white/10 rounded-xl px-3.5 py-2.5">Você está como visitante. Se o assunto for a sua conta, diga o e-mail dela aqui na conversa para a equipe te localizar.</p>}
    <div className="flex-1 mt-5 space-y-3">
      {msgs.length===0&&<div className="flex gap-2.5"><span className="w-8 h-8 rounded-full bg-white text-black grid place-items-center text-xs font-black shrink-0">S</span><div className="bg-neutral-900 border border-white/10 rounded-2xl rounded-tl-md px-4 py-3 text-sm leading-relaxed max-w-[85%]">Oi! Eu sou o suporte da {site}. Me conta o que você precisa: conta e senha, playlists, publicar música como artista ou qualquer dúvida do app.</div></div>}
      {msgs.map((mm:any)=> mm.sender==="user"
        ? <div key={mm.id} className="flex justify-end"><div className="bg-white text-black rounded-2xl rounded-br-md px-4 py-3 text-sm leading-relaxed max-w-[85%] font-medium">{mm.body}<span className="block text-[10px] opacity-50 mt-1 text-right">{new Date(mm.createdAt).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}</span></div></div>
        : <div key={mm.id} className="flex gap-2.5"><span className="w-8 h-8 rounded-full bg-white text-black grid place-items-center text-xs font-black shrink-0">S</span><div className="bg-neutral-900 border border-white/10 rounded-2xl rounded-tl-md px-4 py-3 text-sm leading-relaxed max-w-[85%]">{mm.body}{Array.isArray(mm.actions)&&mm.actions.length>0&&<span className="flex flex-wrap gap-1.5 mt-2.5">{mm.actions.map((a:any)=><Link key={a.href+a.label} href={a.href} className="bg-white text-black text-xs font-bold px-3 py-1.5 rounded-full">{a.label}</Link>)}</span>}<span className="block text-[10px] text-neutral-500 mt-1">{new Date(mm.createdAt).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})}</span></div></div>)}
      {typing&&<div className="flex gap-2.5"><span className="w-8 h-8 rounded-full bg-white text-black grid place-items-center text-xs font-black shrink-0">S</span><div className="bg-neutral-900 border border-white/10 rounded-2xl rounded-tl-md px-4 py-3.5 flex gap-1"><span className="w-1.5 h-1.5 bg-neutral-400 rounded-full animate-bounce"/><span className="w-1.5 h-1.5 bg-neutral-400 rounded-full animate-bounce" style={{animationDelay:"0.15s"}}/><span className="w-1.5 h-1.5 bg-neutral-400 rounded-full animate-bounce" style={{animationDelay:"0.3s"}}/></div></div>}
      <div ref={bottomRef}/>
    </div>

    <div className="mt-8 border border-white/10 rounded-2xl p-5">
      <div className="flex flex-wrap items-center gap-3"><div className="flex-1 min-w-[180px]"><h2 className="font-bold">Chamados de suporte</h2><p className="text-xs text-neutral-400 mt-0.5">Se o atendimento não resolver, abra um chamado: ele ganha número, status e fica salvo para a equipe.</p></div>
      <button onClick={()=>setShowTicket(!showTicket)} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm">Abrir chamado</button></div>
      {showTicket&&<div className="mt-4 space-y-2.5"><textarea value={ticketText} onChange={e=>setTicketText(e.target.value)} rows={3} placeholder="Descreva o problema com detalhes (o que aconteceu, em qual tela...)" className="w-full bg-black border border-white/15 rounded-xl px-4 py-3 text-sm outline-none focus:border-white/50"/>
      <button onClick={async()=>{ setTicketMsg(""); const r=await fetch("/api/support",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"ticket",description:ticketText,conversationId:convId})}); const d=await r.json(); if(!r.ok){ setTicketMsg(d.error||"Erro ao abrir chamado."); return; } setTicketMsg(`Chamado ${d.ticket.code} aberto! A equipe acompanha por aqui.`); setTicketText(""); setShowTicket(false); loadTickets(); fetchMsgs(); }} className="bg-white text-black font-bold px-6 py-2.5 rounded-full text-sm">Enviar chamado</button>
      {ticketMsg&&<p className="text-sm text-neutral-300">{ticketMsg}</p>}</div>}
      {tickets.length>0&&<div className="mt-4 space-y-2">{tickets.map((t:any)=><div key={t.id} className="flex flex-wrap items-center gap-2.5 bg-black border border-white/10 rounded-xl px-3.5 py-2.5"><span className="text-xs font-black">{t.code}</span><span className="text-sm flex-1 min-w-[160px] truncate">{t.description}</span><span className="text-[10px] text-neutral-500">{new Date(t.createdAt).toLocaleDateString("pt-BR")}</span><span className={`text-[10px] font-black px-2 py-1 rounded-full border ${t.status==="resolved"?"bg-white text-black border-white":"border-white/30"}`}>{t.status==="resolved"?"RESOLVIDO":t.status==="in_progress"?"EM ANDAMENTO":"ABERTO"}</span></div>)}</div>}
      {user&&tickets.length===0&&<p className="text-xs text-neutral-500 mt-3">Você ainda não abriu chamados.</p>}
    </div>
    <div className="sticky bottom-32 md:bottom-24 bg-[#0a0a0a] pt-3 pb-1">
      <div className="flex gap-2 overflow-x-auto pb-2.5 scrollbar-none">{chips.map(c=><button key={c} onClick={()=>send(c)} className="whitespace-nowrap text-xs border border-white/20 rounded-full px-3.5 py-2 font-semibold hover:bg-white hover:text-black transition">{c}</button>)}</div>
      <form onSubmit={e=>{e.preventDefault(); send();}} className="flex gap-2">
        <input value={input} onChange={e=>setInput(e.target.value)} placeholder="Escreva sua mensagem..." className="flex-1 bg-neutral-900 border border-white/15 rounded-full px-5 py-3.5 outline-none focus:border-white/50 text-sm"/>
        <button disabled={sending||!input.trim()} className="w-12 h-12 rounded-full bg-white text-black grid place-items-center disabled:opacity-40 shrink-0"><Send size={18}/></button>
      </form>
      <p className="text-[11px] text-neutral-600 mt-2 text-center">Atendimento da {site}. Suas mensagens ficam salvas e a equipe acompanha por aqui.</p>
    </div>
  </div>;
}

export function AdminSupport(){
  const [convs,setConvs]=useState<any[]>([]); const [sel,setSel]=useState<string>(""); const [thread,setThread]=useState<any[]>([]); const [reply,setReply]=useState(""); const [adminTickets,setAdminTickets]=useState<any[]>([]);
  const loadTicketsAdmin=async()=>{ try{ const r=await fetch("/api/support?tickets=all"); const d=await r.json(); if(d.tickets) setAdminTickets(d.tickets); }catch{} };
  useEffect(()=>{ loadTicketsAdmin(); },[]);
  const loadConvs=async()=>{ try{ const r=await fetch("/api/support?all=1"); const d=await r.json(); if(d.conversations) setConvs(d.conversations); }catch{} };
  const loadThread=async(id:string)=>{ try{ const r=await fetch(`/api/support?conversation=${encodeURIComponent(id)}`); const d=await r.json(); if(d.messages) setThread(d.messages); }catch{} };
  useEffect(()=>{ loadConvs(); const i=setInterval(loadConvs, 15000); return ()=>clearInterval(i); },[]);
  useEffect(()=>{ if(sel) loadThread(sel); },[sel]); // eslint-disable-line
  const sendReply=async()=>{ if(!reply.trim()||!sel) return; await fetch("/api/support",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({conversationId:sel, body:reply.trim()})}); setReply(""); loadThread(sel); loadConvs(); };
  return <div className="grid md:grid-cols-[320px,1fr] gap-4 mt-6">
    <div className="space-y-2 max-h-[560px] overflow-auto">{convs.length? convs.map(c=><button key={c.conversationId} onClick={()=>setSel(c.conversationId)} className={`w-full text-left border rounded-2xl px-4 py-3 ${sel===c.conversationId?"bg-white text-black border-white":"bg-neutral-900 border-white/10"}`}>
      <span className="flex items-center justify-between gap-2"><span className="font-bold text-sm truncate">{c.userName}</span>{c.unread>0&&<span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${sel===c.conversationId?"bg-black text-white":"bg-white text-black"}`}>{c.unread} nova(s)</span>}</span>
      <span className={`block text-xs truncate mt-0.5 ${sel===c.conversationId?"text-neutral-600":"text-neutral-400"}`}>{c.userEmail||"Visitante"} • {c.last}</span></button>)
    : <p className="text-sm text-neutral-500 border border-dashed border-white/15 rounded-2xl p-5">Nenhuma conversa de suporte ainda.</p>}</div>
    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-4 flex flex-col min-h-[420px]">
      {!sel? <p className="text-sm text-neutral-500 m-auto">Selecione uma conversa para responder como Suporte SONAR.</p> :
      <><div className="flex-1 space-y-2.5 overflow-auto max-h-[420px]">{thread.map((mm:any)=><div key={mm.id} className={mm.sender==="user"?"flex justify-start":"flex justify-end"}><div className={`px-3.5 py-2.5 rounded-2xl text-sm max-w-[85%] ${mm.sender==="user"?"bg-black border border-white/10":"bg-white text-black font-medium"}`}>{mm.body}<span className={`block text-[10px] mt-1 ${mm.sender==="user"?"text-neutral-500":"opacity-50"}`}>{mm.sender==="user"?"Usuário":"Suporte"} • {new Date(mm.createdAt).toLocaleString("pt-BR")}</span></div></div>)}</div>
      <div className="flex gap-2 mt-3"><input value={reply} onChange={e=>setReply(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") sendReply(); }} placeholder="Responder como Suporte..." className="flex-1 bg-black border border-white/15 rounded-full px-4 py-3 text-sm outline-none"/><button onClick={sendReply} className="bg-white text-black font-bold px-5 rounded-full text-sm">Enviar</button></div></>}
    </div>

    <div className="mt-4 bg-neutral-900 border border-white/10 rounded-2xl p-4"><h3 className="font-bold text-sm">Chamados ({adminTickets.length})</h3>
      <div className="mt-2.5 space-y-2">{adminTickets.length? adminTickets.map((t:any)=><div key={t.id} className="flex flex-wrap items-center gap-2.5 bg-black border border-white/10 rounded-xl px-3.5 py-2.5">
        <span className="text-xs font-black">{t.code}</span>
        <span className="flex-1 min-w-[180px]"><span className="block text-sm truncate">{t.description}</span><span className="block text-[11px] text-neutral-500">{t.userName} {t.userEmail} • {new Date(t.createdAt).toLocaleString("pt-BR")}</span></span>
        <select value={t.status} onChange={async e=>{ await fetch("/api/support",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"ticket-status",ticketId:t.id,status:e.target.value})}); loadTicketsAdmin(); }} className="bg-neutral-900 border border-white/20 rounded-full px-3 py-1.5 text-xs"><option value="open">Aberto</option><option value="in_progress">Em andamento</option><option value="resolved">Resolvido</option></select>
        {t.conversationId&&<button onClick={()=>setSel(t.conversationId)} className="text-xs border border-white/20 px-3 py-1.5 rounded-full font-bold">Abrir conversa</button>}
      </div>):<p className="text-sm text-neutral-500">Nenhum chamado aberto pelos usuários.</p>}</div></div>
  </div>;
}


export function BemVindoPage(){
  const {user,catalog,setTheme,theme,refreshLibrary}=useApp() as any; const router=useRouter();
  const [genres,setGenres]=useState<string[]>([]); const [picked,setPicked]=useState<number[]>([]);
  const allGenres:string[]=catalog?.genres||[]; const artists:any[]=catalog?.artists||[];
  if(user===undefined) return <Loading/>;
  if(!user) return <div className="px-4 pt-10 text-center"><h1 className="text-3xl font-black">Bem-vindo(a) à SONAR</h1><p className="text-neutral-400 mt-2">Crie sua conta para personalizar sua experiência.</p><Link href="/register" className="inline-block mt-6 bg-white text-black font-bold px-7 py-3 rounded-full">Criar conta</Link></div>;
  const toggleGenre=(g:string)=>setGenres(prev=>prev.includes(g)?prev.filter(x=>x!==g):[...prev,g]);
  const toggleArtist=(id:number)=>setPicked(prev=>prev.includes(id)?prev.filter(x=>x!==id):[...prev,id]);
  const finish=async(skip:boolean)=>{
    if(!skip){
      try{ await fetch("/api/prefs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({favoriteGenres:genres, onboardingDone:true})}); }catch{}
      for(const id of picked){ try{ await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"toggle-follow-artist",artistId:id})}); }catch{} }
      refreshLibrary();
    } else { try{ await fetch("/api/prefs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({onboardingDone:true})}); }catch{} }
    router.push("/");
  };
  const themes=[["original","SONAR original","#ffffff"],["rosa","Rosa","#f9a8d4"],["verde","Verde","#4ade80"],["azul","Azul","#60a5fa"],["amarelo","Amarelo","#facc15"]];
  return <div className="px-4 md:px-8 max-w-3xl mx-auto pt-8">
    <p className="text-[11px] font-bold tracking-[0.3em] text-neutral-400">BEM-VINDO(A){user?.displayName?`, ${String(user.displayName).split(" ")[0].toUpperCase()}`:""}</p>
    <h1 className="text-4xl md:text-5xl font-black tracking-tight mt-3">Do seu jeito, em 30 segundos.</h1>
    <p className="text-neutral-400 mt-3">Tudo aqui é opcional — pule quando quiser. Suas escolhas ficam salvas e você muda depois em Configurações.</p>
    <div className="mt-8 bg-neutral-900 border border-white/10 rounded-2xl p-5"><h2 className="font-bold">1. Quais sons você curte?</h2><div className="flex flex-wrap gap-2 mt-3">{allGenres.length?allGenres.map(g=><button key={g} onClick={()=>toggleGenre(g)} className={`px-4 py-2 rounded-full text-sm font-semibold border ${genres.includes(g)?"bg-white text-black border-white":"border-white/20"}`}>{g}</button>):<p className="text-sm text-neutral-500">Catálogo de gêneros carregando...</p>}</div></div>
    <div className="mt-4 bg-neutral-900 border border-white/10 rounded-2xl p-5"><h2 className="font-bold">2. Artistas para seguir agora</h2><div className="grid grid-cols-3 sm:grid-cols-6 gap-3 mt-4">{artists.map(a=><button key={a.id} onClick={()=>toggleArtist(a.id)} className={`text-center group`}><span className={`block rounded-full p-0.5 border-2 ${picked.includes(a.id)?"border-white":"border-transparent"}`}><img src={a.imageUrl} alt="" className="w-full aspect-square object-cover rounded-full bg-neutral-800"/></span><span className="block text-xs font-semibold mt-1.5 truncate">{a.name}</span><span className="text-[10px] text-neutral-500">{picked.includes(a.id)?"Seguindo":"Seguir"}</span></button>)}</div></div>
    <div className="mt-4 bg-neutral-900 border border-white/10 rounded-2xl p-5"><h2 className="font-bold">3. Cor do aplicativo</h2><div className="flex flex-wrap gap-2.5 mt-3">{themes.map(([k,l,c])=><button key={k} onClick={()=>setTheme(k)} className={`flex items-center gap-2 px-4 py-2.5 rounded-full border text-sm font-semibold ${theme===k?"bg-white text-black border-white":"border-white/20"}`}><span className="w-4 h-4 rounded-full border border-black/20" style={{background:c}}/>{l}</button>)}</div></div>
    <div className="flex flex-wrap gap-3 mt-7"><button onClick={()=>finish(false)} className="bg-white text-black font-bold px-8 py-3.5 rounded-full text-sm">Entrar na SONAR</button><button onClick={()=>finish(true)} className="border border-white/30 font-bold px-8 py-3.5 rounded-full text-sm">Pular por agora</button></div>
  </div>;
}

export function ChartsPage(){
  const {play,catalog}=useApp() as any; const [tab,setTab]=useState("tracks"); const [genre,setGenre]=useState(""); const [data,setData]=useState<any>(null); const [loading,setLoading]=useState(true); const [failed,setFailed]=useState(false); const [reloadKey,setReloadKey]=useState(0);
  useEffect(()=>{ (async()=>{ setLoading(true); setFailed(false); try{ const r=await fetch("/api/charts"+(genre?`?genre=${encodeURIComponent(genre)}`:"")); if(!r.ok) throw new Error("charts"); setData(await r.json()); }catch{ setFailed(true); } setLoading(false); })(); },[genre,reloadKey]);
  const {AlbumCard}=Cards();
  const queue=(data?.tracks||[]).map((r:any)=>r.track);
  const albums=[...(catalog?.albums||[])].sort((a:any,b:any)=>String(b.releaseDate).localeCompare(String(a.releaseDate))).slice(0,10);
  const updated=data?.updatedAt? new Date(data.updatedAt).toLocaleString("pt-BR") : "";
  const Change=({c,isNew}:{c:any,isNew:any})=> isNew||c===null||c===undefined? <span className="text-[10px] font-black px-2 py-1 rounded-full border border-white/25">NOVO</span> : c>0? <span className="text-xs font-black">▲ {c}</span> : c<0? <span className="text-xs font-black text-neutral-500">▼ {Math.abs(c)}</span> : <span className="text-xs text-neutral-500">—</span>;
  return <div className="px-4 md:px-8 max-w-[1100px] mx-auto pt-6">
    <p className="text-[11px] font-bold tracking-[0.3em] text-neutral-400">SONAR CHARTS</p>
    <h1 className="text-4xl md:text-5xl font-black tracking-tight mt-2">Charts</h1>
    <p className="text-sm text-neutral-400 mt-2 max-w-2xl">{data?.methodology||"Ranking calculado pelas reproduções registradas na SONAR."}{data?.previousDate?` Comparado com o registro de ${data.previousDate}.`:" A variação de posições aparece a partir do segundo dia de registros."}{updated?` Atualizado em ${updated}.`:""}</p>
    <div className="flex flex-wrap gap-2 mt-6">
      <button onClick={()=>setTab("tracks")} className={`px-5 py-2.5 rounded-full text-sm font-bold ${tab==="tracks"?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>Músicas</button>
      <button onClick={()=>setTab("artists")} className={`px-5 py-2.5 rounded-full text-sm font-bold ${tab==="artists"?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>Artistas</button>
      <button onClick={()=>setTab("releases")} className={`px-5 py-2.5 rounded-full text-sm font-bold ${tab==="releases"?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>Lançamentos</button>
      <select value={genre} onChange={e=>setGenre(e.target.value)} className="bg-neutral-900 border border-white/10 rounded-full px-4 py-2.5 text-sm ml-auto"><option value="">Todos os gêneros</option>{(data?.genres||[]).map((g:string)=><option key={g} value={g}>{g}</option>)}</select>
    </div>
    {loading&&<Loading/>}
    {!loading&&failed&&<div className="mt-8"><Empty title="Não foi possível carregar os Charts" body="Verifique sua conexão e tente novamente."/><button onClick={()=>setReloadKey(reloadKey+1)} className="mt-4 bg-white text-black font-bold px-6 py-3 rounded-full text-sm">Tentar novamente</button></div>}
    {!loading&&!failed&&data&&tab==="tracks"&&<>
      {queue.length>0&&<div className="mt-6"><PlayAllButton tracks={queue} label="Ouvir o Top da SONAR"/></div>}
      <div className="mt-5 bg-neutral-900/60 border border-white/10 rounded-2xl p-2">
      {data.tracks.length? data.tracks.map((r:any)=>{ const t=r.track; return <div key={t.id} className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5">
        <span className="w-9 text-center shrink-0"><span className="block text-lg font-black leading-none">{r.position}</span><span className="block text-[10px] text-neutral-500">{r.previousPosition?`antes: ${r.previousPosition}`:"estreia"}</span></span>
        <button onClick={()=>play(t,queue)} className="shrink-0"><img src={t.coverUrl||"/icon.svg"} alt="" className="w-11 h-11 rounded object-cover bg-neutral-800"/></button>
        <div className="flex-1 min-w-0"><Link href={`/track/${t.id}`} className="block text-sm font-semibold truncate hover:underline">{t.title}</Link><Link href={`/artist/${t.artistId}`} className="block text-xs text-neutral-400 truncate hover:text-white">{t.artist?.name}</Link></div>
        <span className="hidden sm:block text-xs text-neutral-500">{(t.plays/1000).toFixed(0)}k plays</span>
        <Change c={r.change} isNew={r.isNew}/></div>; })
      : <Empty title="Sem dados suficientes" body="Ainda não há reproduções registradas para montar este ranking. Ouça músicas e volte amanhã."/>}
      </div></>}
    {!loading&&!failed&&data&&tab==="artists"&&<div className="mt-6 space-y-2">
      {data.artists.length? data.artists.map((r:any)=><Link key={r.artist.id} href={`/artist/${r.artist.id}`} className="flex items-center gap-3 bg-neutral-900/60 border border-white/10 rounded-2xl px-4 py-3 hover:bg-neutral-900">
        <span className="w-9 text-center shrink-0"><span className="block text-lg font-black leading-none">{r.position}</span><span className="block text-[10px] text-neutral-500">{r.previousPosition?`antes: ${r.previousPosition}`:"estreia"}</span></span>
        <img src={r.artist.imageUrl} alt="" className="w-11 h-11 rounded-full object-cover bg-neutral-800"/>
        <span className="flex-1 min-w-0"><span className="block text-sm font-semibold truncate">{r.artist.name}</span><span className="block text-xs text-neutral-400">{r.artist.genre} • {(r.plays/1000).toFixed(0)}k plays somados</span></span>
        <Change c={r.change} isNew={r.isNew}/></Link>)
      : <Empty title="Sem dados suficientes" body="O ranking de artistas aparece quando houver reproduções registradas."/>}
    </div>}
    {!loading&&tab==="releases"&&<>{albums.length? <RowScroll>{albums.map((a:any)=><AlbumCard key={a.id} a={a}/>)}</RowScroll> : <div className="mt-6"><Empty title="Sem lançamentos" body="Os lançamentos dos artistas aparecerão aqui."/></div>}</>}
    {data?.history?.length>0&&<p className="text-xs text-neutral-600 mt-5">Registros de charts: {data.history.join(" • ")}</p>}
    <p className="text-xs text-neutral-600 mt-2">Toque em qualquer música para ouvir na hora, ou abra o artista/álbum para ver tudo.</p>
  </div>;
}



export function DeployGitHubPage(){
  const [owner,setOwner]=useState(""); const [repo,setRepo]=useState(""); const [token,setToken]=useState("");
  const [logs,setLogs]=useState<string[]>([]); const [busy,setBusy]=useState(false); const [done,setDone]=useState(false);
  const input="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none focus:border-white/50 text-sm";
  const log=(m:string)=>setLogs(prev=>[...prev.slice(-14),m]);
  const gh=async(path:string,options:any={})=>{ const r=await fetch("https://api.github.com"+path,{...options,headers:{Authorization:"Bearer "+token.trim(),Accept:"application/vnd.github+json","Content-Type":"application/json",...(options.headers||{})}}); if(!r.ok){ const t=await r.text(); throw new Error("GitHub respondeu "+r.status+": "+t.slice(0,120)); } return r.status===204?null:r.json(); };
  const run=async()=>{ setDone(false); setLogs([]);
    if(!owner.trim()||!repo.trim()||!token.trim()){ log("Preencha usuário, repositório e a chave do GitHub."); return; }
    setBusy(true);
    try{
      log("1/5 Baixando o pacote do código...");
      const zr=await fetch("/sonar-codigo-fonte.zip"); if(!zr.ok) throw new Error("Pacote não encontrado neste link.");
      const zip=await JSZip.loadAsync(await zr.arrayBuffer());
      const paths=Object.keys(zip.files).filter(x=>!zip.files[x].dir&&x.startsWith("sonar/")).map(x=>x.slice(6));
      log(`Pacote OK: ${paths.length} arquivos.`);
      log("2/5 Conferindo o repositório...");
      const info=await gh(`/repos/${owner.trim()}/${repo.trim()}`); const branch=info.default_branch||"main";
      let baseSha="",baseTree="";
      try{ const ref=await gh(`/repos/${owner.trim()}/${repo.trim()}/git/ref/heads/${branch}`); baseSha=ref.object.sha; const c=await gh(`/repos/${owner.trim()}/${repo.trim()}/git/commits/${baseSha}`); baseTree=c.tree.sha; }catch{ log("Repositório vazio: criando o primeiro envio."); }
      log("3/5 Enviando arquivos...");
      const treeItems:any[]=[]; let i=0;
      for(const path of paths){ i++; const content=await zip.file("sonar/"+path)!.async("base64"); const blob=await gh(`/repos/${owner.trim()}/${repo.trim()}/git/blobs`,{method:"POST",body:JSON.stringify({content,encoding:"base64"})}); treeItems.push({path,mode:"100644",type:"blob",sha:blob.sha}); if(i%10===0||i===paths.length) log(`   ${i}/${paths.length} arquivos...`); }
      log("4/5 Montando a versão final...");
      const tree=await gh(`/repos/${owner.trim()}/${repo.trim()}/git/trees`,{method:"POST",body:JSON.stringify({tree:treeItems,...(baseTree?{base_tree:baseTree}:{})})});
      const commit=await gh(`/repos/${owner.trim()}/${repo.trim()}/git/commits`,{method:"POST",body:JSON.stringify({message:"SONAR - atualização completa",tree:tree.sha,parents:baseSha?[baseSha]:[]})});
      if(baseSha) await gh(`/repos/${owner.trim()}/${repo.trim()}/git/refs/heads/${branch}`,{method:"PATCH",body:JSON.stringify({sha:commit.sha})});
      else await gh(`/repos/${owner.trim()}/${repo.trim()}/git/refs`,{method:"POST",body:JSON.stringify({ref:`refs/heads/${branch}`,sha:commit.sha})});
      log("5/5 Pronto! Código publicado no GitHub."); setDone(true);
    }catch(e:any){ log("ERRO: "+(e?.message||"falha de conexão")); }
    setBusy(false);
  };
  return <div className="px-4 md:px-8 max-w-2xl mx-auto pt-8">
    <p className="text-[11px] font-bold tracking-[0.3em] text-neutral-400">PUBLICAR O APLICATIVO</p>
    <h1 className="text-4xl font-black tracking-tight mt-3">Enviar o código para o GitHub</h1>
    <p className="text-neutral-400 mt-3">Pelo celular, sem computador e sem extrair ZIP. Crie a chave, preencha os 3 campos e toque em enviar.</p>
    <div className="mt-6 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-3 text-sm">
      <p><b>Passo 1 — Criar a chave:</b> login no GitHub, nome SONAR, desça e toque em Generate token. Copie a chave <b>ghp_</b>.</p>
      <a href="https://github.com/settings/tokens/new?scopes=repo&description=SONAR" target="_blank" rel="noreferrer" className="inline-block bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm">Criar chave no GitHub</a>
      <p className="text-xs text-neutral-500">Não compartilhe a chave. Ela é usada só no seu navegador, direto com o GitHub.</p>
    </div>
    <div className="mt-4 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-3">
      <p className="font-bold text-sm">Passo 2 — Enviar</p>
      <input value={owner} onChange={e=>setOwner(e.target.value)} placeholder="Seu usuário do GitHub" className={input} autoCapitalize="none"/>
      <input value={repo} onChange={e=>setRepo(e.target.value)} placeholder="Nome do repositório (ex: sonar)" className={input} autoCapitalize="none"/>
      <input value={token} onChange={e=>setToken(e.target.value)} placeholder="Cole a chave (ghp_...)" className={input} autoCapitalize="none"/>
      <button onClick={run} disabled={busy} className="w-full bg-white text-black font-bold py-3.5 rounded-full text-sm disabled:opacity-50">{busy?"Enviando... aguarde":"Enviar código para o GitHub"}</button>
      {logs.length>0&&<div className="bg-black border border-white/10 rounded-xl p-3.5 text-xs font-mono space-y-1 max-h-52 overflow-auto">{logs.map((l,i)=><p key={i}>{l}</p>)}</div>}
      {done&&<a href="https://vercel.com/new" target="_blank" rel="noreferrer" className="block bg-white text-black font-bold px-5 py-3 rounded-full text-center text-sm">Abrir a Vercel para publicar</a>}
    </div>
  </div>;
}

export function AdminStudio(){
  const {catalog}=useApp() as any; const app=useApp() as any;
  const site=(catalog?.settings?.siteName||"SONAR");
  const tracks:Track[]=catalog?.tracks||[]; const artists:any[]=catalog?.artists||[]; const albums:any[]=catalog?.albums||[];
  const [kind,setKind]=useState("musica"); const [format,setFormat]=useState<"stories"|"feed">("stories");
  const [trackId,setTrackId]=useState<number>(0); const [artistId,setArtistId]=useState<number>(0); const [albumId,setAlbumId]=useState<number>(0);
  const [chartGenre,setChartGenre]=useState(""); const [chartSource,setChartSource]=useState("tracks");
  const [prompt,setPrompt]=useState(""); const [version,setVersion]=useState(0);
  const [img,setImg]=useState(""); const [busy,setBusy]=useState(false); const [note,setNote]=useState("");
  useEffect(()=>{ if(!trackId&&tracks[0]) setTrackId(tracks[0].id); if(!artistId&&artists[0]) setArtistId(artists[0].id); if(!albumId&&albums[0]) setAlbumId(albums[0].id); },[tracks,artists,albums]); // eslint-disable-line
  const input="w-full bg-black border border-white/15 rounded-xl px-4 py-3 outline-none focus:border-white/50 text-sm";
  const presets=[["Elegante","arte elegante, sofisticada, premium"],["Impactante","arte impactante, dramática, forte"],["Minimalista","arte minimalista, limpa, simples"],["Dramática","arte dramática, intensa, cinematográfica"]];
  const generate=async(v=version)=>{
    setBusy(true); setNote("");
    try{
      let spec:any=null;
      if(kind==="musica"){ const t=tracks.find(x=>x.id===trackId)||tracks[0]; if(!t) throw new Error("Nenhuma música cadastrada."); spec={format,kindLabel:"DIVULGAÇÃO DE MÚSICA",title:t.title,subtitle:t.artist?.name||"",coverUrl:t.coverUrl||"",path:`/track/${t.id}`,styleText:prompt,version:v,siteName:site}; }
      else if(kind==="artista"){ const a=artists.find((x:any)=>x.id===artistId)||artists[0]; if(!a) throw new Error("Nenhum artista cadastrado."); spec={format,kindLabel:"ARTISTA EM DESTAQUE",title:a.name,subtitle:`${a.genre||""} • ${(a.monthlyListeners/1000).toFixed(0)}k ouvintes/mês`,coverUrl:a.imageUrl||"",path:`/artist/${a.id}`,styleText:prompt,version:v,siteName:site}; }
      else if(kind==="lancamento"){ const a=albums.find((x:any)=>x.id===albumId)||albums[0]; if(!a) throw new Error("Nenhum lançamento cadastrado."); spec={format,kindLabel:"LANÇAMENTO",title:a.title,subtitle:`${a.artist?.name||""} • ${a.releaseDate||""}`,coverUrl:a.coverUrl||"",path:`/album/${a.id}`,styleText:prompt,version:v,siteName:site}; }
      else {
        const r=await fetch("/api/charts"+(chartGenre?`?genre=${encodeURIComponent(chartGenre)}`:"")); if(!r.ok) throw new Error("Não foi possível carregar os charts agora."); const d=await r.json();
        if(chartSource==="artists"){
          const items=(d.artists||[]).slice(0,10).map((x:any)=>({position:x.position,title:x.artist?.name||"",artist:`${(x.plays/1000).toFixed(0)}k plays somados`,coverUrl:x.artist?.imageUrl||"",change:x.change,isNew:x.isNew}));
          if(!items.length) throw new Error("Sem dados de artistas suficientes para este chart.");
          spec={format,kindLabel:"CHART DE ARTISTAS",title:chartGenre?`TOP 10 ARTISTAS • ${chartGenre.toUpperCase()}`:"TOP 10 ARTISTAS",subtitle:"Ranking real por reproduções somadas",coverUrl:items[0].coverUrl,path:"/charts",chartItems:items,styleText:prompt,version:v,siteName:site};
        } else {
          const items=(d.tracks||[]).slice(0,10).map((x:any)=>({position:x.position,title:x.track.title,artist:x.track.artist?.name||"",coverUrl:x.track.coverUrl||"",change:x.change,isNew:x.isNew}));
          if(!items.length) throw new Error("Sem dados de músicas suficientes para este chart.");
          spec={format,kindLabel:kind==="top10"?"TOP 10 OFICIAL":"CHART DE MÚSICAS",title:chartGenre?`TOP 10 • ${chartGenre.toUpperCase()}`:"TOP 10 SONAR",subtitle:"Ranking real por reproduções registradas",coverUrl:items[0].coverUrl,path:"/charts",chartItems:items,styleText:prompt,version:v,siteName:site};
        }
      }
      const out=await generatePromoArt(spec); setImg(URL.createObjectURL(dataUrlToBlob(out))); setVersion(v);
    }catch(e:any){ setNote(e?.message||"Erro ao gerar a arte."); setImg(""); }
    setBusy(false);
  };
  const another=()=>{ const v=version+1; setVersion(v); generate(v); };
  const download=()=>{ if(!img) return; const a=document.createElement("a"); a.href=img; a.download=`sonar-studio-${kind}-${format}-v${version}.png`; document.body.appendChild(a); a.click(); a.remove(); setNote("Imagem baixada em alta qualidade."); };
  const shareFile=async()=>{ if(!img) return; const file=new File([await (await fetch(img)).blob()],`sonar-studio-${format}.png`,{type:"image/png"}); const nav:any=navigator; if(nav.canShare&&nav.canShare({files:[file]})){ try{ await nav.share({files:[file],title:"Arte SONAR"}); return; }catch(e:any){ if(e?.name!=="AbortError") setNote("Não foi possível abrir o compartilhamento agora."); return; } } setNote("Compartilhamento direto indisponível neste aparelho — use Baixar em alta."); };
  return <div className="grid lg:grid-cols-[400px,1fr] gap-5 mt-6">
    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-4 h-fit">
      <div><h3 className="font-black text-lg">Admin Studio</h3><p className="text-xs text-neutral-400 mt-1">Assistente de artes com os dados reais da {site}. Escolha o conteúdo, o formato e o estilo.</p></div>
      <div><p className="text-xs font-bold text-neutral-400 mb-2">TIPO DE CONTEÚDO</p><div className="grid grid-cols-2 gap-2">{[["musica","Divulgação de música"],["artista","Divulgação de artista"],["lancamento","Lançamento"],["top10","TOP 10"],["chart","Chart específico"]].map(([k,l])=><button key={k} onClick={()=>setKind(k)} className={`px-3 py-2.5 rounded-xl border text-xs font-bold ${kind===k?"bg-white text-black border-white":"border-white/15"}`}>{l}</button>)}</div></div>
      {kind==="musica"&&<select value={trackId} onChange={e=>setTrackId(+e.target.value)} className={input}>{tracks.map(t=><option key={t.id} value={t.id}>{t.title} — {t.artist?.name}</option>)}</select>}
      {kind==="artista"&&<select value={artistId} onChange={e=>setArtistId(+e.target.value)} className={input}>{artists.map((a:any)=><option key={a.id} value={a.id}>{a.name}</option>)}</select>}
      {kind==="lancamento"&&<select value={albumId} onChange={e=>setAlbumId(+e.target.value)} className={input}>{albums.map((a:any)=><option key={a.id} value={a.id}>{a.title} — {a.artist?.name}</option>)}</select>}
      {(kind==="top10"||kind==="chart")&&<div className="space-y-2"><GenreSelect value={chartGenre} onChange={setChartGenre} className={input}/>{kind==="chart"&&<select value={chartSource} onChange={e=>setChartSource(e.target.value)} className={input}><option value="tracks">Ranking de músicas</option><option value="artists">Ranking de artistas</option></select>}<p className="text-[11px] text-neutral-500">Em branco = chart geral. As posições vêm do ranking real; nada é inventado.</p></div>}
      <div><p className="text-xs font-bold text-neutral-400 mb-2">FORMATO</p><div className="grid grid-cols-2 gap-2"><button onClick={()=>{setFormat("stories"); if(img) setTimeout(()=>generate(version),50);}} className={`px-3 py-3 rounded-xl border text-sm font-bold ${format==="stories"?"bg-white text-black border-white":"border-white/15"}`}>Stories 9:16</button><button onClick={()=>{setFormat("feed"); if(img) setTimeout(()=>generate(version),50);}} className={`px-3 py-3 rounded-xl border text-sm font-bold ${format==="feed"?"bg-white text-black border-white":"border-white/15"}`}>Feed 4:5</button></div></div>
      <div><p className="text-xs font-bold text-neutral-400 mb-2">INSTRUÇÕES DE ESTILO</p><div className="flex flex-wrap gap-1.5 mb-2">{presets.map(([l,v])=><button key={l} onClick={()=>setPrompt(v)} className="text-xs border border-white/20 rounded-full px-3 py-1.5 font-semibold">{l}</button>)}</div>
      <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={3} placeholder="Ex: arte elegante, dramática, com presença forte da capa..." className={input}/><p className="text-[11px] text-neutral-500 mt-1.5">O estilo muda a composição — nunca os nomes, capas ou posições reais.</p></div>
      <button onClick={()=>generate()} disabled={busy} className="w-full bg-white text-black font-black py-3.5 rounded-full text-sm disabled:opacity-50">{busy?"Gerando arte...":"Gerar arte"}</button>
      {note&&<p className="text-xs border border-white/15 rounded-xl px-3 py-2.5 text-neutral-200">{note}</p>}
    </div>
    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5">
      <div className="flex flex-wrap items-center gap-2"><h3 className="font-black flex-1">Prévia</h3><span className="text-[11px] border border-white/20 rounded-full px-3 py-1 font-bold">{format==="stories"?"STORIES 9:16 • 1080×1920":"FEED 4:5 • 1080×1350"}</span>{img&&<span className="text-[11px] border border-white/20 rounded-full px-3 py-1 font-bold">VERSÃO {version}</span>}</div>
      <div className="mt-4 rounded-2xl overflow-hidden border border-white/10 bg-black grid place-items-center min-h-[420px] max-w-[430px] mx-auto w-full">
        {busy? <p className="text-sm text-neutral-500 py-24">Criando composição...</p> : img? <img src={img} alt="Arte gerada no Admin Studio" className="w-full"/> : <p className="text-sm text-neutral-500 py-24 px-6 text-center">Escolha o conteúdo ao lado e toque em "Gerar arte".</p>}
      </div>
      {img&&<div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
        <button onClick={download} className="bg-white text-black font-bold py-3 rounded-full text-xs">Baixar em alta</button>
        <button onClick={another} className="border border-white/30 font-bold py-3 rounded-full text-xs">Gerar outra versão</button>
        <button onClick={()=>setFormat("stories")} className="border border-white/30 font-bold py-3 rounded-full text-xs">Ver Stories 9:16</button>
        <button onClick={()=>setFormat("feed")} className="border border-white/30 font-bold py-3 rounded-full text-xs">Ver Feed 4:5</button>
      </div>}
      <p className="text-[11px] text-neutral-500 mt-3">* Stories/Feed: o app prepara e baixa/compartilha a arte; a postagem final é concluída por você no Instagram/WhatsApp. Nada é marcado como publicado automaticamente.</p>
    </div>
  </div>;
}


export function ResetPasswordPage(){
  const router=useRouter(); const params=useSearchParams();
  const token=params.get("token")||"";
  const [password,setPassword]=useState(""); const [confirm,setConfirm]=useState(""); const [err,setErr]=useState(""); const [ok,setOk]=useState(false); const [busy,setBusy]=useState(false);
  const label="mb-1.5 block text-[0.78rem] font-bold text-neutral-400";
  const field="w-full rounded-[0.6rem] border border-white/20 bg-[#181818] px-3.5 py-2.5 text-[0.92rem] text-white outline-none transition focus:border-white placeholder:text-neutral-600";
  const primary="h-11 w-full rounded-full bg-white px-6 text-[0.9rem] font-bold text-black transition hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50";
  const submit=async(e:any)=>{ e.preventDefault(); setErr("");
    if(!token){ setErr("Este link está incompleto. Peça um novo em Esqueci minha senha."); return; }
    if(password.length<6){ setErr("A nova senha precisa de pelo menos 6 caracteres."); return; }
    if(password!==confirm){ setErr("A confirmação não bate com a nova senha."); return; }
    setBusy(true);
    try{ const r=await fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"reset",token,password})}); const d=await r.json().catch(()=>({})); if(!r.ok){ setErr(d.error||"Link inválido ou expirado."); } else setOk(true); }
    catch{ setErr("Erro de conexão. Tente novamente."); }
    setBusy(false);
  };
  return <div className="relative flex min-h-dvh flex-col items-center overflow-hidden bg-black px-6 py-10 text-white">
    <div className="pointer-events-none absolute -right-32 -top-32 h-[460px] w-[460px] animate-drift rounded-full opacity-60 blur-[80px]" style={{background:"radial-gradient(circle, rgba(255,255,255,0.25), transparent 70%)"}}/>
    <div className="relative flex w-full max-w-[380px] flex-1 flex-col justify-center">
      <div className="mb-8 flex justify-center"><SonarLogo size={48}/></div>
      <h1 className="mb-2 text-center text-[28px] font-extrabold leading-tight tracking-tight">Criar nova senha</h1>
      <p className="mb-8 text-center text-sm text-neutral-500">Este link é pessoal, temporário e só pode ser usado uma vez.</p>
      {ok?<div className="space-y-4"><p role="status" className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-neutral-200">Senha redefinida com sucesso.</p><button onClick={()=>router.push("/login")} className={primary}>Entrar com a nova senha</button></div>
      :<form onSubmit={submit} className="space-y-4">
        {!token&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm">Link incompleto. Volte em “Esqueci minha senha” e peça um novo.</p>}
        <div><label className={label} htmlFor="new-password">Nova senha</label><input id="new-password" type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete="new-password" className={field}/></div>
        <div><label className={label} htmlFor="confirm-password">Confirmar nova senha</label><input id="confirm-password" type="password" value={confirm} onChange={e=>setConfirm(e.target.value)} autoComplete="new-password" className={field}/></div>
        {err&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm">{err}</p>}
        <button disabled={busy||!token} className={primary}>{busy?"Salvando…":"Redefinir senha"}</button>
        <p className="text-center text-sm"><Link href="/login" className="text-neutral-500 underline hover:text-white">Voltar para entrar</Link></p>
      </form>}
    </div>
  </div>;
}

export function AccountRecoveryPage(){
  const router=useRouter();
  const [identifier,setIdentifier]=useState(""); const [description,setDescription]=useState("");
  const [protocol,setProtocol]=useState(""); const [secret,setSecret]=useState("");
  const [status,setStatus]=useState<any>(null); const [err,setErr]=useState(""); const [sent,setSent]=useState<any>(null); const [busy,setBusy]=useState(false);
  const [newPassword,setNewPassword]=useState(""); const [done,setDone]=useState(false);
  const label="mb-1.5 block text-[0.78rem] font-bold text-neutral-400";
  const field="w-full rounded-[0.6rem] border border-white/20 bg-[#181818] px-3.5 py-2.5 text-[0.92rem] text-white outline-none transition focus:border-white placeholder:text-neutral-600";
  const primary="h-11 w-full rounded-full bg-white px-6 text-[0.9rem] font-bold text-black transition hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50";
  const call=async(payload:any)=>{ const r=await fetch("/api/recovery",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)}); const d=await r.json().catch(()=>({})); if(!r.ok) throw new Error(d.error||"Erro na solicitação."); return d; };
  const submit=async(e:any)=>{ e.preventDefault(); setErr(""); setBusy(true); try{ const d=await call({action:"submit",identifier,description}); setSent(d); setProtocol(d.code); setSecret(d.secret); }catch(e:any){ setErr(e.message); } setBusy(false); };
  const check=async()=>{ setErr(""); setBusy(true); try{ const d=await call({action:"status",code:protocol,identifier}); setStatus(d.request); }catch(e:any){ setErr(e.message); setStatus(null); } setBusy(false); };
  const complete=async()=>{ setErr(""); setBusy(true); try{ await call({action:"complete",code:protocol,identifier,secret,password:newPassword}); setDone(true); }catch(e:any){ setErr(e.message); } setBusy(false); };
  const statusLabel=(v:string)=>({pending:"Em análise",approved:"Aprovada — liberação ativa por 24h",rejected:"Rejeitada",completed:"Concluída"} as any)[v]||v;
  return <div className="relative flex min-h-dvh flex-col items-center overflow-hidden bg-black px-6 py-10 text-white">
    <div className="pointer-events-none absolute -right-32 -top-32 h-[460px] w-[460px] animate-drift rounded-full opacity-60 blur-[80px]" style={{background:"radial-gradient(circle, rgba(255,255,255,0.25), transparent 70%)"}}/>
    <div className="relative w-full max-w-[430px] flex-1">
      <div className="mb-8 flex justify-center"><SonarLogo size={48}/></div>
      <h1 className="text-center text-[28px] font-extrabold leading-tight tracking-tight">Não consigo acessar meu e-mail</h1>
      <p className="mx-auto mt-3 max-w-[360px] text-center text-sm leading-relaxed text-neutral-500">Envie uma solicitação para a equipe analisar. Ninguém vê sua senha antiga e o administrador não escolhe uma senha para você.</p>

      {!sent?<form onSubmit={submit} className="mt-8 space-y-4">
        <div><label className={label} htmlFor="rec-id">E-mail ou nome de usuário da conta</label><input id="rec-id" value={identifier} onChange={e=>setIdentifier(e.target.value)} autoComplete="username" className={field}/></div>
        <div><label className={label} htmlFor="rec-desc">Explique o problema</label><textarea id="rec-desc" value={description} onChange={e=>setDescription(e.target.value)} rows={4} placeholder="Ex.: perdi o acesso ao e-mail cadastrado e não consigo receber o link de redefinição." className={field}/></div>
        {err&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm">{err}</p>}
        <button disabled={busy} className={primary}>{busy?"Enviando…":"Enviar solicitação"}</button>
      </form>
      :<div className="mt-8 space-y-4 rounded-2xl border border-white/10 bg-white/5 p-5">
        <p className="text-sm"><b>Solicitação enviada.</b></p>
        <p className="text-sm text-neutral-300">Protocolo: <b className="text-white">{sent.code}</b></p>
        <p className="text-sm text-neutral-300">Código de acompanhamento: <b className="tracking-widest text-white">{sent.secret}</b></p>
        <p className="text-xs leading-relaxed text-neutral-500">Guarde esses dois dados agora. Eles são a sua prova para consultar a decisão e criar a nova senha se a solicitação for aprovada. O código só aparece nesta tela.</p>
      </div>}

      <div className="mt-8 space-y-4 border-t border-white/10 pt-7">
        <h2 className="text-center text-lg font-extrabold">Acompanhar solicitação</h2>
        <div><label className={label} htmlFor="rec-protocol">Protocolo</label><input id="rec-protocol" value={protocol} onChange={e=>setProtocol(e.target.value.toUpperCase())} placeholder="REC-2026-0001" className={field}/></div>
        <div><label className={label} htmlFor="rec-check-id">E-mail ou usuário usado no envio</label><input id="rec-check-id" value={identifier} onChange={e=>setIdentifier(e.target.value)} className={field}/></div>
        <button onClick={check} disabled={busy} className={primary}>Consultar estado</button>
        {status&&<div className="space-y-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm">
          <p><b>Estado:</b> {statusLabel(status.status)}</p>
          {status.adminReason&&<p className="text-neutral-400"><b className="text-neutral-200">Motivo/observação:</b> {status.adminReason}</p>}
          <p className="text-xs text-neutral-500">Aberta em {new Date(status.createdAt).toLocaleString("pt-BR")}</p>
          {status.canReset&&!done&&<>
            <div><label className={label} htmlFor="rec-secret">Código de acompanhamento</label><input id="rec-secret" value={secret} onChange={e=>setSecret(e.target.value.toUpperCase())} className={field}/></div>
            <div><label className={label} htmlFor="rec-new-pass">Nova senha</label><input id="rec-new-pass" type="password" value={newPassword} onChange={e=>setNewPassword(e.target.value)} autoComplete="new-password" className={field}/></div>
            <button onClick={complete} disabled={busy} className={primary}>Criar nova senha</button>
          </>}
          {done&&<p className="font-semibold text-white">Senha atualizada. Faça login com a nova senha.</p>}
        </div>}
        {err&&<p role="alert" className="rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm">{err}</p>}
        <p className="text-center text-sm"><Link href="/login" className="text-neutral-500 underline hover:text-white">Voltar para entrar</Link></p>
      </div>
    </div>
  </div>;
}


export function AdminRecoverySecurity({data,post}:{data:any,post:(action:string,body?:any)=>Promise<void>}){
  const [reasons,setReasons]=useState<Record<number,string>>({});
  const reqs=data.recoveryRequests||[];
  const events=data.security?.events||[];
  const emailLogs=data.security?.emailLogs||[];
  const statusLabel=(v:string)=>({pending:"PENDENTE",approved:"APROVADA",rejected:"REJEITADA",completed:"CONCLUÍDA"} as any)[v]||v;
  return <div className="space-y-5 mt-6">
    <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5">
      <h3 className="font-black">Solicitações de recuperação de conta</h3>
      <p className="text-xs text-neutral-400 mt-1">O administrador nunca vê senhas nem códigos secretos. Ao aprovar, o usuário usa o próprio protocolo + código de acompanhamento para criar a nova senha em até 24 horas.</p>
      <div className="mt-4 space-y-3">
        {reqs.length? reqs.map((r:any)=><div key={r.id} className="bg-black border border-white/10 rounded-2xl p-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm font-black">{r.code}</span>
            <span className={`text-[10px] font-black tracking-wider px-2.5 py-1 rounded-full border ${r.status==="approved"||r.status==="completed"?"bg-white text-black border-white":"border-white/30 text-neutral-300"}`}>{statusLabel(r.status)}</span>
            <span className="text-xs text-neutral-500">{new Date(r.createdAt).toLocaleString("pt-BR")}</span>
          </div>
          <p className="text-sm mt-2.5 leading-relaxed">{r.description}</p>
          <div className="grid sm:grid-cols-2 gap-2 mt-3 text-xs text-neutral-400">
            <p><b className="text-neutral-200">Identificador:</b> {r.identifier}</p>
            <p><b className="text-neutral-200">Conta vinculada:</b> {r.account? `${r.account.displayName} @${r.account.username}`:"não encontrada"}</p>
            <p><b className="text-neutral-200">E-mail da conta:</b> {r.account?.email||"—"}</p>
            <p><b className="text-neutral-200">Conta criada em:</b> {r.account? new Date(r.account.createdAt).toLocaleString("pt-BR"):"—"}</p>
            {r.account&&<p><b className="text-neutral-200">Papel:</b> {r.account.role}{r.account.suspended?" • suspensa":""}</p>}
            {r.expiresAt&&<p><b className="text-neutral-200">Liberação até:</b> {new Date(r.expiresAt).toLocaleString("pt-BR")}</p>}
          </div>
          {r.adminReason&&<p className="text-xs text-neutral-400 mt-2"><b className="text-neutral-200">Motivo registrado:</b> {r.adminReason}</p>}
          {(r.status==="pending"||r.status==="approved"||r.status==="rejected")&&<div className="flex flex-col sm:flex-row gap-2 mt-3">
            <input value={reasons[r.id]||""} onChange={e=>setReasons({...reasons,[r.id]:e.target.value})} placeholder="Motivo da decisão (obrigatório ao rejeitar)" className="flex-1 bg-neutral-900 border border-white/15 rounded-full px-4 py-2.5 text-sm outline-none"/>
            <button onClick={()=>post("recovery-decision",{id:r.id,decision:"approved",reason:reasons[r.id]||""})} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-xs">Aprovar recuperação</button>
            <button onClick={()=>{ if(!(reasons[r.id]||"").trim()){ alert("Escreva o motivo da rejeição."); return; } post("recovery-decision",{id:r.id,decision:"rejected",reason:reasons[r.id]}); }} className="border border-white/25 font-bold px-5 py-2.5 rounded-full text-xs">Rejeitar</button>
          </div>}
        </div>):<Empty title="Nenhuma solicitação" body="Pedidos de quem perdeu o e-mail aparecerão aqui."/>}
      </div>
    </div>

    <div className="grid lg:grid-cols-2 gap-5">
      <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5">
        <h3 className="font-black">Segurança e acessos</h3>
        <p className="text-xs text-neutral-400 mt-1">Tentativas com falha nas últimas 24h: <b className="text-white">{data.security?.failedLogins24h||0}</b>. Senhas e tokens nunca são registrados.</p>
        <div className="mt-3 space-y-2 max-h-[420px] overflow-auto">
          {events.length? events.slice(0,40).map((e:any)=><div key={e.id} className="bg-black border border-white/10 rounded-xl px-3.5 py-2.5 text-xs flex gap-3">
            <span className={`font-black ${e.success?"text-white":"text-neutral-500"}`}>{e.success?"OK":"FALHA"}</span>
            <span className="flex-1 min-w-0"><span className="block text-sm text-neutral-100 truncate">{e.event}</span><span className="block text-neutral-500 truncate">{e.identifier||"—"} • {e.ip||""} {e.detail?`• ${e.detail}`:""}</span></span>
            <span className="text-neutral-600 whitespace-nowrap">{new Date(e.createdAt).toLocaleString("pt-BR")}</span>
          </div>):<p className="text-sm text-neutral-500">Sem eventos registrados.</p>}
        </div>
      </div>
      <div className="bg-neutral-900 border border-white/10 rounded-2xl p-5">
        <h3 className="font-black">Envios de e-mail</h3>
        <p className="text-xs text-neutral-400 mt-1">Somente tipo, provedor e resultado — sem conteúdo, senhas ou tokens.</p>
        <div className="mt-3 space-y-2 max-h-[420px] overflow-auto">
          {emailLogs.length? emailLogs.slice(0,40).map((l:any)=><div key={l.id} className="bg-black border border-white/10 rounded-xl px-3.5 py-2.5 text-xs flex gap-3">
            <span className="font-black">{l.status.toUpperCase()}</span>
            <span className="flex-1"><span className="block text-sm text-neutral-100">{l.kind}</span><span className="block text-neutral-500">{l.provider}{l.error?` • ${l.error}`:""}</span></span>
            <span className="text-neutral-600 whitespace-nowrap">{new Date(l.createdAt).toLocaleString("pt-BR")}</span>
          </div>):<p className="text-sm text-neutral-500">Nenhum envio registrado.</p>}
        </div>
      </div>
    </div>
  </div>;
}


export function ClipsPage(){
  const {user,catalog,library,refreshLibrary}=useApp() as any; const app=useApp() as any; const router=useRouter();
  const [clips,setClips]=useState<any[]>([]); const [loading,setLoading]=useState(true); const [muted,setMuted]=useState(true);
  const [activeId,setActiveId]=useState<number|null>(null); const [progress,setProgress]=useState(0);
  const [openComments,setOpenComments]=useState<any>(null); const [comments,setComments]=useState<any[]>([]); const [commentText,setCommentText]=useState("");
  const feedRef=React.useRef<HTMLDivElement>(null); const videoRefs=React.useRef<Record<number,HTMLVideoElement|null>>({});
  const load=async()=>{ try{ const r=await fetch("/api/clips"); const d=await r.json(); setClips(d.clips||[]); }catch{} setLoading(false); };
  useEffect(()=>{ load(); if(app.playing) app.toggle(); },[]); // eslint-disable-line
  useEffect(()=>{
    const root=feedRef.current; if(!root) return;
    const io=new IntersectionObserver((entries)=>{
      for(const e of entries){
        const v=e.target as HTMLVideoElement;
        if(e.intersectionRatio>=0.6){ setActiveId(Number(v.dataset.trackId||0)); v.play().catch(()=>{}); } else { v.pause(); }
      }
    },{root,threshold:[0,0.6,1]});
    Object.values(videoRefs.current).forEach(v=>{ if(v) io.observe(v); });
    return ()=>io.disconnect();
  },[clips,muted]);
  const needLogin=()=>{ if(!user){ router.push("/login"); return true; } return false; };
  const act=async(action:string,trackId:number,extra:any={})=>{ if(needLogin()) return; const r=await fetch("/api/clips",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,trackId,...extra})}); const d=await r.json().catch(()=>({})); if(!r.ok){ app.showToast(d.error||"Erro"); return; } if(d.clips) setClips(d.clips); };
  const loadComments=async(trackId:number)=>{ try{ const r=await fetch(`/api/clips?trackId=${trackId}`); const d=await r.json(); setComments(d.comments||[]); }catch{} };
  const openCommentsFor=(c:any)=>{ setOpenComments(c); Object.values(videoRefs.current).forEach(v=>v?.pause()); loadComments(c.id); };
  const closeComments=()=>{ setOpenComments(null); const v=activeId?videoRefs.current[activeId]:null; if(v) v.play().catch(()=>{}); };
  const sendComment=async()=>{ if(!openComments||!commentText.trim()) return; await act("comment",openComments.id,{body:commentText.trim()}); setCommentText(""); loadComments(openComments.id); };
  const shareClip=async(c:any)=>{ const url=location.origin+`/track/${c.id}`; if(navigator.share) await navigator.share({title:c.title,text:`${c.title} — ${c.artist?.name||""} no ${catalog?.settings?.siteName||"Sonar"}`,url}).catch(()=>{}); else app.showToast("Compartilhamento direto não suportado neste aparelho."); };
  const fmtN=(n:number)=> n>=1000? (n/1000).toFixed(1).replace(".0","")+"k" : String(n);
  const followedIds:number[]=library?.followedArtistIds||[];
  const toggleFollow=async(artistId:number)=>{ if(needLogin()) return; const r=await fetch("/api/actions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"toggle-follow-artist",artistId})}); const d=await r.json().catch(()=>({})); if(r.ok) refreshLibrary(); else app.showToast(d.error||"Erro"); };
  return <div className="fixed inset-0 z-[60] bg-black text-white overflow-hidden">
    {/* topo minimo sobre o video */}
    <div className="absolute top-0 inset-x-0 z-30 flex items-center gap-3 px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-6 bg-gradient-to-b from-black/70 to-transparent pointer-events-none">
      <div className="pointer-events-auto"><SonarLogo size={26}/></div>
      <span className="font-black text-[15px] drop-shadow ml-1">Clipes</span>
      <div className="ml-auto flex items-center gap-2 pointer-events-auto">
        <button onClick={()=>setMuted(!muted)} className="w-10 h-10 grid place-items-center rounded-full bg-black/45 border border-white/20 backdrop-blur" aria-label={muted?"Ativar som":"Silenciar"}>{muted?<VolumeX size={17}/>:<Volume2 size={17}/>}</button>
        <Link href="/area-artista" className="h-10 px-4 rounded-full bg-white text-black text-xs font-black flex items-center">Publicar clipe</Link>
      </div>
    </div>

    {loading&&<div className="h-[100dvh] grid place-items-center text-sm text-neutral-400">Carregando clipes...</div>}
    {!loading&&clips.length===0&&<div className="h-[100dvh] flex flex-col items-center justify-center px-8 text-center">
      <SonarBrandMark size={60}/>
      <h1 className="text-2xl font-black mt-6">Nenhum clipe ainda</h1>
      <p className="text-sm text-neutral-400 mt-2 max-w-[290px] leading-relaxed">Quando um artista publicar um videoclipe no Estúdio, ele aparece aqui em tela cheia para deslizar, curtir e comentar.</p>
      <Link href="/area-artista" className="mt-6 bg-white text-black font-bold px-6 py-3 rounded-full text-sm">Publicar meu clipe</Link>
    </div>}

    {clips.length>0&&<div ref={feedRef} className="h-[100dvh] overflow-y-auto snap-y snap-mandatory scrollbar-none">
      {clips.map(c=><section key={c.id} className="relative h-[100dvh] snap-start snap-always overflow-hidden bg-black">
        <div className="relative h-full w-full sm:max-w-[520px] mx-auto overflow-hidden bg-black">
          <video ref={(el:any)=>{ videoRefs.current[c.id]=el; }} data-track-id={c.id} src={c.videoUrl} poster={c.thumbnail||undefined} className="absolute inset-0 h-full w-full object-cover" loop playsInline muted={muted} preload="metadata"
            onTimeUpdate={(e:any)=>{ if(activeId===c.id){ const v=e.currentTarget; setProgress(v.duration? v.currentTime/v.duration : 0); } }}
            onClick={(e:any)=>{ const v=e.currentTarget; if(v.paused) v.play().catch(()=>{}); else v.pause(); }}/>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/25"/>
          {/* trilho de acoes estilo Reels */}
          <div className="absolute right-3 bottom-32 flex flex-col items-center gap-5 z-20">
            <Link href={`/artist/${c.artist?.id}`} className="relative">
              {c.artist?.imageUrl? <img src={c.artist.imageUrl} alt="" className="w-12 h-12 rounded-full object-cover border-2 border-white"/> : <span className="w-12 h-12 rounded-full bg-white text-black grid place-items-center font-black border-2 border-white">{(c.artist?.name||"?")[0]}</span>}
            </Link>
            <button onClick={()=>act("like",c.id)} className="flex flex-col items-center gap-1" aria-label="Curtir">
              <span className={`w-12 h-12 rounded-full grid place-items-center backdrop-blur ${c.liked?"bg-white text-black":"bg-black/45 text-white border border-white/20"}`}><Heart size={22} fill={c.liked?"#000":"none"}/></span>
              <span className="text-[11px] font-bold drop-shadow">{fmtN(c.likeCount)}</span>
            </button>
            <button onClick={()=>openCommentsFor(c)} className="flex flex-col items-center gap-1" aria-label="Comentários">
              <span className="w-12 h-12 rounded-full grid place-items-center bg-black/45 text-white border border-white/20 backdrop-blur"><MessageCircle size={21}/></span>
              <span className="text-[11px] font-bold drop-shadow">{fmtN(c.commentCount)}</span>
            </button>
            <button onClick={()=>act("repost",c.id)} className="flex flex-col items-center gap-1" aria-label="Repostar">
              <span className={`w-12 h-12 rounded-full grid place-items-center backdrop-blur ${c.reposted?"bg-white text-black":"bg-black/45 text-white border border-white/20"}`}><Repeat2 size={21}/></span>
              <span className="text-[11px] font-bold drop-shadow">{fmtN(c.repostCount)}</span>
            </button>
            <button onClick={()=>shareClip(c)} className="flex flex-col items-center gap-1" aria-label="Compartilhar">
              <span className="w-12 h-12 rounded-full grid place-items-center bg-black/45 text-white border border-white/20 backdrop-blur"><Share2 size={20}/></span>
              <span className="text-[11px] font-bold drop-shadow">Enviar</span>
            </button>
          </div>
          {/* informacoes do clipe */}
          <div className="absolute left-4 right-20 bottom-24 z-20">
            <div className="flex items-center gap-2.5 flex-wrap">
              <Link href={`/artist/${c.artist?.id}`} className="font-bold text-[15px] drop-shadow">{c.artist?.name}</Link>
              {c.artist?.id&&!followedIds.includes(c.artist.id)&&<button onClick={()=>toggleFollow(c.artist.id)} className="text-[11px] font-bold border border-white/60 rounded-full px-3 py-1 backdrop-blur bg-black/30">Seguir</button>}
            </div>
            <p className="text-sm mt-1.5 leading-snug drop-shadow">{c.title}{c.genre?` • ${c.genre}`:""}</p>
            <p className="text-[11px] text-neutral-300 mt-1">{fmtN(c.plays)} reproduções da música</p>
            <div className="flex gap-2 mt-3">
              <Link href={`/track/${c.id}`} className="bg-white text-black text-xs font-bold px-4 py-2 rounded-full flex items-center gap-1.5"><Play size={13} fill="currentColor"/> Ouvir música</Link>
              <Link href={`/artist/${c.artist?.id}`} className="border border-white/40 text-xs font-bold px-4 py-2 rounded-full backdrop-blur bg-black/30">Ver artista</Link>
            </div>
          </div>
          {/* progresso */}
          <div className="absolute bottom-[60px] left-0 right-0 h-[3px] bg-white/15 z-20"><div className="h-full bg-white transition-[width] duration-200" style={{width:`${activeId===c.id? Math.round(progress*100):0}%`}}/></div>
        </div>
      </section>)}
    </div>}

    {/* navegacao minima estilo Reels */}
    <nav className="absolute bottom-0 inset-x-0 z-30 bg-black/85 backdrop-blur border-t border-white/10 pb-[env(safe-area-inset-bottom)]">
      <div className="max-w-[520px] mx-auto grid grid-cols-5">
        <Link href="/" className="flex flex-col items-center gap-0.5 py-2 text-[9px] font-bold text-neutral-400"><Music2 size={20}/>Início</Link>
        <Link href="/search" className="flex flex-col items-center gap-0.5 py-2 text-[9px] font-bold text-neutral-400"><Search size={20}/>Buscar</Link>
        <Link href="/clipes" className="flex flex-col items-center gap-0.5 py-2 text-[9px] font-bold text-white"><Clapperboard size={20}/>Clipes</Link>
        <Link href="/library" className="flex flex-col items-center gap-0.5 py-2 text-[9px] font-bold text-neutral-400"><ListMusic size={20}/>Biblioteca</Link>
        <Link href="/area-artista" className="flex flex-col items-center gap-0.5 py-2 text-[9px] font-bold text-neutral-400"><Mic2 size={20}/>Estúdio</Link>
      </div>
    </nav>

    {openComments&&<div className="fixed inset-0 z-[90] bg-black/70 flex items-end sm:items-center justify-center" onClick={closeComments}>
      <div className="w-full max-w-lg bg-neutral-900 border border-white/10 rounded-t-3xl sm:rounded-3xl max-h-[78dvh] flex flex-col" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
          <div className="flex-1 min-w-0"><p className="font-black truncate">Comentários</p><p className="text-xs text-neutral-400 truncate">{openComments.title} — {openComments.artist?.name}</p></div>
          <button onClick={closeComments} className="text-neutral-400"><X size={19}/></button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-3 space-y-3.5">
          {comments.length? comments.map((cm:any)=><div key={cm.id} className="flex gap-2.5">
            <span className="w-8 h-8 rounded-full bg-white text-black grid place-items-center text-xs font-black shrink-0 overflow-hidden">{cm.user?.avatarUrl?<img src={cm.user.avatarUrl} alt="" className="w-full h-full object-cover"/>:(cm.user?.displayName||"?")[0]}</span>
            <div className="flex-1 min-w-0"><p className="text-xs"><b>{cm.user?.displayName}</b> <span className="text-neutral-500">@{cm.user?.username}</span></p>
            <p className="text-sm text-neutral-200 leading-relaxed">{cm.body}</p>
            <p className="text-[10px] text-neutral-600 mt-0.5">{new Date(cm.createdAt).toLocaleString("pt-BR")}</p></div>
            {(user&&(cm.user?.id===user.id||user.role==="admin"))&&<button onClick={async()=>{ await act("delete-comment",openComments.id,{commentId:cm.id}); loadComments(openComments.id); }} className="text-neutral-500 hover:text-white h-fit"><Trash2 size={14}/></button>}
          </div>):<p className="text-sm text-neutral-500 py-6 text-center">Seja a primeira pessoa a comentar neste clipe.</p>}
        </div>
        <div className="flex gap-2 p-4 border-t border-white/10">
          <input value={commentText} onChange={e=>setCommentText(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") sendComment(); }} placeholder={user?"Adicione um comentário...":"Entre para comentar"} disabled={!user} className="flex-1 bg-black border border-white/15 rounded-full px-4 py-3 text-sm outline-none focus:border-white/50 disabled:opacity-50"/>
          <button onClick={sendComment} disabled={!user||!commentText.trim()} className="w-11 h-11 rounded-full bg-white text-black grid place-items-center disabled:opacity-40 shrink-0"><Send size={17}/></button>
        </div>
      </div>
    </div>}
  </div>;
}

export function AdminPage(){
  const {user,refreshCatalog}=useApp() as any; const [data,setData]=useState<any>(null); const [tab,setTab]=useState("overview"); const [msg,setMsg]=useState("");
  const [trackForm,setTrackForm]=useState<any>({title:"",artistId:"",albumId:"",audioUrl:"",coverUrl:"",duration:200,genre:"",credits:"",published:true,featured:false});
  const [artistForm,setArtistForm]=useState<any>({name:"",bio:"",imageUrl:"",genre:"",monthlyListeners:0});
  const [albumForm,setAlbumForm]=useState<any>({title:"",artistId:"",coverUrl:"",releaseDate:"2025-01-01",type:"album",genre:""});
  const [settings,setSettings]=useState<any>({});
  const load=async()=>{ const r=await fetch("/api/admin"); if(r.ok){ const d=await r.json(); setData(d); setSettings(d.settings||{}); } };
  useEffect(()=>{ load(); },[]);
  if(user===undefined) return <Loading/>; if(!user||user.role!=="admin") return <div className="px-4 md:px-8 pt-10 max-w-lg"><h1 className="text-3xl font-black">Painel administrativo</h1><p className="text-neutral-400 mt-2">Acesso restrito a administradores autenticados no servidor.</p>{!user&&<Link href="/login" className="inline-block mt-5 bg-white text-black font-bold px-6 py-3 rounded-full">Entrar como admin</Link>}<p className="text-xs text-neutral-500 mt-4">Entre com a conta administradora do proprietário para acessar.</p></div>;
  if(!data) return <Loading/>;
  const post=async(action:string,body:any={})=>{ const r=await fetch("/api/admin",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action,...body})}); const d=await r.json(); setMsg(r.ok?"Salvo com sucesso.":(d.error||"Erro")); load(); refreshCatalog(); };
  const input="w-full bg-black border border-white/15 rounded-xl px-3 py-2.5 text-sm outline-none";
  return <div className="px-4 md:px-8 max-w-[1400px] mx-auto pt-6">
    <div className="flex items-center gap-3"><span className="w-10 h-10 rounded-xl bg-white text-black grid place-items-center"><Shield size={19}/></span><div><h1 className="text-2xl md:text-3xl font-black">Painel SONAR</h1><p className="text-xs text-neutral-400">Administração • permissão verificada no servidor</p></div><div className="ml-auto flex gap-2 flex-wrap"><Link href="/area-artista" className="bg-white text-black font-bold px-4 py-2.5 rounded-full text-xs">Estúdio do Artista (testar)</Link><Link href="/seja-artista" className="border border-white/30 font-bold px-4 py-2.5 rounded-full text-xs">Novo perfil de artista</Link></div></div>
    <div className="flex gap-2 mt-6 overflow-x-auto">{[["overview","Visão geral"],["recovery","Recuperação & Segurança"],["studio","Admin Studio"],["tracks","Músicas"],["artists","Artistas"],["albums","Álbuns"],["users","Usuários"],["reports","Denúncias"],["support","Suporte"],["settings","Site & Home"],["logs","Auditoria"]].map(([k,l])=><button key={k} onClick={()=>setTab(k)} className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap ${tab===k?"bg-white text-black":"bg-neutral-900 border border-white/10"}`}>{l}</button>)}</div>
    {msg&&<p className="mt-4 text-sm bg-white text-black px-4 py-2.5 rounded-xl font-semibold inline-block">{msg}</p>}
    {tab==="overview"&&<>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">{[[Users,"Usuários",data.stats.users],[Music2,"Músicas",data.stats.tracks],[MicIcon,"Artistas",data.stats.artists],[Disc,"Álbuns",data.stats.albums],[ListMusic,"Playlists",data.stats.playlists],[BarChart3,"Reproduções (catálogo)",data.stats.plays],[Clock,"Plays registrados",data.stats.playsLogged],[Flag,"Denúncias abertas",data.stats.openReports]].map(([Icon,label,val]:any)=><div key={label} className="bg-neutral-900 border border-white/10 rounded-2xl p-5"><Icon size={19} className="text-neutral-400"/><p className="text-3xl font-black mt-3">{val}</p><p className="text-xs text-neutral-400 mt-1">{label}</p></div>)}</div>
      <div className="mt-4 bg-neutral-900 border border-white/10 rounded-2xl p-5">
        <h3 className="font-black">Banco de dados e integrações</h3>
        <p className="text-xs text-neutral-400 mt-1">Status real verificado no servidor. Nenhuma senha ou chave é exibida.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-2.5 mt-4">
          {[["Banco PostgreSQL",data.services?.database],["Login com Google",data.services?.google],["Login com Apple",data.services?.apple],["E-mail automático",data.services?.email],["Segredo de sessão",data.services?.authSecret],["Letra por IA",data.services?.transcription]].map(([label,svc]:any)=><div key={label} className="bg-black border border-white/10 rounded-xl px-4 py-3"><p className="text-xs font-bold text-neutral-400">{label}</p><p className={`text-sm font-black mt-1 ${svc?.configured?"text-white":"text-neutral-400"}`}>{svc?.configured?"CONFIGURADO":"PENDENTE"}</p>{svc?.detail&&<p className="text-[11px] text-neutral-500 mt-1">{svc.detail}</p>}</div>)}
        </div>
        {data.services?.missing?.length>0&&<p className="text-xs text-neutral-400 mt-4 leading-relaxed"><b className="text-white">Falta configurar no servidor:</b> {data.services.missing.join(" • ")}. Sem isso, Google/e-mail não são fingidos: o app informa a pendência.</p>}
      </div>
    </>}
    {tab==="recovery"&&<AdminRecoverySecurity data={data} post={post}/>}
    {tab==="studio"&&<AdminStudio/>}
    {tab==="tracks"&&<div className="grid lg:grid-cols-[380px,1fr] gap-5 mt-6"><div className="bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-2.5 h-fit"><h3 className="font-bold">{trackForm.id?"Editar música":"Nova música"}</h3><input placeholder="Título" value={trackForm.title} onChange={e=>setTrackForm({...trackForm,title:e.target.value})} className={input}/><select value={trackForm.artistId} onChange={e=>setTrackForm({...trackForm,artistId:e.target.value})} className={input}><option value="">Artista...</option>{data.artists.map((a:any)=><option key={a.id} value={a.id}>{a.name}</option>)}</select><select value={trackForm.albumId} onChange={e=>setTrackForm({...trackForm,albumId:e.target.value})} className={input}><option value="">Álbum (opcional)...</option>{data.albums.map((a:any)=><option key={a.id} value={a.id}>{a.title}</option>)}</select><FileUpload kind="audio" label="Enviar arquivo da música" value={trackForm.audioUrl||""} onChange={(url,dur)=>setTrackForm({...trackForm,audioUrl:url,duration:dur||trackForm.duration})}/><FileUpload kind="image" label="Enviar capa" value={trackForm.coverUrl||""} onChange={(url)=>setTrackForm({...trackForm,coverUrl:url})}/><div className="grid grid-cols-2 gap-2"><input type="number" placeholder="Duração (s)" value={trackForm.duration} onChange={e=>setTrackForm({...trackForm,duration:e.target.value})} className={input}/><GenreSelect value={trackForm.genre} onChange={v=>setTrackForm({...trackForm,genre:v})} className={input}/></div><input placeholder="Créditos" value={trackForm.credits} onChange={e=>setTrackForm({...trackForm,credits:e.target.value})} className={input}/><label className="flex gap-2 text-sm"><input type="checkbox" checked={trackForm.published} onChange={e=>setTrackForm({...trackForm,published:e.target.checked})} className="accent-white"/> Publicada</label><label className="flex gap-2 text-sm"><input type="checkbox" checked={trackForm.featured} onChange={e=>setTrackForm({...trackForm,featured:e.target.checked})} className="accent-white"/> Destaque na home</label><button onClick={()=>post("upsert-track",trackForm)} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm w-full">Salvar música</button></div>
    <div className="space-y-2">{data.tracks.map((t:any)=><div key={t.id} className="flex items-center gap-3 bg-neutral-900 border border-white/10 rounded-xl px-3 py-2.5"><img src={t.coverUrl} alt="" className="w-10 h-10 rounded object-cover bg-neutral-800"/><div className="flex-1 min-w-0"><p className="text-sm font-semibold truncate">{t.title} {!t.published&&<span className="text-[10px] border border-white/25 rounded px-1.5 py-0.5">RASCUNHO</span>}</p><p className="text-xs text-neutral-400">{t.genre} • {t.plays} plays</p></div><button onClick={()=>setTrackForm(t)} className="text-sm border border-white/20 px-3 py-1.5 rounded-full">Editar</button><button onClick={()=>{ if(confirm("Remover música?")) post("delete-track",{id:t.id}); }} className="text-neutral-400 hover:text-white"><Trash2 size={16}/></button></div>)}</div></div>}
    {tab==="artists"&&<div className="grid lg:grid-cols-[380px,1fr] gap-5 mt-6"><div className="bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-2.5 h-fit"><h3 className="font-bold">{artistForm.id?"Editar artista":"Novo artista"}</h3><input placeholder="Nome" value={artistForm.name} onChange={e=>setArtistForm({...artistForm,name:e.target.value})} className={input}/><FileUpload kind="image" label="Enviar foto do artista" value={artistForm.imageUrl||""} onChange={(url)=>setArtistForm({...artistForm,imageUrl:url})}/><GenreSelect value={artistForm.genre} onChange={v=>setArtistForm({...artistForm,genre:v})} className={input}/><input type="number" placeholder="Ouvintes mensais" value={artistForm.monthlyListeners} onChange={e=>setArtistForm({...artistForm,monthlyListeners:e.target.value})} className={input}/><textarea placeholder="Biografia" value={artistForm.bio} onChange={e=>setArtistForm({...artistForm,bio:e.target.value})} className={input}/><button onClick={()=>post("upsert-artist",artistForm)} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm w-full">Salvar artista</button></div>
    <div className="space-y-2">{data.artists.map((a:any)=><div key={a.id} className="flex flex-wrap items-center gap-3 bg-neutral-900 border border-white/10 rounded-xl px-3 py-2.5"><img src={a.imageUrl} alt="" className="w-10 h-10 rounded-full object-cover bg-neutral-800"/><div className="flex-1 min-w-[140px]"><p className="text-sm font-semibold">{a.name} <span className={`text-[10px] font-black tracking-wider px-2 py-0.5 rounded-full border ${a.status==="approved"?"bg-white text-black border-white":"border-white/30"}`}>{a.userId?"ATIVO":"EDITORIAL"}</span></p><p className="text-xs text-neutral-400">{a.genre}{a.userId?" • conta vinculada":" • editorial"}</p></div><button onClick={()=>setArtistForm(a)} className="text-sm border border-white/20 px-3 py-1.5 rounded-full">Editar</button><button onClick={()=>{ if(confirm("Remover artista?")) post("delete-artist",{id:a.id}); }} className="text-neutral-400"><Trash2 size={16}/></button></div>)}</div></div>}
    {tab==="albums"&&<div className="grid lg:grid-cols-[380px,1fr] gap-5 mt-6"><div className="bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-2.5 h-fit"><h3 className="font-bold">{albumForm.id?"Editar álbum":"Novo álbum / single / EP"}</h3><input placeholder="Título" value={albumForm.title} onChange={e=>setAlbumForm({...albumForm,title:e.target.value})} className={input}/><select value={albumForm.artistId} onChange={e=>setAlbumForm({...albumForm,artistId:e.target.value})} className={input}><option value="">Artista...</option>{data.artists.map((a:any)=><option key={a.id} value={a.id}>{a.name}</option>)}</select><FileUpload kind="image" label="Enviar capa do álbum" value={albumForm.coverUrl||""} onChange={(url)=>setAlbumForm({...albumForm,coverUrl:url})}/><div className="grid grid-cols-2 gap-2"><input type="date" value={albumForm.releaseDate} onChange={e=>setAlbumForm({...albumForm,releaseDate:e.target.value})} className={input}/><select value={albumForm.type} onChange={e=>setAlbumForm({...albumForm,type:e.target.value})} className={input}><option value="album">Álbum</option><option value="single">Single</option><option value="ep">EP</option></select></div><GenreSelect value={albumForm.genre} onChange={v=>setAlbumForm({...albumForm,genre:v})} className={input}/><button onClick={()=>post("upsert-album",albumForm)} className="bg-white text-black font-bold px-5 py-2.5 rounded-full text-sm w-full">Salvar álbum</button></div>
    <div className="space-y-2">{data.albums.map((a:any)=><div key={a.id} className="flex items-center gap-3 bg-neutral-900 border border-white/10 rounded-xl px-3 py-2.5"><img src={a.coverUrl} alt="" className="w-10 h-10 rounded object-cover bg-neutral-800"/><div className="flex-1"><p className="text-sm font-semibold">{a.title}</p><p className="text-xs text-neutral-400">{a.type} • {a.releaseDate}</p></div><button onClick={()=>setAlbumForm(a)} className="text-sm border border-white/20 px-3 py-1.5 rounded-full">Editar</button><button onClick={()=>{ if(confirm("Remover álbum?")) post("delete-album",{id:a.id}); }} className="text-neutral-400"><Trash2 size={16}/></button></div>)}</div></div>}
    {tab==="users"&&<div className="space-y-2 mt-6">{data.users.map((u:any)=><div key={u.id} className="flex flex-wrap items-center gap-3 bg-neutral-900 border border-white/10 rounded-xl px-4 py-3"><div className="flex-1 min-w-[180px]"><p className="text-sm font-semibold">{u.displayName} <span className="text-neutral-500">@{u.username}</span></p><p className="text-xs text-neutral-400">{u.email} • {u.role}{u.suspended?" • SUSPENSO":""}</p></div><button onClick={()=>post("toggle-role",{id:u.id})} className="text-xs border border-white/20 px-3 py-1.5 rounded-full">{u.role==="admin"?"Remover admin":"Tornar admin"}</button><button onClick={()=>post("toggle-suspend",{id:u.id})} className="text-xs border border-white/20 px-3 py-1.5 rounded-full">{u.suspended?"Reativar":"Suspender"}</button></div>)}</div>}
    {tab==="reports"&&<div className="space-y-2 mt-6">{data.reports.length?data.reports.map((r:any)=><div key={r.id} className="flex gap-3 items-center bg-neutral-900 border border-white/10 rounded-xl px-4 py-3"><Flag size={16} className="text-neutral-400"/><div className="flex-1"><p className="text-sm">{r.targetType} #{r.targetId} — {r.reason}</p><p className="text-xs text-neutral-500">{r.status} • {new Date(r.createdAt).toLocaleString("pt-BR")}</p></div>{r.status==="open"&&<button onClick={()=>post("resolve-report",{id:r.id})} className="text-xs bg-white text-black font-bold px-3 py-1.5 rounded-full">Resolver</button>}</div>):<Empty title="Sem denúncias" body="Denúncias de conteúdo aparecerão aqui."/>}</div>}
    {tab==="support"&&<AdminSupport/>}
    {tab==="settings"&&<div className="mt-6 bg-neutral-900 border border-white/10 rounded-2xl p-5 space-y-2.5 max-w-xl"><h3 className="font-bold">Identidade e página inicial</h3><p className="text-xs text-neutral-400">Troque aqui o nome da plataforma quando sua marca estiver pronta — sem tocar no código.</p><input placeholder="Nome da plataforma" value={settings.siteName||""} onChange={e=>setSettings({...settings,siteName:e.target.value})} className={input}/><input placeholder="Slogan" value={settings.tagline||""} onChange={e=>setSettings({...settings,tagline:e.target.value})} className={input}/><input placeholder="URL do logotipo (opcional)" value={settings.logoUrl||""} onChange={e=>setSettings({...settings,logoUrl:e.target.value})} className={input}/><input placeholder="Título do hero" value={settings.heroTitle||""} onChange={e=>setSettings({...settings,heroTitle:e.target.value})} className={input}/><textarea placeholder="Subtítulo do hero" value={settings.heroSubtitle||""} onChange={e=>setSettings({...settings,heroSubtitle:e.target.value})} className={input}/><button onClick={()=>post("update-settings",settings)} className="bg-white text-black font-bold px-6 py-2.5 rounded-full text-sm">Salvar configurações</button></div>}
    {tab==="logs"&&<div className="space-y-2 mt-6">{data.logs.length?data.logs.map((l:any)=><div key={l.id} className="bg-neutral-900 border border-white/10 rounded-xl px-4 py-3 text-sm flex justify-between gap-3"><span>{l.action} — {l.detail}</span><span className="text-xs text-neutral-500">{new Date(l.createdAt).toLocaleString("pt-BR")}</span></div>):<Empty title="Sem registros" body="Ações administrativas serão auditadas aqui."/>}</div>}
  </div>;
}
function MicIcon(props:any){ return <Music2 {...props}/>; }

export function LegalPage({type}:{type:"terms"|"privacy"}){
  const isTerms=type==="terms";
  return <div className="px-4 md:px-8 max-w-3xl mx-auto pt-10"><h1 className="text-4xl font-black">{isTerms?"Termos de Uso":"Política de Privacidade"}</h1>
  <div className="mt-6 space-y-4 text-neutral-300 leading-relaxed text-[15px]">
  {isTerms? <>
    <p>A SONAR é uma plataforma de descoberta e reprodução de música de artistas independentes e de fontes de áudio autorizadas. Ao criar uma conta, você concorda com estes termos.</p>
    <h2 className="text-white font-bold text-lg">Conta e conduta</h2><p>Você é responsável pela sua conta e senha. Não publique conteúdo sem direitos, não tente acessar contas de terceiros e respeite outros usuários. Conteúdos podem ser denunciados e moderados.</p>
    <h2 className="text-white font-bold text-lg">Conteúdo e direitos</h2><p>Artistas e administradores só devem cadastrar áudios com autorização. Demonstrações utilizam a fonte autorizada SoundHelix. Direitos de obras permanecem com seus titulares.</p>
    <h2 className="text-white font-bold text-lg">Disponibilidade</h2><p>Podemos atualizar, suspender contas que violem estes termos e remover conteúdos denunciados após análise.</p>
  </>:<>
    <p>Coletamos apenas os dados necessários: conta (nome, e-mail, usuário), biblioteca (favoritos, playlists, seguidos), histórico de reprodução e notificações.</p>
    <h2 className="text-white font-bold text-lg">Uso dos dados</h2><p>Usamos os dados para operar a plataforma, personalizar sua biblioteca e enviar notificações internas. Senhas são armazenadas com hash (bcrypt) e sessões usam cookies httpOnly.</p>
    <h2 className="text-white font-bold text-lg">Seus direitos</h2><p>Você pode editar seu perfil, tornar o histórico privado, limpar o histórico e excluir sua conta em Configurações. Playlists privadas não aparecem em buscas públicas.</p>
    <h2 className="text-white font-bold text-lg">Compartilhamento</h2><p>Não vendemos dados pessoais. Conteúdos públicos (perfil, playlists públicas) são visíveis a outros usuários por design do recurso social.</p>
  </>}
  </div></div>;
}
