import { NextResponse } from "next/server";
import { db } from "@/db";
import { accountRecoveryRequests, users, notifications } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { ensureSeed } from "@/lib/catalog";
import { hashPassword } from "@/lib/auth";
import { logAuthEvent, requestIp } from "@/lib/security";
import crypto from "crypto";

const hits = new Map<string, number[]>();
function rateLimit(key: string, max: number, windowMs: number) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  arr.push(now);
  hits.set(key, arr);
  return arr.length > max;
}
function sha256(value: string) { return crypto.createHash("sha256").update(value).digest("hex"); }
function publicRequest(r: any) {
  return {
    id: r.id,
    code: r.code,
    identifier: r.identifier,
    status: r.status,
    adminReason: r.adminReason || "",
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
    canReset: r.status === "approved" && !r.usedAt && r.expiresAt && new Date(r.expiresAt).getTime() > Date.now(),
  };
}
async function findUser(identifier: string) {
  const ident = identifier.toLowerCase().trim();
  const [u] = await db.select().from(users).where(or(eq(users.email, ident), eq(users.username, ident))).limit(1);
  return u || null;
}
async function findRequest(code: string, identifier: string) {
  const protocol = (code || "").toUpperCase().trim();
  const ident = (identifier || "").toLowerCase().trim();
  if (!protocol || !ident) return null;
  const [r] = await db.select().from(accountRecoveryRequests).where(eq(accountRecoveryRequests.code, protocol)).limit(1);
  if (!r || r.identifier.toLowerCase() !== ident) return null;
  return r;
}

export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const protocol = url.searchParams.get("code") || "";
  const identifier = url.searchParams.get("identifier") || "";
  const r = await findRequest(protocol, identifier);
  if (!r) return NextResponse.json({ error: "Solicitação não encontrada. Confira o protocolo e o identificador usados no envio." }, { status: 404 });
  return NextResponse.json({ request: publicRequest(r) });
}

export async function POST(req: Request) {
  await ensureSeed();
  const body = await req.json().catch(() => ({}));
  const action = body.action;
  const ip = requestIp(req);
  try {
    if (action === "submit") {
      if (rateLimit(`recovery:${ip}`, 5, 15 * 60 * 1000)) return NextResponse.json({ error: "Muitas solicitações. Aguarde alguns minutos." }, { status: 429 });
      const identifier = (body.identifier || "").toLowerCase().trim();
      const description = (body.description || "").trim();
      if (!identifier || identifier.length < 3) return NextResponse.json({ error: "Informe seu e-mail ou nome de usuário cadastrado." }, { status: 400 });
      if (rateLimit(`recovery-id:${identifier}`, 3, 60 * 60 * 1000)) return NextResponse.json({ error: "Já há solicitações recentes para este identificador. Aguarde a análise." }, { status: 429 });
      if (description.length < 10) return NextResponse.json({ error: "Explique o problema em pelo menos algumas palavras para a equipe conseguir analisar." }, { status: 400 });
      const user = await findUser(identifier);
      const secret = crypto.randomBytes(6).toString("hex").toUpperCase(); // código de acompanhamento do solicitante
      const [created] = await db.insert(accountRecoveryRequests).values({
        code: "TEMP",
        userId: user?.id || null,
        identifier,
        description: description.slice(0, 1200),
        secretHash: sha256(`pending:${identifier}:${secret}`),
        status: "pending",
      }).returning();
      const code = `REC-${new Date().getFullYear()}-${String(created.id).padStart(4, "0")}`;
      await db.update(accountRecoveryRequests).set({ code, secretHash: sha256(`${code}:${identifier}:${secret}`), updatedAt: new Date() }).where(eq(accountRecoveryRequests.id, created.id));
      await logAuthEvent({ req, userId: user?.id || null, identifier, event: "account_recovery_requested", success: true, detail: code });
      const admins = await db.select().from(users).where(eq(users.role, "admin"));
      for (const adm of admins) await db.insert(notifications).values({ userId: adm.id, title: `Nova recuperação de conta ${code}`, body: `Solicitação alternativa recebida para análise. Nenhuma senha é exibida.` });
      // O código secreto aparece uma única vez: é a prova de acompanhamento do solicitante.
      return NextResponse.json({ ok: true, code, secret, note: "Guarde o protocolo e o código de acompanhamento. Você vai usá-los para consultar a decisão e, se aprovado, criar a nova senha." });
    }

    if (action === "status") {
      const r = await findRequest(body.code || "", body.identifier || "");
      if (!r) return NextResponse.json({ error: "Solicitação não encontrada. Confira o protocolo e o identificador." }, { status: 404 });
      return NextResponse.json({ ok: true, request: publicRequest(r) });
    }

    if (action === "complete") {
      const password = body.password || "";
      if (!password || password.length < 6 || password.length > 128) return NextResponse.json({ error: "A nova senha precisa ter entre 6 e 128 caracteres." }, { status: 400 });
      const r = await findRequest(body.code || "", body.identifier || "");
      if (!r) return NextResponse.json({ error: "Solicitação não encontrada." }, { status: 404 });
      if (r.status !== "approved" || r.usedAt) return NextResponse.json({ error: "Esta solicitação ainda não está liberada para redefinir a senha." }, { status: 403 });
      if (!r.expiresAt || new Date(r.expiresAt).getTime() < Date.now()) return NextResponse.json({ error: "A liberação expirou. Abra uma nova solicitação." }, { status: 400 });
      const expected = sha256(`${r.code}:${r.identifier.toLowerCase()}:${(body.secret || "").toUpperCase().trim()}`);
      if (expected !== r.secretHash) {
        await logAuthEvent({ req, userId: r.userId, identifier: r.identifier, event: "account_recovery_failed", success: false, detail: r.code });
        return NextResponse.json({ error: "Código de acompanhamento incorreto." }, { status: 400 });
      }
      if (!r.userId) return NextResponse.json({ error: "Não foi possível vincular esta solicitação a uma conta. Fale com o suporte." }, { status: 400 });
      const [u] = await db.select().from(users).where(eq(users.id, r.userId)).limit(1);
      if (!u) return NextResponse.json({ error: "Conta não encontrada." }, { status: 404 });
      const newVersion = (((u as any).sessionVersion || 1) + 1);
      await db.update(users).set({ passwordHash: await hashPassword(password), resetToken: null, resetExpires: null, sessionVersion: newVersion }).where(eq(users.id, u.id));
      await db.update(accountRecoveryRequests).set({ status: "completed", usedAt: new Date(), updatedAt: new Date() }).where(eq(accountRecoveryRequests.id, r.id));
      await logAuthEvent({ req, userId: u.id, identifier: r.identifier, event: "account_recovery_completed", success: true, detail: r.code });
      return NextResponse.json({ ok: true, note: "Senha atualizada com segurança. Faça login com a nova senha." });
    }

    return NextResponse.json({ error: "Ação inválida." }, { status: 400 });
  } catch (error) {
    console.error("recovery error", error instanceof Error ? error.message : "unknown error");
    return NextResponse.json({ error: "Erro no servidor. Tente novamente." }, { status: 500 });
  }
}
