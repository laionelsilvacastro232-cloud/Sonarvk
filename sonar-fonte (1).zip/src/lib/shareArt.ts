"use client";

/**
 * Gera a arte de divulgação de uma música (stories 9:16 ou feed 4:5),
 * tenta abrir o compartilhamento nativo do dispositivo e, se não houver
 * suporte, baixa a imagem automaticamente. Nunca lança erro para a UI.
 */
export async function shareTrackArt(opts: {
  trackId: string;
  format: "stories" | "feed";
  title: string;
  artistName: string;
}): Promise<{ ok: boolean; mode: "shared" | "downloaded"; error?: string }> {
  const { trackId, format, title, artistName } = opts;
  try {
    const url = `${window.location.origin}/api/story/track/${trackId}?format=${format}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Não foi possível gerar a arte.");
    const blob = await res.blob();
    const ext = format === "stories" ? "9x16" : "4x5";
    const fileName = `sonarbr-${title.slice(0, 30).replace(/\s+/g, "-").toLowerCase()}-${ext}.png`;
    const file = new File([blob], fileName, { type: "image/png" });

    // 1) compartilhamento nativo com imagem (celular)
    if (typeof navigator !== "undefined" && navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title, text: `${title} — ${artistName} no SonarBR` });
        return { ok: true, mode: "shared" };
      } catch (e) {
        // usuário cancelou: não é erro
        if ((e as Error)?.name === "AbortError") return { ok: true, mode: "shared" };
        // senão, cai para o download
      }
    }
    // 2) fallback: baixa a imagem
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objectUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    return { ok: true, mode: "downloaded" };
  } catch (e) {
    return { ok: false, mode: "downloaded", error: (e as Error)?.message || "Falha ao gerar a arte." };
  }
}
