import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, type PoolConfig } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

// Compatível com PostgreSQL local, Neon e Supabase (Postgres).
// Bancos hospedados normalmente exigem SSL; bancos locais normalmente não.
function poolConfig(connectionString: string): PoolConfig {
  let needsSsl = /sslmode=require/i.test(connectionString);
  try {
    const url = new URL(connectionString);
    const host = url.hostname.toLowerCase();
    if (host.includes("neon.tech") || host.includes("supabase.co") || host.includes("supabase.com")) needsSsl = true;
  } catch {
    // Se a URL não puder ser analisada, o driver apresentará o erro real de conexão.
  }

  return {
    connectionString,
    max: Number(process.env.DB_POOL_MAX || 5),
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 15_000,
    ...(needsSsl ? { ssl: { rejectUnauthorized: false } } : {}),
  };
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool(poolConfig(databaseUrl));

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
