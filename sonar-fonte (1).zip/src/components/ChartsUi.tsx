"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Cover } from "@/components/Cover";

import type { ChartRow, ChartScope } from "@/lib/charts";

function TabRow({ param, entries, current }: { param: string; entries: [string, string][]; current: string }) {
  const router = useRouter();
  const sp = useSearchParams();
  function go(v: string) {
    const p = new URLSearchParams(sp.toString());
    if (current === v) return;
    p.set(param, v);
    router.push(`/charts?${p.toString()}`);
  }
  return (
    <div className="flex gap-2 overflow-x-auto">
      {entries.map(([v, label]) => (
        <button key={v} onClick={() => go(v)} data-active={current === v} className="chip shrink-0">
          {label}
        </button>
      ))}
    </div>
  );
}

export function ChartScopeTabs({ scope }: { scope: ChartScope }) {
  const entries: [string, string][] = [
    ["musicas", "Músicas"],
    ["artistas", "Artistas"],
  ];
  return <TabRow param="escopo" entries={entries} current={scope === "artists" ? "artistas" : "musicas"} />;
}

export function ChartPeriodTabs({ period }: { period: string }) {
  const entries: [string, string][] = [
    ["semana", "Semana"],
    ["mes", "Mês"],
    ["geral", "Geral"],
  ];
  const cur = period === "month" ? "mes" : period === "all" ? "geral" : "semana";
  return <TabRow param="periodo" entries={entries} current={cur} />;
}

function ChangeBadge({ change }: { change: number | null }) {
  if (change == null)
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-[color:var(--border-strong)] px-2 py-0.5 text-[11px] font-semibold text-[color:var(--text)/0.55]">
        novo
      </span>
    );
  if (change > 0)
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-[color:var(--border-strong)] bg-[color:var(--accent)/0.1] px-2 py-0.5 text-[11px] font-semibold text-[var(--accent-text)]">
        <span aria-hidden>↑</span>
        {change}
      </span>
    );
  if (change < 0)
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-[color:var(--border-strong)] px-2 py-0.5 text-[11px] font-semibold text-[color:var(--text)/0.5]">
        <span aria-hidden>↓</span>
        {Math.abs(change)}
      </span>
    );
  return (
    <span className="inline-flex items-center rounded-full border border-[color:var(--border)] px-2 py-0.5 text-[11px] font-semibold text-[color:var(--text)/0.4]">
      =
    </span>
  );
}

export function ChartList({ rows, scope }: { rows: ChartRow[]; scope: ChartScope }) {
  return (
    <ol className="space-y-2">
      {rows.map((r) => (
        <li key={r.targetId}>
          <Link
            href={r.href}
            className="group flex items-center gap-3 rounded-xl border border-[color:var(--border)] p-2.5 transition hover-soft sm:gap-4 sm:p-3"
          >
            <span className="w-8 shrink-0 text-center text-lg font-extrabold tabular-nums text-[color:var(--text)/0.5] group-hover:text-[var(--accent-text)]">
              {r.position}
            </span>
            <span className="h-12 w-12 shrink-0 sm:h-14 sm:w-14">
              <Cover src={r.coverUrl} seed={r.targetId} title={r.title} round={scope === "artists"} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-semibold">{r.title}</span>
              <span className="block truncate text-xs text-[color:var(--text)/0.5]">{r.subtitle}</span>
            </span>
            <ChangeBadge change={r.change} />
          </Link>
        </li>
      ))}
    </ol>
  );
}
