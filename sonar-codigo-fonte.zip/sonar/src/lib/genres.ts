// Lista oficial de gêneros do SONAR (nomes corretos, sem duplicações).
// Bossa Nova é gênero próprio. Nada de misturas vagas como "Pop/Rock".
export const CANONICAL_GENRES = [
  "Pop","Rock","Hip-Hop/Rap","Trap","R&B/Soul","Eletrônica","Funk Brasileiro","Sertanejo","MPB","Samba","Pagode",
  "Bossa Nova","Jazz","Blues","Reggae","Gospel","Música Clássica","Country","Indie/Alternativo","K-Pop",
  "Música Latina","Música Africana","Música Asiática","Folk","Metal","Forró","Axé","Piseiro","Lo-fi",
] as const;

// Converte nomes antigos/confusos para o gênero oficial mais próximo.
const ALIASES: Record<string,string> = {
  "pop alternativo":"Indie/Alternativo",
  "indie":"Indie/Alternativo",
  "indie/ alternativo":"Indie/Alternativo",
  "rock alternativo":"Rock",
  "pop/rock":"Pop",
  "pop rock":"Pop",
  "soul / r&b":"R&B/Soul",
  "soul/r&b":"R&B/Soul",
  "r&b":"R&B/Soul",
  "soul":"R&B/Soul",
  "jazz / bossa":"Bossa Nova",
  "bossa":"Bossa Nova",
  "hip hop":"Hip-Hop/Rap",
  "rap":"Hip-Hop/Rap",
  "hip-hop":"Hip-Hop/Rap",
  "eletronica":"Eletrônica",
  "electronic":"Eletrônica",
  "funk":"Funk Brasileiro",
  "musica classica":"Música Clássica",
  "classica":"Música Clássica",
  "latina":"Música Latina",
  "africana":"Música Africana",
  "asiatica":"Música Asiática",
  "lofi":"Lo-fi",
  "lo fi":"Lo-fi",
};

export function normalizeGenre(raw?: string|null): string {
  const g=(raw||"").trim();
  if(!g) return "";
  const exact=(CANONICAL_GENRES as readonly string[]).find(c=>c.toLowerCase()===g.toLowerCase());
  if(exact) return exact;
  return ALIASES[g.toLowerCase()] || g;
}
