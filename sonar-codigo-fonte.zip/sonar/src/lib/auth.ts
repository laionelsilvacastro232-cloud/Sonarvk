import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "noir-dev-secret-change-in-production-32chars");
export const hashPassword = (p: string) => bcrypt.hash(p, 10);
export const verifyPassword = (p: string, h: string) => bcrypt.compare(p, h);
const SESSION_DAYS = 30; // sessão longa: atualizar o app não derruba o usuário
const COOKIE_NAME = "noir_session";

export async function createSession(userId: number, role: string, sessionVersion = 1) {
  const token = await new SignJWT({ userId, role, v: sessionVersion || 1 })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(secret);
  const c = await cookies();
  c.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * SESSION_DAYS,
    secure: process.env.NODE_ENV === "production",
  });
  return token;
}

export async function setSessionCookie(token: string) {
  const c = await cookies();
  c.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * SESSION_DAYS,
    secure: process.env.NODE_ENV === "production",
  });
}

export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, secret);
    return payload as { userId: number; role: string; v?: number };
  } catch {
    return null;
  }
}

export async function destroySession() {
  const c = await cookies();
  c.delete(COOKIE_NAME);
}

export async function getSession() {
  try {
    const c = await cookies();
    const t = c.get(COOKIE_NAME)?.value;
    if (!t) return null;
    return await verifyToken(t);
  } catch {
    return null;
  }
}

export async function getCurrentUser() {
  const s = await getSession();
  if (!s) return null;
  const [u] = await db.select().from(users).where(eq(users.id, s.userId)).limit(1);
  if (!u || u.suspended) return null;
  // Tokens antigos sem versão valem como v1. "Sair de todos os dispositivos"
  // aumenta session_version no banco e invalida todos os JWTs anteriores.
  if ((s.v || 1) !== ((u as any).sessionVersion || 1)) return null;
  return u;
}

export function publicUser(u: any) {
  if (!u) return null;
  const { passwordHash, resetToken, resetExpires, ...rest } = u;
  return rest;
}
