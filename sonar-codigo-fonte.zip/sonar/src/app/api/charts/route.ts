import { NextResponse } from "next/server";
import { db } from "@/db";
import { tracks, artists, chartSnapshots } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { ensureSeed } from "@/lib/catalog";

// Charts REAIS: ranking calculado pelas reproduções registradas no banco (plays).
// A cada dia, o primeiro acesso grava um snapshot — ele vira a "posição anterior".
async function ensureSnapshot() {
  const today = new Date().toISOString().slice(0, 10);
  const existing = await db.select().from(chartSnapshots).where(eq(chartSnapshots.snapshotDate, today)).limit(1);
  if (existing.length) return;
  const ranked = await db.select().from(tracks).where(eq(tracks.published, true)).orderBy(desc(tracks.plays));
  let i = 0;
  for (const t of ranked) { i++; await db.insert(chartSnapshots).values({ trackId: t.id, position: i, plays: t.plays || 0, snapshotDate: today }); }
}

export async function GET(req: Request) {
  await ensureSeed();
  await ensureSnapshot();
  const url = new URL(req.url);
  const genre = url.searchParams.get("genre") || "";
  const allArtists = await db.select().from(artists);
  const aMap = new Map(allArtists.map(a => [a.id, a]));
  const published = await db.select().from(tracks).where(eq(tracks.published, true)).orderBy(desc(tracks.plays));

  // datas registradas
  const allSnaps = await db.select().from(chartSnapshots).orderBy(desc(chartSnapshots.snapshotDate));
  const dates = [...new Set(allSnaps.map(x => x.snapshotDate))];
  const today = new Date().toISOString().slice(0, 10);
  const prevDate = dates.find(d => d < today) || null;
  const prevSnaps = prevDate ? allSnaps.filter(x => x.snapshotDate === prevDate) : [];

  // posição anterior por faixa (respeitando o filtro de gênero)
  function prevPosByGenre(rows: any[]) {
    const byGenre = new Map<string, any[]>();
    for (const s of rows) {
      const tr = published.find(t => t.id === s.trackId); if (!tr) continue;
      const g = tr.genre || ""; if (!byGenre.has(g)) byGenre.set(g, []);
      byGenre.get(g)!.push({ ...s, _plays: s.plays });
    }
    const map = new Map<number, number>();
    for (const [, arr] of byGenre) { arr.sort((a, b) => b._plays - a._plays).forEach((s, idx) => map.set(s.trackId, idx + 1)); }
    // ranking geral anterior
    [...rows].sort((a, b) => a.position - b.position).forEach(s => { if (!map.has(s.trackId)) map.set(s.trackId, s.position); });
    return map;
  }
  const prevMap = prevPosByGenre(prevSnaps);

  let cur = published;
  if (genre) cur = cur.filter(t => (t.genre || "") === genre);
  const trackChart = cur.slice(0, 50).map((t, i) => {
    const prev = prevMap.get(t.id);
    return {
      position: i + 1, previousPosition: prev ?? null, change: prev ? prev - (i + 1) : null, isNew: !prev,
      track: { ...t, artist: aMap.get(t.artistId) || null },
    };
  });

  // artistas: soma de plays das faixas
  const agg = (list: any[]) => {
    const m = new Map<number, number>();
    for (const t of list) m.set(t.artistId, (m.get(t.artistId) || 0) + (t.plays || 0));
    return m;
  };
  const curAgg = agg(cur.length && genre ? cur : published);
  const prevAggMap = new Map<number, number>();
  for (const s of prevSnaps) { const tr = published.find(t => t.id === s.trackId); if (tr && (!genre || (tr.genre || "") === genre)) prevAggMap.set(tr.artistId, (prevAggMap.get(tr.artistId) || 0) + s.plays); }
  const prevArtistRank = [...prevAggMap.entries()].sort((a, b) => b[1] - a[1]).map(e => e[0]);
  const artistChart = [...curAgg.entries()].sort((a, b) => b[1] - a[1]).slice(0, 30).map(([artistId, plays], i) => {
    const prevIdx = prevArtistRank.indexOf(artistId);
    return { position: i + 1, previousPosition: prevIdx >= 0 ? prevIdx + 1 : null, change: prevIdx >= 0 ? (prevIdx + 1) - (i + 1) : null, isNew: prevIdx < 0, plays, artist: aMap.get(artistId) || null };
  }).filter(x => x.artist);

  const genres = [...new Set(published.map(t => t.genre || "").filter(Boolean))];
  return NextResponse.json({
    methodology: "Ranking calculado pelas reproduções registradas na SONAR (campo plays, somado a cada reprodução). Snapshot diário guarda a posição anterior.",
    updatedAt: new Date().toISOString(), previousDate: prevDate, history: dates.slice(0, 14), genre,
    genres, tracks: trackChart, artists: artistChart,
  });
}
