"use client";

import { useState } from "react";
import { IconShare } from "@/components/Icons";

/**
 * Botão "Stories": gera um card vertical (1080x1920) da playlist e abre o
 * compartilhamento nativo (celular) ou baixa a imagem para postar no story.
 * O link incluso aponta para a playlist na plataforma.
 */
export function StoryShare({ playlistId, name }: { playlistId: string; name: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function share() {
    setBusy(true);
    setError(null);
    try {
      const url = `${window.location.origin}/api/story/playlist/${playlistId}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Não foi possível gerar a imagem.");
      const blob = await res.blob();
      const file = new File([blob], "story.png", { type: "image/png" });

      // tenta compartilhar a imagem diretamente (celular)
      if (navigator.canShare?.({ files: [file] })) {
        await navigator.share({ files: [file], title: name, text: `${name} no SonarBR` });
        return;
      }
      // fallback: baixa a imagem
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `story-${name.slice(0, 30).replace(/\s+/g, "-").toLowerCase()}.png`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (e) {
      if ((e as Error).name !== "AbortError") setError((e as Error).message || "Falha ao compartilhar.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <span className="inline-flex flex-col gap-1">
      <button onClick={share} disabled={busy} className="btn-outline" title="Gerar imagem para Stories">
        <IconShare size={18} /> {busy ? "Gerando…" : "Stories"}
      </button>
      {error && <span className="text-xs text-[color:var(--text)/0.6]">{error}</span>}
    </span>
  );
}
