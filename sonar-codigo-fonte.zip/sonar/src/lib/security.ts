import { db } from "@/db";
import { authEvents, emailLogs } from "@/db/schema";

export function requestIp(req: Request) {
  return (req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "local").split(",")[0].trim().slice(0, 80);
}

export function requestUserAgent(req: Request) {
  return (req.headers.get("user-agent") || "").slice(0, 300);
}

export async function logAuthEvent(input: {
  req?: Request;
  userId?: number | null;
  identifier?: string;
  event: string;
  success: boolean;
  detail?: string;
}) {
  try {
    await db.insert(authEvents).values({
      userId: input.userId || null,
      identifier: (input.identifier || "").toLowerCase().slice(0, 160),
      event: input.event.slice(0, 60),
      success: input.success,
      ip: input.req ? requestIp(input.req) : "",
      userAgent: input.req ? requestUserAgent(input.req) : "",
      detail: (input.detail || "").slice(0, 240),
    });
  } catch (error) {
    // Auditoria nunca deve derrubar o login; apenas registra a falha internamente.
    console.error("auth event log failed", error instanceof Error ? error.message : "unknown error");
  }
}

export async function logEmailEvent(input: {
  userId?: number | null;
  kind: string;
  provider: string;
  status: "sent" | "failed" | "not_configured";
  error?: string;
}) {
  try {
    await db.insert(emailLogs).values({
      userId: input.userId || null,
      kind: input.kind.slice(0, 60),
      provider: (input.provider || "none").slice(0, 30),
      status: input.status,
      error: (input.error || "").slice(0, 120),
    });
  } catch (error) {
    console.error("email log failed", error instanceof Error ? error.message : "unknown error");
  }
}
