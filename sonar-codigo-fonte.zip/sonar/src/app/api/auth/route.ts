import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, notifications, siteSettings } from "@/db/schema";
import { eq, or } from "drizzle-orm";
import { hashPassword, verifyPassword, createSession, destroySession, getCurrentUser, publicUser, verifyToken, setSessionCookie } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";
import { mailConfigured, mailProvider, resetLinkEmail, sendMailDetailed } from "@/lib/mail";
import { getAppOrigin } from "@/lib/app-url";
import { logAuthEvent, logEmailEvent, requestIp } from "@/lib/security";
import crypto from "crypto";

// Limite anti-abuso (muitas pessoas acessando): por IP + ação
const hits = new Map<string, number[]>();
function rateLimit(key: string, max: number, windowMs: number) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  arr.push(now);
  hits.set(key, arr);
  return arr.length > max;
}
function ipOf(req: Request) { return requestIp(req); }
function sha256(value: string) { return crypto.createHash("sha256").update(value).digest("hex"); }

export async function GET() {
  await ensureSeed();
  const u = await getCurrentUser();
  return NextResponse.json({ user: u ? publicUser(u) : null });
}

export async function POST(req: Request) {
  await ensureSeed();
  const body = await req.json().catch(() => ({}));
  const { action } = body;
  const ip = ipOf(req);
  try {
    if (action === "restore") {
      // Restaura a sessão a partir do token guardado no aparelho (sobrevive a atualização/troca de link)
      const payload = body.token ? await verifyToken(body.token) : null;
      if (!payload) return NextResponse.json({ error: "Sessão expirada. Faça login novamente." }, { status: 401 });
      const [u] = await db.select().from(users).where(eq(users.id, payload.userId)).limit(1);
      if (!u || u.suspended) return NextResponse.json({ error: "Conta indisponível." }, { status: 401 });
      if ((payload.v || 1) !== ((u as any).sessionVersion || 1)) return NextResponse.json({ error: "Sessão encerrada em outro dispositivo." }, { status: 401 });
      await setSessionCookie(body.token);
      return NextResponse.json({ user: publicUser(u) });
    }

    if (action === "register") {
      if (rateLimit(`reg:${ip}`, 10, 10 * 60 * 1000)) return NextResponse.json({ error: "Muitas tentativas. Aguarde alguns minutos." }, { status: 429 });
      const name = (body.displayName || "").trim();
      const mail = (body.email || "").toLowerCase().trim();
      if (!name || name.length > 80) return NextResponse.json({ error: "Digite seu nome para criar a conta." }, { status: 400 });
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return NextResponse.json({ error: "Digite um e-mail válido." }, { status: 400 });
      if (!body.password || body.password.length < 6 || body.password.length > 128) return NextResponse.json({ error: "A senha precisa ter entre 6 e 128 caracteres." }, { status: 400 });
      const [byEmail] = await db.select().from(users).where(eq(users.email, mail)).limit(1);
      if (byEmail) {
        await logAuthEvent({ req, identifier: mail, event: "register_duplicate", success: false });
        return NextResponse.json({ error: "Este e-mail já tem uma conta. Toque em Entrar e faça login." }, { status: 409 });
      }
      // @ gerado automaticamente a partir do nome: sempre único, nunca bloqueia o cadastro
      const base = (name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "") || "usuario").slice(0, 20);
      let username = base;
      let suffix = 1;
      while (true) {
        const [taken] = await db.select().from(users).where(eq(users.username, username)).limit(1);
        if (!taken) break;
        suffix++;
        username = base + suffix;
      }
      const [u] = await db.insert(users).values({ email: mail, username, displayName: name, passwordHash: await hashPassword(body.password), bio: "", avatarUrl: "" }).returning();
      await db.insert(notifications).values({ userId: u.id, title: "Bem-vindo(a) à SONAR", body: "Sua conta foi criada. Explore o catálogo, siga artistas e monte sua primeira playlist." });
      await logAuthEvent({ req, userId: u.id, identifier: mail, event: "register", success: true });
      const token = await createSession(u.id, u.role, (u as any).sessionVersion || 1);
      return NextResponse.json({ user: publicUser(u), token });
    }

    if (action === "login") {
      if (rateLimit(`login:${ip}`, 20, 10 * 60 * 1000)) return NextResponse.json({ error: "Muitas tentativas. Aguarde alguns minutos." }, { status: 429 });
      const ident = (body.email || "").toLowerCase().trim();
      const [u] = await db.select().from(users).where(or(eq(users.email, ident), eq(users.username, ident))).limit(1);
      if (!u) {
        await logAuthEvent({ req, identifier: ident, event: "login_failed", success: false, detail: "account_not_found" });
        return NextResponse.json({ error: "Conta não encontrada. Verifique os dados ou cadastre-se." }, { status: 401 });
      }
      if (u.suspended) {
        await logAuthEvent({ req, userId: u.id, identifier: ident, event: "login_failed", success: false, detail: "suspended" });
        return NextResponse.json({ error: "Conta suspensa. Fale com o suporte." }, { status: 403 });
      }
      if (!(await verifyPassword(body.password || "", u.passwordHash))) {
        await logAuthEvent({ req, userId: u.id, identifier: ident, event: "login_failed", success: false, detail: "wrong_password" });
        return NextResponse.json({ error: "Senha incorreta. Tente de novo ou toque em 'Esqueci minha senha'." }, { status: 401 });
      }
      await logAuthEvent({ req, userId: u.id, identifier: ident, event: "login", success: true });
      const token = await createSession(u.id, u.role, (u as any).sessionVersion || 1);
      return NextResponse.json({ user: publicUser(u), token });
    }

    if (action === "logout") {
      const me = await getCurrentUser();
      if (me) await logAuthEvent({ req, userId: me.id, identifier: me.email, event: "logout", success: true });
      await destroySession();
      return NextResponse.json({ ok: true });
    }

    if (action === "forgot") {
      if (rateLimit(`forgot:${ip}`, 6, 10 * 60 * 1000)) return NextResponse.json({ error: "Muitas tentativas. Aguarde alguns minutos." }, { status: 429 });
      const mail = (body.email || "").toLowerCase().trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return NextResponse.json({ error: "Digite um e-mail válido para receber o link de redefinição." }, { status: 400 });
      if (rateLimit(`forgot-mail:${mail}`, 3, 15 * 60 * 1000)) return NextResponse.json({ error: "Você já pediu links demais para este e-mail. Aguarde 15 minutos." }, { status: 429 });
      const [u] = await db.select().from(users).where(eq(users.email, mail)).limit(1);
      if (!mailConfigured()) {
        if (u) await logEmailEvent({ userId: u.id, kind: "password_reset_link", provider: mailProvider(), status: "not_configured", error: "not_configured" });
        await logAuthEvent({ req, userId: u?.id || null, identifier: mail, event: "password_reset_requested", success: false, detail: "email_not_configured" });
        return NextResponse.json({ error: "O envio automático por e-mail ainda não está ativo no servidor. Nenhum link foi gerado na tela." }, { status: 503 });
      }
      // Resposta genérica: não revela se o e-mail possui conta e nunca devolve o token ao navegador.
      if (!u) return NextResponse.json({ ok: true, sent: true, note: "Se este e-mail tiver uma conta, enviamos um link seguro para redefinir a senha. Ele vale 30 minutos. Confira a caixa de entrada e o spam." });

      const rawToken = crypto.randomBytes(32).toString("hex");
      const tokenHash = sha256(rawToken);
      await db.update(users).set({ resetToken: tokenHash, resetExpires: new Date(Date.now() + 30 * 60 * 1000) }).where(eq(users.id, u.id));
      const [s] = await db.select().from(siteSettings).limit(1);
      const siteName = s?.siteName || "SONAR";
      const resetUrl = `${getAppOrigin(req)}/redefinir?token=${encodeURIComponent(rawToken)}`;
      const result = await sendMailDetailed(mail, `${siteName} — redefinir sua senha`, (await import("@/lib/mail")).resetLinkEmail(siteName, resetUrl));
      await logEmailEvent({ userId: u.id, kind: "password_reset_link", provider: result.provider, status: result.ok ? "sent" : "failed", error: result.ok ? "" : result.error });
      await logAuthEvent({ req, userId: u.id, identifier: mail, event: "password_reset_requested", success: result.ok, detail: result.ok ? "email_sent" : "email_failed" });
      if (!result.ok) {
        await db.update(users).set({ resetToken: null, resetExpires: null }).where(eq(users.id, u.id));
        return NextResponse.json({ error: "Não conseguimos entregar o e-mail agora. Tente novamente em instantes." }, { status: 502 });
      }
      return NextResponse.json({ ok: true, sent: true, note: "Link seguro enviado para o seu e-mail. Ele vale 30 minutos e só pode ser usado uma vez. Confira também o spam." });
    }

    if (action === "reset") {
      const supplied = (body.token || body.code || "").trim();
      const mail = (body.email || "").toLowerCase().trim();
      if (!supplied || !body.password || body.password.length < 6 || body.password.length > 128) {
        return NextResponse.json({ error: "Abra o link recebido no e-mail e crie uma nova senha (mínimo 6 caracteres)." }, { status: 400 });
      }
      let u: any = null;
      if (supplied.length >= 32) {
        const tokenHash = sha256(supplied);
        const [byToken] = await db.select().from(users).where(eq(users.resetToken, tokenHash)).limit(1);
        u = byToken || null;
      } else if (/^\d{6}$/.test(supplied)) {
        // Compatibilidade com códigos antigos de 6 dígitos já enviados.
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return NextResponse.json({ error: "Informe o mesmo e-mail onde você recebeu o código." }, { status: 400 });
        const [byMail] = await db.select().from(users).where(eq(users.email, mail)).limit(1);
        const codeHash = byMail ? sha256(`${byMail.id}:${mail}:${supplied}`) : "";
        u = byMail && byMail.resetToken && (byMail.resetToken === codeHash || byMail.resetToken === supplied) ? byMail : null;
      }
      if (!u) {
        await logAuthEvent({ req, identifier: mail, event: "password_reset_failed", success: false, detail: "invalid_token" });
        return NextResponse.json({ error: "Link inválido ou já utilizado. Peça um novo em 'Esqueci minha senha'." }, { status: 400 });
      }
      if (!u.resetExpires || new Date(u.resetExpires).getTime() < Date.now()) {
        await logAuthEvent({ req, userId: u.id, identifier: u.email, event: "password_reset_failed", success: false, detail: "expired_token" });
        return NextResponse.json({ error: "Link expirado. Peça um novo em 'Esqueci minha senha'." }, { status: 400 });
      }
      const newVersion = (((u as any).sessionVersion || 1) + 1);
      await db.update(users).set({ passwordHash: await hashPassword(body.password), resetToken: null, resetExpires: null, sessionVersion: newVersion }).where(eq(users.id, u.id));
      await logAuthEvent({ req, userId: u.id, identifier: u.email, event: "password_reset_completed", success: true });
      return NextResponse.json({ ok: true, note: "Senha redefinida! Faça login com a nova senha." });
    }

    // authenticated actions
    const me = await getCurrentUser();
    if (!me) return NextResponse.json({ error: "Faça login para continuar." }, { status: 401 });

    if (action === "logout-all") {
      const newVersion = (((me as any).sessionVersion || 1) + 1);
      await db.update(users).set({ sessionVersion: newVersion }).where(eq(users.id, me.id));
      await logAuthEvent({ req, userId: me.id, identifier: me.email, event: "logout_all_devices", success: true });
      await destroySession();
      return NextResponse.json({ ok: true, note: "Você saiu de todos os dispositivos." });
    }

    if (action === "change-password") {
      if (!(await verifyPassword(body.current || "", me.passwordHash))) return NextResponse.json({ error: "Senha atual incorreta." }, { status: 400 });
      if (!body.next || body.next.length < 6) return NextResponse.json({ error: "Nova senha precisa de 6+ caracteres." }, { status: 400 });
      const newVersion = (((me as any).sessionVersion || 1) + 1);
      await db.update(users).set({ passwordHash: await hashPassword(body.next), sessionVersion: newVersion }).where(eq(users.id, me.id));
      await createSession(me.id, me.role, newVersion);
      await logAuthEvent({ req, userId: me.id, identifier: me.email, event: "password_changed", success: true });
      return NextResponse.json({ ok: true });
    }

    if (action === "update-profile") {
      const [u] = await db.update(users).set({ displayName: body.displayName || me.displayName, bio: body.bio ?? me.bio, avatarUrl: body.avatarUrl ?? me.avatarUrl, historyPrivate: !!body.historyPrivate }).where(eq(users.id, me.id)).returning();
      return NextResponse.json({ user: publicUser(u) });
    }

    if (action === "delete-account") {
      await logAuthEvent({ req, userId: me.id, identifier: me.email, event: "account_deleted", success: true });
      await db.delete(users).where(eq(users.id, me.id));
      await destroySession();
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Ação inválida." }, { status: 400 });
  } catch (e: any) {
    // Conflito de unicidade (corrida entre dois cadastros iguais) vira mensagem clara, não erro 500.
    if (action === "register" && (e?.code === "23505" || /duplicate key|unique/i.test(String(e?.message || "")))) {
      return NextResponse.json({ error: "Este e-mail já tem uma conta. Toque em Entrar e faça login." }, { status: 409 });
    }
    console.error("auth error", e instanceof Error ? e.message : "unknown error");
    return NextResponse.json({ error: "Erro no servidor. Tente novamente." }, { status: 500 });
  }
}
