import { ImageResponse } from "next/og";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { albums, artists, tracks } from "@/db/schema";

export const dynamic = "force-dynamic";

function esc(s: string) {
  return s.replace(/[<>&'"]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" }[c]!));
}
function clamp(text: string, max: number) {
  const t = text.trim();
  return t.length > max ? t.slice(0, max - 1).trimEnd() + "…" : t;
}

// formatos: stories=9:16 (1080x1920), feed=4:5 (1080x1350)
const FORMATS = {
  stories: { w: 1080, h: 1920 },
  feed: { w: 1080, h: 1350 },
} as const;

async function toDataUrl(url: string | null): Promise<string | null> {
  if (!url) return null;
  const res = await fetch(url).catch(() => null);
  if (!res || !res.ok) return null;
  const buf = await res.arrayBuffer();
  const ct = res.headers.get("content-type") || "image/jpeg";
  return `data:${ct};base64,${Buffer.from(buf).toString("base64")}`;
}

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const url = new URL(_req.url);
  const formatParam = url.searchParams.get("format") === "feed" ? "feed" : "stories";
  const { w, h } = FORMATS[formatParam];

  const [tr] = await db
    .select({ title: tracks.title, artistName: artists.name, coverUrl: tracks.coverUrl, albumCover: albums.coverUrl, albumTitle: albums.title })
    .from(tracks)
    .innerJoin(artists, eq(artists.id, tracks.artistId))
    .leftJoin(albums, eq(albums.id, tracks.albumId))
    .where(and(eq(tracks.id, id), eq(tracks.status, "published")))
    .limit(1);

  if (!tr) {
    return new ImageResponse(
      (<div style={{ width: "100%", height: "100%", background: "#0a0a0a", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif", fontSize: 44 }}>Música indisponível</div>),
      { width: w, height: h },
    );
  }

  const cover = await toDataUrl(tr.coverUrl ?? tr.albumCover);
  // no feed a capa é menor e o texto mais próximo; no stories mais respiro
  const isFeed = formatParam === "feed";
  const coverSize = isFeed ? 620 : 720;
  const titleSize = isFeed ? 64 : 76;
  const pad = isFeed ? 70 : 90;

  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", background: "#000", color: "#fff", display: "flex", flexDirection: "column", padding: pad, fontFamily: "sans-serif" }}>
        {/* marca */}
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <div style={{ width: 58, height: 58, borderRadius: 16, border: "3px solid #fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32, fontWeight: 800 }}>S</div>
          <div style={{ fontSize: 38, fontWeight: 800, letterSpacing: -1 }}>SonarBR</div>
        </div>

        <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
          <div style={{ width: coverSize, height: coverSize, borderRadius: 28, background: "#151515", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 40px 120px rgba(255,255,255,0.08)" }}>
            {cover ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={cover} width={coverSize} height={coverSize} style={{ objectFit: "cover" }} alt="" />
            ) : (
              <div style={{ fontSize: Math.round(coverSize * 0.32), fontWeight: 800, color: "#fff", opacity: 0.85 }}>{esc(clamp(tr.title, 1).charAt(0).toUpperCase())}</div>
            )}
          </div>

          <div style={{ fontSize: titleSize, fontWeight: 800, letterSpacing: -2, marginTop: isFeed ? 44 : 60, textAlign: "center", maxWidth: isFeed ? 900 : 920 }}>
            {esc(clamp(tr.title, 40))}
          </div>
          <div style={{ fontSize: isFeed ? 38 : 42, color: "rgba(255,255,255,0.6)", marginTop: 22, textAlign: "center", maxWidth: 880 }}>
            {esc(clamp(tr.artistName, 40))}
          </div>
          {tr.albumTitle && (
            <div style={{ fontSize: 30, color: "rgba(255,255,255,0.4)", marginTop: 16 }}>{esc(clamp(tr.albumTitle, 50))}</div>
          )}
        </div>

        {/* rodapé */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ fontSize: isFeed ? 34 : 36, fontWeight: 800, border: "3px solid #fff", borderRadius: 999, padding: isFeed ? "14px 32px" : "16px 36px" }}>Ouvir agora</div>
        </div>
        <div style={{ fontSize: 28, color: "rgba(255,255,255,0.4)", marginTop: 24, textAlign: "center", width: "100%" }}>Ouça no SonarBR</div>
      </div>
    ),
    { width: w, height: h },
  );
}
