/**
 * Categorias musicais canônicas do SonarBR.
 *
 * Cada categoria tem um nome oficial e uma lista de apelidos (aliases) que
 * aparecem em metadados importados de APIs externas. O alias permite agrupar
 * variações sem misturar gêneros distintos na mesma categoria.
 *
 * Regras seguidas:
 * - Bossa Nova e Samba sao categorias proprias, nunca subgeneros de MPB ou Pop.
 * - Nenhuma categoria junta dois generos sem relacao (nao existe "Pop/Rock").
 * - Nomes consistentes, com acentuacao correta e em portugues.
 */
export type Genre = { name: string; slug: string; aliases: string[] };

export const GENRES: Genre[] = [
  { name: "Pop", slug: "pop", aliases: ["pop", "pop latino", "k-pop", "kpop", "dance pop", "synth-pop"] },
  { name: "Rock", slug: "rock", aliases: ["rock", "rock and roll", "rock & roll", "hard rock", "rock nacional"] },
  { name: "Hip-Hop/Rap", slug: "hip-hop-rap", aliases: ["hip hop", "hip-hop", "rap", "trap", "drill", "r&b/hip hop", "boom bap"] },
  { name: "R&B/Soul", slug: "rnb-soul", aliases: ["r&b", "rhythm and blues", "soul", "neo soul", "funk"] },
  { name: "Eletrônica", slug: "eletronica", aliases: ["electronic", "eletronica", "edm", "house", "techno", "trance", "drum and bass", "dubstep", "deep house", "ambient", "lo-fi beats"] },
  { name: "Funk Brasileiro", slug: "funk-brasileiro", aliases: ["funk carioca", "funk ostentação", "funk", "funk 150", "baile funk"] },
  { name: "Sertanejo", slug: "sertanejo", aliases: ["sertanejo", "sertanejo universitário", "sertanejo raiz"] },
  { name: "MPB", slug: "mpb", aliases: ["mpb", "música popular brasileira", "musica popular brasileira"] },
  { name: "Samba", slug: "samba", aliases: ["samba", "samba-enredo", "samba de roda"] },
  { name: "Pagode", slug: "pagode", aliases: ["pagode", "pagodão", "samba pagode"] },
  { name: "Bossa Nova", slug: "bossa-nova", aliases: ["bossa nova", "bossanova", "bossa"] },
  { name: "Jazz", slug: "jazz", aliases: ["jazz", "bebop", "smooth jazz", "jazz fusion"] },
  { name: "Blues", slug: "blues", aliases: ["blues"] },
  { name: "Reggae", slug: "reggae", aliases: ["reggae", "dancehall", "ska", "rocksteady"] },
  { name: "Gospel", slug: "gospel", aliases: ["gospel", "gospel/adoração", "worship", "coral"] },
  { name: "Música Clássica", slug: "classica", aliases: ["classical", "clássica", "classica", "orquestra", "sinfonia", "música de câmara"] },
  { name: "Country", slug: "country", aliases: ["country", "americana", "bluegrass"] },
  { name: "Indie/Alternativo", slug: "indie-alternativo", aliases: ["indie", "alternative", "alternativo", "indie rock", "shoegaze", "dream pop"] },
  { name: "K-Pop", slug: "k-pop", aliases: ["kpop", "k-pop", "korean pop"] },
  { name: "Música Latina", slug: "latina", aliases: ["latin", "latina", "reguetón", "reggaeton", "cumbia", "bachata", "salsa", "mariachi", "latin pop"] },
  { name: "Música Africana", slug: "africana", aliases: ["african", "africana", "afrobeat", "afrobeats", "highlife", "mbalax"] },
  { name: "Música Asiática", slug: "asiatica", aliases: ["asian", "asiática", "asiatica", "j-pop", "jpop", "c-pop", "cantopop", "city pop", "anime"] },
  { name: "Folk", slug: "folk", aliases: ["folk", "folkrock", "caipira", "world"] },
  { name: "Metal", slug: "metal", aliases: ["metal", "heavy metal", "thrash", "death metal", "metalcore", "nu metal", "black metal"] },
  { name: "Forró", slug: "forro", aliases: ["forró", "forro", "forró eletrônico", "xote", "baião"] },
  { name: "Axé", slug: "axe", aliases: ["axé", "axe", "axé music"] },
  { name: "Piseiro", slug: "piseiro", aliases: ["piseiro", "pisadinha"] },
  { name: "Trap", slug: "trap", aliases: ["trap", "trap brasileiro"] },
  { name: "Lo-fi", slug: "lo-fi", aliases: ["lo-fi", "lofi", "lo fi", "lofi hip hop", "chillhop"] },
];

const aliasToName = new Map<string, string>();
for (const g of GENRES) {
  aliasToName.set(g.name.toLowerCase(), g.name);
  aliasToName.set(g.slug, g.name);
  for (const a of g.aliases) aliasToName.set(a.toLowerCase(), g.name);
}

export const genreSlugs = GENRES.map((g) => g.slug);

/** Normaliza um gênero vindo de metadados externos para o nome canônico. */
export function normalizeGenre(raw: string | null | undefined): string {
  const v = (raw ?? "").trim().toLowerCase();
  if (!v) return "";
  return aliasToName.get(v) ?? (raw ?? "").trim();
}

/** Retorna a lista de nomes canônicos que casam com um termo de busca. */
export function genreOptions(): string[] {
  return GENRES.map((g) => g.name);
}

export const genreBySlug = (slug: string) => GENRES.find((g) => g.slug === slug) ?? null;
