import "server-only";
import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { artistFollows, artists, chartEntries, chartSnapshots, playHistory, tracks } from "@/db/schema";

export type ChartScope = "tracks" | "artists";
export type ChartPeriod = "week" | "month" | "all";

export type ChartRow = {
  position: number;
  previous: number | null;
  change: number | null; // positivo = subiu, negativo = desceu, 0 = igual, null = novo
  score: number;
  targetId: string;
  title: string;
  subtitle: string;
  coverUrl: string | null;
  href: string;
};

function periodStart(period: ChartPeriod): Date | null {
  const now = new Date();
  if (period === "week") return new Date(now.getTime() - 7 * 86400_000);
  if (period === "month") return new Date(now.getTime() - 30 * 86400_000);
  return null;
}

/** Gera (ou atualiza) o snapshot do dia para o escopo/período dado. Metodologia: nº de reproduções distintas no período. */
export async function ensureChartSnapshot(scope: ChartScope, period: ChartPeriod, limit = 50) {
  const today = new Date().toISOString().slice(0, 10);
  const [existing] = await db
    .select()
    .from(chartSnapshots)
    .where(and(eq(chartSnapshots.scope, scope), eq(chartSnapshots.period, period), eq(chartSnapshots.snapshotDate, today)))
    .limit(1);
  if (existing) return existing.id;

  const start = periodStart(period);
  const filter = start ? gte(playHistory.playedAt, start) : undefined;

  const [snap] = await db
    .insert(chartSnapshots)
    .values({ scope, period, snapshotDate: today })
    .onConflictDoNothing()
    .returning();
  // se outro processo ganhou a corrida, usa o id existente
  const snapshotId =
    snap?.id ??
    (await db
      .select({ id: chartSnapshots.id })
      .from(chartSnapshots)
      .where(and(eq(chartSnapshots.scope, scope), eq(chartSnapshots.period, period), eq(chartSnapshots.snapshotDate, today)))
      .limit(1))[0].id;

  let entries: { targetId: string; score: number }[] = [];
  if (scope === "tracks") {
    // Reproduções reais (play_history) + reproduções acumuladas no catálogo (play_count)
    const byHistory = filter
      ? await db
          .select({ trackId: playHistory.trackId, score: sql<number>`count(*)::int` })
          .from(playHistory)
          .where(filter)
          .groupBy(playHistory.trackId)
          .orderBy(desc(sql`count(*)`))
          .limit(limit)
      : [];
    // fallback: play_count acumulado (dado real do catálogo)
    const byCount = await db
      .select({ trackId: tracks.id, score: tracks.playCount })
      .from(tracks)
      .where(eq(tracks.status, "published"))
      .orderBy(desc(tracks.playCount))
      .limit(limit);
    const map = new Map<string, number>();
    for (const r of byHistory) map.set(r.trackId, (map.get(r.trackId) ?? 0) + r.score);
    for (const r of byCount) map.set(r.trackId, (map.get(r.trackId) ?? 0) + r.score);
    entries = [...map.entries()].map(([targetId, score]) => ({ targetId, score })).sort((a, b) => b.score - a.score).slice(0, limit);
  } else {
    const byHistory = filter
      ? await db
          .select({ artistId: artists.id, score: sql<number>`count(*)::int` })
          .from(playHistory)
          .innerJoin(tracks, eq(tracks.id, playHistory.trackId))
          .innerJoin(artists, eq(artists.id, tracks.artistId))
          .where(filter)
          .groupBy(artists.id)
          .orderBy(desc(sql`count(*)`))
          .limit(limit)
      : [];
    const byFollow = await db
      .select({ artistId: artistFollows.artistId, score: sql<number>`count(*)::int` })
      .from(artistFollows)
      .groupBy(artistFollows.artistId)
      .orderBy(desc(sql`count(*)`))
      .limit(limit);
    const byCount = await db
      .select({ artistId: tracks.artistId, score: sql<number>`sum(${tracks.playCount})::int` })
      .from(tracks)
      .innerJoin(artists, eq(artists.id, tracks.artistId))
      .where(eq(tracks.status, "published"))
      .groupBy(tracks.artistId)
      .orderBy(desc(sql`sum(${tracks.playCount})`))
      .limit(limit);
    const map = new Map<string, number>();
    for (const r of byHistory) map.set(r.artistId, (map.get(r.artistId) ?? 0) + r.score);
    for (const r of byFollow) map.set(r.artistId, (map.get(r.artistId) ?? 0) + r.score * 5);
    for (const r of byCount) map.set(r.artistId, (map.get(r.artistId) ?? 0) + r.score);
    entries = [...map.entries()].map(([targetId, score]) => ({ targetId, score })).sort((a, b) => b.score - a.score).slice(0, limit);
  }

  if (entries.length) {
    await db.insert(chartEntries).values(entries.map((e, i) => ({ snapshotId, targetType: scope === "tracks" ? "track" : "artist", targetId: e.targetId, position: i + 1, score: e.score })));
  }
  return snapshotId;
}

/** Lê o chart atual com comparação à posição anterior (snapshot anterior do mesmo escopo/período). */
export async function getChart(scope: ChartScope, period: ChartPeriod, limit = 50): Promise<{ rows: ChartRow[]; generatedAt: string; hasData: boolean }> {
  const snapshotId = await ensureChartSnapshot(scope, period, limit);
  const entries = await db.select().from(chartEntries).where(eq(chartEntries.snapshotId, snapshotId)).orderBy(chartEntries.position).limit(limit);
  if (!entries.length) return { rows: [], generatedAt: new Date().toISOString(), hasData: false };

  // snapshot anterior (mais recente anterior ao atual)
  const [prevSnap] = await db
    .select()
    .from(chartSnapshots)
    .where(and(eq(chartSnapshots.scope, scope), eq(chartSnapshots.period, period), sql`${chartSnapshots.snapshotDate} < (select snapshot_date from ${chartSnapshots} where id = ${snapshotId})`))
    .orderBy(desc(chartSnapshots.snapshotDate))
    .limit(1);
  const prevMap = new Map<string, number>();
  if (prevSnap) {
    const prevEntries = await db.select().from(chartEntries).where(eq(chartEntries.snapshotId, prevSnap.id));
    for (const e of prevEntries) prevMap.set(e.targetId, e.position);
  }

  const ids = entries.map((e) => e.targetId);
  const meta = new Map<string, { title: string; subtitle: string; cover: string | null }>();
  if (scope === "tracks") {
    const list = await db
      .select({ id: tracks.id, title: tracks.title, artist: artists.name, cover: tracks.coverUrl })
      .from(tracks).innerJoin(artists, eq(artists.id, tracks.artistId))
      .where(inArray(tracks.id, ids));
    for (const t of list) meta.set(t.id, { title: t.title, subtitle: t.artist, cover: t.cover });
  } else {
    const list = await db.select({ id: artists.id, name: artists.name, cover: artists.imageUrl }).from(artists).where(inArray(artists.id, ids));
    for (const a of list) meta.set(a.id, { title: a.name, subtitle: "Artista", cover: a.cover });
  }

  const rows: ChartRow[] = entries.map((e) => {
    const m = meta.get(e.targetId) ?? { title: "Conteúdo", subtitle: "", cover: null };
    const prev = prevMap.get(e.targetId) ?? null;
    return {
      position: e.position,
      previous: prev,
      change: prev == null ? null : prev - e.position,
      score: e.score,
      targetId: e.targetId,
      title: m.title,
      subtitle: m.subtitle,
      coverUrl: m.cover,
      href: scope === "tracks" ? `/musica/${e.targetId}` : `/artista/${e.targetId}`,
    };
  });
  return { rows, generatedAt: new Date().toISOString(), hasData: true };
}
