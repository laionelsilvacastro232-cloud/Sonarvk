import { ArtistAreaPage } from "@/components/pages";
export default function Page(){ return <ArtistAreaPage/>; }
