import { NextResponse } from "next/server";
import { db } from "@/db";
import { artists, tracks, albums, users, notifications } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { getCurrentUser, publicUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";
import { readFile } from "fs/promises";
import path from "path";

async function myArtist(userId: number) {
  const [a] = await db.select().from(artists).where(eq(artists.userId, userId)).limit(1);
  return a || null;
}

function transcriptionConfig() {
  const key = process.env.OPENAI_API_KEY || process.env.TRANSCRIPTION_API_KEY || process.env.WHISPER_API_KEY || "";
  return {
    configured: Boolean(key),
    key,
    model: process.env.OPENAI_TRANSCRIBE_MODEL || process.env.TRANSCRIPTION_MODEL || "gpt-4o-mini-transcribe",
    baseUrl: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, ""),
  };
}

function aiLyricsStatus() {
  const c = transcriptionConfig();
  return { configured: c.configured, provider: c.configured ? "OpenAI" : null, model: c.configured ? c.model : null };
}

async function ownTracks(artistId: number) {
  return db.select().from(tracks).where(eq(tracks.artistId, artistId)).orderBy(desc(tracks.createdAt));
}
async function ownAlbums(artistId: number) {
  return db.select().from(albums).where(eq(albums.artistId, artistId)).orderBy(desc(albums.createdAt));
}
async function findOwnAlbum(albumId: any, artistId: number) {
  const id = Number(albumId);
  if (!id) return null;
  const [a] = await db.select().from(albums).where(and(eq(albums.id, id), eq(albums.artistId, artistId))).limit(1);
  return a || null;
}
function validDate(value: any, fallback = "2025-01-01") {
  const v = String(value || "").slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : fallback;
}
function safeMediaUrl(value: any, prefix = "") {
  const v = String(value || "").trim();
  if (!v) return "";
  if (prefix && v.startsWith(prefix)) return v;
  if (/^https?:\/\//i.test(v)) return v;
  if (!prefix && (v.startsWith("/api/files/") || v.startsWith("/uploads/"))) return v;
  return "";
}

const AUDIO_MIME: Record<string, string> = {
  mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", m4a: "audio/mp4", mp4: "audio/mp4", aac: "audio/aac", flac: "audio/flac", webm: "audio/webm",
};

async function resolveAudio(body: any, artist: any) {
  let audioUrl = String(body.audioUrl || "").trim();
  if (body.trackId) {
    const [t] = await db.select().from(tracks).where(eq(tracks.id, Number(body.trackId))).limit(1);
    if (!t) throw new Error("Música não encontrada.");
    if (t.artistId !== artist.id) throw new Error("Você só pode gerar a letra das suas próprias músicas.");
    audioUrl = t.audioUrl;
  }
  if (!audioUrl) throw new Error("Envie primeiro o arquivo de áudio da música.");

  if (audioUrl.startsWith("/api/files/audios/")) {
    const name = path.basename(audioUrl);
    if (!name || name !== audioUrl.split("/").pop()) throw new Error("Arquivo de áudio inválido.");
    const ext = (name.split(".").pop() || "mp3").toLowerCase();
    const buffer = await readFile(path.join(process.cwd(), "public", "uploads", "audios", name));
    if (!buffer.length) throw new Error("O arquivo de áudio está vazio.");
    if (buffer.length > 25 * 1024 * 1024) throw new Error("Para gerar a letra, o áudio precisa ter até 25MB.");
    return { buffer, filename: name, type: AUDIO_MIME[ext] || "audio/mpeg" };
  }

  if (/^https?:\/\//i.test(audioUrl)) {
    const parsed = new URL(audioUrl);
    if (["localhost", "127.0.0.1", "::1"].includes(parsed.hostname)) throw new Error("Use um arquivo de áudio enviado ao Sonar.");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25000);
    try {
      const res = await fetch(audioUrl, { signal: controller.signal });
      if (!res.ok) throw new Error("Não foi possível ler o arquivo de áudio.");
      const length = Number(res.headers.get("content-length") || 0);
      if (length > 25 * 1024 * 1024) throw new Error("Para gerar a letra, o áudio precisa ter até 25MB.");
      const buffer = Buffer.from(await res.arrayBuffer());
      if (!buffer.length || buffer.length > 25 * 1024 * 1024) throw new Error("O arquivo de áudio é inválido ou grande demais.");
      const ext = (parsed.pathname.split(".").pop() || "mp3").toLowerCase();
      return { buffer, filename: `audio.${AUDIO_MIME[ext] ? ext : "mp3"}`, type: res.headers.get("content-type") || AUDIO_MIME[ext] || "audio/mpeg" };
    } finally {
      clearTimeout(timer);
    }
  }

  throw new Error("Envie o áudio pelo Sonar para gerar a letra.");
}

async function generateLyrics(body: any, artist: any) {
  const config = transcriptionConfig();
  if (!config.configured) {
    return NextResponse.json({
      error: "A letra automática por IA ainda não está configurada no servidor. Configure OPENAI_API_KEY no ambiente para ativar a transcrição real do áudio.",
      code: "TRANSCRIPTION_NOT_CONFIGURED",
      requiredEnv: "OPENAI_API_KEY",
    }, { status: 503 });
  }

  let audio: { buffer: Buffer; filename: string; type: string };
  try {
    audio = await resolveAudio(body, artist);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Não foi possível ler o áudio." }, { status: 400 });
  }

  const form = new FormData();
  form.append("file", new Blob([new Uint8Array(audio.buffer)], { type: audio.type }), audio.filename);
  form.append("model", config.model);
  form.append("response_format", "json");
  form.append("language", String(body.language || "pt").slice(0, 5));
  form.append("prompt", "Transcreva fielmente apenas os vocais cantados desta música, em português quando for o idioma cantado. Não invente palavras, não resuma e não adicione comentários.");

  let response: Response;
  try {
    response = await fetch(`${config.baseUrl}/audio/transcriptions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${config.key}` },
      body: form,
    });
  } catch {
    return NextResponse.json({ error: "Não foi possível conectar ao serviço de transcrição agora. Tente novamente." }, { status: 502 });
  }

  const data: any = await response.json().catch(() => ({}));
  if (!response.ok) {
    return NextResponse.json({ error: "O serviço de IA não conseguiu transcrever este áudio. Confira o arquivo e tente novamente." }, { status: 502 });
  }
  const lyrics = String(data?.text || "").trim();
  if (!lyrics) return NextResponse.json({ error: "Não foi possível identificar vocais neste áudio. Se for instrumental, a letra precisa ser escrita manualmente." }, { status: 422 });
  return NextResponse.json({ ok: true, lyrics, provider: "OpenAI", model: config.model, message: "Letra gerada a partir do áudio. Revise antes de publicar." });
}

export async function GET() {
  await ensureSeed();
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Faça login para acessar a área do artista." }, { status: 401 });
  const artist = await myArtist(me.id);
  let myTracks: any[] = [];
  let myAlbums: any[] = [];
  if (artist) {
    // Sem revisão: perfis de artista ficam ativos automaticamente.
    if (artist.status !== "approved") {
      await db.update(artists).set({ status: "approved" }).where(eq(artists.id, artist.id));
      artist.status = "approved";
    }
    myTracks = await ownTracks(artist.id);
    myAlbums = await ownAlbums(artist.id);
  }
  return NextResponse.json({ user: publicUser(me), artist, tracks: myTracks, albums: myAlbums, approved: !!artist, aiLyrics: aiLyricsStatus() });
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Faça login para continuar." }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const a = b.action;
  try {
    if (a === "create-artist") {
      if (!b.name?.trim()) return NextResponse.json({ error: "Informe o nome artístico." }, { status: 400 });
      const existing = await myArtist(me.id);
      if (existing) return NextResponse.json({ ok: true, artist: existing, message: "Você já tem um perfil de artista vinculado à sua conta." });
      const [artist] = await db.insert(artists).values({ name: b.name.trim(), bio: b.bio || "", imageUrl: b.imageUrl || "", genre: b.genre || "", verified: false, monthlyListeners: 0, userId: me.id, status: "approved" }).returning();
      await db.insert(notifications).values({ userId: me.id, title: "Perfil de artista ativo", body: `"${artist.name}" foi criado e já está ativo. Você já pode publicar músicas, álbuns e videoclipes.` });
      return NextResponse.json({ ok: true, artist, message: "Perfil de artista criado e ativado! Você já pode publicar." });
    }

    const artist = await myArtist(me.id);
    if (!artist) return NextResponse.json({ error: "Você ainda não tem um perfil de artista. Crie seu perfil primeiro." }, { status: 400 });

    if (a === "update-artist") {
      const [u] = await db.update(artists).set({ name: b.name?.trim() || artist.name, bio: b.bio ?? artist.bio, imageUrl: b.imageUrl ?? artist.imageUrl, genre: b.genre ?? artist.genre }).where(eq(artists.id, artist.id)).returning();
      return NextResponse.json({ ok: true, artist: u, message: "Perfil de artista atualizado." });
    }

    if (a === "generate-lyrics") {
      return generateLyrics(b, artist);
    }

    if (a === "create-album" || a === "save-album") {
      if (!b.title?.trim()) return NextResponse.json({ error: "Dê um título ao álbum, EP ou single." }, { status: 400 });
      const values = {
        title: b.title.trim(),
        artistId: artist.id,
        coverUrl: safeMediaUrl(b.coverUrl),
        releaseDate: validDate(b.releaseDate, new Date().toISOString().slice(0, 10)),
        type: ["album", "single", "ep"].includes(b.type) ? b.type : "album",
        genre: b.genre || artist.genre || "",
        published: true,
      };
      let album: any;
      if (b.id) {
        const existing = await findOwnAlbum(b.id, artist.id);
        if (!existing) return NextResponse.json({ error: "Álbum não encontrado ou não pertence a você." }, { status: 404 });
        [album] = await db.update(albums).set(values).where(eq(albums.id, existing.id)).returning();
      } else {
        [album] = await db.insert(albums).values(values).returning();
      }
      const selectedIds: number[] = Array.isArray(b.trackIds) ? [...new Set<number>(b.trackIds.map((x: any) => Number(x)).filter(Boolean))] : [];
      if (selectedIds.length) {
        const mine = await ownTracks(artist.id);
        const allowed = new Set(mine.map(t => t.id));
        for (const trackId of selectedIds) {
          if (!allowed.has(trackId)) continue;
          const track = mine.find(t => t.id === trackId);
          await db.update(tracks).set({ albumId: album.id, coverUrl: track?.coverUrl || album.coverUrl || "" }).where(eq(tracks.id, trackId));
        }
        // Remove deste álbum as faixas que foram desmarcadas.
        for (const track of mine) {
          if (track.albumId === album.id && !selectedIds.includes(track.id)) {
            await db.update(tracks).set({ albumId: null }).where(eq(tracks.id, track.id));
          }
        }
      }
      return NextResponse.json({ ok: true, album, albums: await ownAlbums(artist.id), tracks: await ownTracks(artist.id), message: b.id ? "Álbum atualizado e já está no ar." : "Álbum publicado! Ele já aparece para os ouvintes." });
    }

    if (a === "delete-album") {
      const album = await findOwnAlbum(b.albumId || b.id, artist.id);
      if (!album) return NextResponse.json({ error: "Álbum não encontrado ou não pertence a você." }, { status: 404 });
      await db.update(tracks).set({ albumId: null }).where(and(eq(tracks.artistId, artist.id), eq(tracks.albumId, album.id)));
      await db.delete(albums).where(eq(albums.id, album.id));
      return NextResponse.json({ ok: true, albums: await ownAlbums(artist.id), tracks: await ownTracks(artist.id), message: "Álbum excluído. As músicas foram mantidas como faixas avulsas." });
    }

    if (a === "submit-track") {
      // Publicação imediata: sem revisão do administrador.
      if (!b.title?.trim() || !b.audioUrl?.trim()) return NextResponse.json({ error: "Dê um título e envie o arquivo da música." }, { status: 400 });
      let album: any = null;
      if (b.albumId) {
        album = await findOwnAlbum(b.albumId, artist.id);
        if (!album) return NextResponse.json({ error: "Selecione um álbum seu ou deixe a música avulsa." }, { status: 400 });
      }
      const [t] = await db.insert(tracks).values({
        title: b.title.trim(),
        artistId: artist.id,
        albumId: album?.id || null,
        featuring: (b.featuring || "").toString().slice(0, 160),
        coverUrl: safeMediaUrl(b.coverUrl) || album?.coverUrl || "",
        audioUrl: String(b.audioUrl).trim(),
        duration: +(b.duration || 200),
        releaseDate: validDate(b.releaseDate, album?.releaseDate || new Date().toISOString().slice(0, 10)),
        genre: b.genre || album?.genre || artist.genre || "",
        credits: b.credits || `${artist.name} • Publicado pelo artista via SONAR`,
        lyrics: b.lyrics || "",
        lyricsSource: b.lyricsSource === "ai" ? "ai" : b.lyrics ? "manual" : "",
        lyricsGeneratedAt: b.lyricsSource === "ai" ? new Date() : null,
        videoUrl: safeMediaUrl(b.videoUrl, "/api/files/videos/"),
        videoThumbnailUrl: safeMediaUrl(b.videoThumbnailUrl),
        plays: 0,
        published: true,
        featured: false,
      }).returning();
      return NextResponse.json({ ok: true, track: t, tracks: await ownTracks(artist.id), albums: await ownAlbums(artist.id), message: "Música publicada! Ela já está no ar." });
    }

    if (a === "set-track-video") {
      const [t] = await db.select().from(tracks).where(eq(tracks.id, Number(b.trackId))).limit(1);
      if (!t) return NextResponse.json({ error: "Música não encontrada." }, { status: 404 });
      if (t.artistId !== artist.id) return NextResponse.json({ error: "Você só pode alterar as suas próprias músicas." }, { status: 403 });
      const videoUrl = b.videoUrl ? safeMediaUrl(b.videoUrl, "/api/files/videos/") : "";
      if (b.videoUrl && !videoUrl) return NextResponse.json({ error: "Envie um arquivo de vídeo válido (MP4, WEBM ou MOV)." }, { status: 400 });
      await db.update(tracks).set({ videoUrl, videoThumbnailUrl: safeMediaUrl(b.videoThumbnailUrl) || t.videoThumbnailUrl || t.coverUrl || "" }).where(eq(tracks.id, t.id));
      return NextResponse.json({ ok: true, tracks: await ownTracks(artist.id), message: videoUrl ? "Videoclipe publicado e vinculado à música." : "Videoclipe removido." });
    }

    if (a === "update-track" || a === "delete-track") {
      const [t] = await db.select().from(tracks).where(eq(tracks.id, Number(b.trackId))).limit(1);
      if (!t) return NextResponse.json({ error: "Música não encontrada." }, { status: 404 });
      if (t.artistId !== artist.id) return NextResponse.json({ error: "Você só pode alterar as suas próprias músicas." }, { status: 403 });
      if (a === "delete-track") {
        await db.delete(tracks).where(eq(tracks.id, t.id));
      } else {
        let albumId = t.albumId;
        if (b.albumId !== undefined) {
          if (!b.albumId) albumId = null;
          else {
            const album = await findOwnAlbum(b.albumId, artist.id);
            if (!album) return NextResponse.json({ error: "Selecione um álbum seu ou deixe a música avulsa." }, { status: 400 });
            albumId = album.id;
          }
        }
        await db.update(tracks).set({
          title: b.title?.trim() || t.title,
          audioUrl: b.audioUrl?.trim() || t.audioUrl,
          albumId,
          featuring: b.featuring !== undefined ? String(b.featuring).slice(0, 160) : t.featuring,
          coverUrl: b.coverUrl !== undefined ? safeMediaUrl(b.coverUrl) : t.coverUrl,
          genre: b.genre ?? t.genre,
          duration: +(b.duration || t.duration),
          releaseDate: b.releaseDate ? validDate(b.releaseDate, t.releaseDate || "2025-01-01") : t.releaseDate,
          lyrics: b.lyrics ?? t.lyrics,
          lyricsSource: b.lyricsSource === "ai" ? "ai" : b.lyrics !== undefined && b.lyrics !== t.lyrics ? "manual" : (t as any).lyricsSource,
          lyricsGeneratedAt: b.lyricsSource === "ai" ? new Date() : (t as any).lyricsGeneratedAt,
          videoUrl: b.videoUrl !== undefined ? safeMediaUrl(b.videoUrl, "/api/files/videos/") : (t as any).videoUrl,
          videoThumbnailUrl: b.videoThumbnailUrl !== undefined ? safeMediaUrl(b.videoThumbnailUrl) : (t as any).videoThumbnailUrl,
          published: true,
        }).where(eq(tracks.id, t.id));
      }
      return NextResponse.json({ ok: true, tracks: await ownTracks(artist.id), albums: await ownAlbums(artist.id), message: a === "delete-track" ? "Publicação excluída." : "Música atualizada e já está no ar." });
    }

    return NextResponse.json({ error: "Ação inválida." }, { status: 400 });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: "Erro no servidor. Tente novamente." }, { status: 500 });
  }
}
