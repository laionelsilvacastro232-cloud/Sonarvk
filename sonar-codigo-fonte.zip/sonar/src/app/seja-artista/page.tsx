import { ArtistJoinPage } from "@/components/pages";
export default function Page(){ return <ArtistJoinPage/>; }
