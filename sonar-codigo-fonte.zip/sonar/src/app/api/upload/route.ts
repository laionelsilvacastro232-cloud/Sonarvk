import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import crypto from "crypto";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";

// Envio real de arquivos (música e imagem) — nada de colar links.
const AUDIO: Record<string, string> = { "audio/mpeg": "mp3", "audio/mp3": "mp3", "audio/wav": "wav", "audio/x-wav": "wav", "audio/wave": "wav", "audio/ogg": "ogg", "audio/mp4": "m4a", "audio/x-m4a": "m4a", "audio/aac": "aac", "audio/flac": "flac", "audio/x-flac": "flac" };
const IMG: Record<string, string> = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif", "image/avif": "avif" };
const VIDEO: Record<string, string> = { "video/mp4": "mp4", "video/webm": "webm", "video/quicktime": "mov", "video/x-m4v": "m4v" };

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Faça login para enviar arquivos." }, { status: 401 });
  try {
    const form = await req.formData().catch(() => null);
    const file = form?.get("file") as File | null;
    const kind = String(form?.get("kind") || "audio");
    if (!file || typeof (file as any).arrayBuffer !== "function") return NextResponse.json({ error: "Nenhum arquivo recebido. Toque em escolher arquivo e tente de novo." }, { status: 400 });
    const mediaKind = kind === "image" || kind === "video" ? kind : "audio";
    const isAudio = mediaKind === "audio";
    const isVideo = mediaKind === "video";
    const map = isAudio ? AUDIO : isVideo ? VIDEO : IMG;
    const extFromName = (file.name.split(".").pop() || "").toLowerCase();
    const ext = map[file.type] || (Object.values(map).includes(extFromName) ? extFromName : "");
    if (!ext) return NextResponse.json({ error: isAudio ? "Formato não suportado. Envie MP3, WAV, OGG, M4A ou FLAC." : isVideo ? "Formato não suportado. Envie MP4, WEBM ou MOV." : "Formato não suportado. Envie JPG, PNG ou WEBP." }, { status: 400 });
    const maxBytes = isAudio ? 25 * 1024 * 1024 : isVideo ? 100 * 1024 * 1024 : 6 * 1024 * 1024;
    if (file.size > maxBytes) return NextResponse.json({ error: `Arquivo muito grande (máximo ${isAudio ? "25MB" : isVideo ? "100MB" : "6MB"}).` }, { status: 413 });
    if (file.size === 0) return NextResponse.json({ error: "O arquivo veio vazio. Escolha outro." }, { status: 400 });
    const buf = Buffer.from(await file.arrayBuffer());
    const name = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}.${ext}`;
    const folder = isAudio ? "audios" : isVideo ? "videos" : "images";
    const dir = path.join(process.cwd(), "public", "uploads", folder);
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, name), buf);
    return NextResponse.json({ ok: true, url: `/api/files/${folder}/${name}`, fileName: file.name, size: file.size });
  } catch (e: any) {
    console.error("upload", e);
    return NextResponse.json({ error: "Erro ao enviar o arquivo. Tente novamente." }, { status: 500 });
  }
}
