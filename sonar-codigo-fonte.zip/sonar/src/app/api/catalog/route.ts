import { NextResponse } from "next/server";
import { db } from "@/db";
import { tracks, artists, albums, playlists, users, playlistTracks, siteSettings } from "@/db/schema";
import { eq, desc, ilike, or } from "drizzle-orm";
import { ensureSeed, serializeTracks } from "@/lib/catalog";
import { CANONICAL_GENRES, normalizeGenre } from "@/lib/genres";

export async function GET(req:Request){
  await ensureSeed();
  const url=new URL(req.url); const q=url.searchParams.get("q")||""; const artistId=url.searchParams.get("artist"); const albumId=url.searchParams.get("album"); const genre=url.searchParams.get("genre")||"";
  const [settings]=await db.select().from(siteSettings).limit(1);
  const allArtistsEarly=await db.select().from(artists).orderBy(desc(artists.monthlyListeners));
  let trackRows=await db.select().from(tracks).where(eq(tracks.published,true)).orderBy(desc(tracks.plays));
  if(artistId) trackRows=trackRows.filter(t=>t.artistId===+artistId);
  if(albumId) trackRows=trackRows.filter(t=>t.albumId===+albumId);
  if(genre) trackRows=trackRows.filter(t=>(t.genre||"")===genre);
  if(q){
    const ql=q.toLowerCase();
    const artistNameIds=new Set(allArtistsEarly.filter(a=>a.name.toLowerCase().includes(ql)).map(a=>a.id));
    trackRows=trackRows.filter(t=>t.title.toLowerCase().includes(ql)||(t.genre||"").toLowerCase().includes(ql)||artistNameIds.has(t.artistId));
  }
  const allArtists=await db.select().from(artists).orderBy(desc(artists.monthlyListeners));
  const allAlbums=await db.select().from(albums).where(eq(albums.published,true)).orderBy(desc(albums.createdAt));
  const allAlbumsFiltered = genre ? allAlbums.filter(a=>(a.genre||"")===genre) : allAlbums;
  const allPlaylists=await db.select().from(playlists).where(eq(playlists.isPublic,true)).orderBy(desc(playlists.createdAt));
  const pts=await db.select().from(playlistTracks);
  const ownerIds=[...new Set(allPlaylists.map(p=>p.userId))];
  const owners= ownerIds.length? await db.select().from(users) : [];
  const ownerMap=new Map(owners.map(o=>[o.id,o.displayName]));
  const playlistsOut=allPlaylists.map(p=>({...p, ownerName:ownerMap.get(p.userId)||"SONAR", trackCount:pts.filter(x=>x.playlistId===p.id).length, trackIds:pts.filter(x=>x.playlistId===p.id).sort((a,b)=>a.position-b.position).map(x=>x.trackId)}));
  let artistOut=allArtists; let albumOut=allAlbumsFiltered; let userOut:any[]=[];
  if(q){
    const ql=q.toLowerCase();
    artistOut=allArtists.filter(a=>a.name.toLowerCase().includes(ql)||(a.genre||"").toLowerCase().includes(ql));
    albumOut=allAlbums.filter(a=>a.title.toLowerCase().includes(ql));
    const us=await db.select().from(users);
    userOut=us.filter(u=>u.displayName.toLowerCase().includes(ql)||u.username.toLowerCase().includes(ql)).map(u=>({id:u.id, username:u.username, displayName:u.displayName, bio:u.bio, avatarUrl:u.avatarUrl}));
  }
  return NextResponse.json({
    settings: settings||null,
    tracks: await serializeTracks(trackRows),
    artists: artistOut,
    albums: (q||genre? albumOut : albumOut).map(a=>({...a, artist: allArtists.find(x=>x.id===a.artistId)||null})),
    playlists: q? playlistsOut.filter(p=>p.name.toLowerCase().includes(q.toLowerCase())) : playlistsOut,
    users: userOut,
    genres: CANONICAL_GENRES.filter(g=> trackRows.some(t=>normalizeGenre(t.genre)===g) || allArtists.some(a=>normalizeGenre(a.genre)===g)),
  });
}
