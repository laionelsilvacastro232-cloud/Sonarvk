import nodemailer from "nodemailer";

// Envio automático de e-mail pelo próprio aplicativo.
// Opção 1 (SMTP/Gmail): SMTP_USER + SMTP_PASS (Senha de app, não a senha normal).
// Opção 2 (Resend): RESEND_API_KEY + RESEND_FROM (remetente verificado no Resend).
function mailConfig() {
  const user = (process.env.SMTP_USER || "").trim();
  const pass = (process.env.SMTP_PASS || "").replace(/\s+/g, "");
  return {
    user,
    pass,
    host: (process.env.SMTP_HOST || "smtp.gmail.com").trim(),
    port: +(process.env.SMTP_PORT || 465),
    from: (process.env.SMTP_FROM || "").trim(),
    resendKey: (process.env.RESEND_API_KEY || "").trim(),
    resendFrom: (process.env.RESEND_FROM || process.env.SMTP_FROM || "").trim(),
  };
}

export function mailConfigured() {
  const c = mailConfig();
  return Boolean((c.user && c.pass) || c.resendKey);
}

export function mailProvider() {
  const c = mailConfig();
  if (c.resendKey) return "resend";
  if (c.user && c.pass) return "smtp";
  return "none";
}

export type MailResult = { ok: boolean; provider: string; error?: string };

async function sendWithResendDetailed(to: string, subject: string, html: string): Promise<MailResult> {
  const c = mailConfig();
  if (!c.resendKey) return { ok: false, provider: "resend", error: "not_configured" };
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${c.resendKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: c.resendFrom || "SONAR <onboarding@resend.dev>",
        to: [to],
        subject,
        html,
      }),
    });
    if (response.ok) return { ok: true, provider: "resend" };
    let code = `http_${response.status}`;
    try {
      const data: any = await response.json();
      code = String(data?.name || data?.code || code).slice(0, 80);
    } catch {}
    return { ok: false, provider: "resend", error: code };
  } catch (error) {
    return { ok: false, provider: "resend", error: error instanceof Error ? error.name : "network_error" };
  }
}

async function sendWithSmtpDetailed(to: string, subject: string, html: string): Promise<MailResult> {
  const c = mailConfig();
  if (!c.user || !c.pass) return { ok: false, provider: "smtp", error: "not_configured" };
  try {
    const transporter = nodemailer.createTransport({
      host: c.host,
      port: c.port,
      secure: c.port === 465,
      requireTLS: c.port === 587,
      auth: { user: c.user, pass: c.pass },
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 15000,
    });
    const info = await transporter.sendMail({
      from: c.from || `"SONAR" <${c.user}>`,
      to,
      subject,
      html,
    });
    const accepted = Array.isArray(info.accepted) ? info.accepted.map((x: any) => String(x).toLowerCase()) : [];
    const ok = accepted.length ? accepted.includes(to.toLowerCase()) : Boolean(info.messageId);
    return { ok, provider: "smtp", error: ok ? undefined : "not_accepted" };
  } catch (error: any) {
    return { ok: false, provider: "smtp", error: String(error?.code || error?.name || "smtp_error").slice(0, 80) };
  }
}

export async function sendMailDetailed(to: string, subject: string, html: string): Promise<MailResult> {
  if (!mailConfigured()) return { ok: false, provider: "none", error: "not_configured" };
  const c = mailConfig();
  if (c.resendKey) {
    const r = await sendWithResendDetailed(to, subject, html);
    if (r.ok || !(c.user && c.pass)) return r;
  }
  return sendWithSmtpDetailed(to, subject, html);
}

async function sendWithResend(to: string, subject: string, html: string) {
  const c = mailConfig();
  if (!c.resendKey) return false;
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${c.resendKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: c.resendFrom || "SONAR <onboarding@resend.dev>",
        to: [to],
        subject,
        html,
      }),
    });
    return response.ok;
  } catch (error) {
    console.error("resend delivery failed", error instanceof Error ? error.message : "unknown error");
    return false;
  }
}

async function sendWithSmtp(to: string, subject: string, html: string) {
  const c = mailConfig();
  if (!c.user || !c.pass) return false;
  try {
    const transporter = nodemailer.createTransport({
      host: c.host,
      port: c.port,
      secure: c.port === 465,
      requireTLS: c.port === 587,
      auth: { user: c.user, pass: c.pass },
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 15000,
    });
    const info = await transporter.sendMail({
      from: c.from || `"SONAR" <${c.user}>`,
      to,
      subject,
      html,
    });
    const accepted = Array.isArray(info.accepted) ? info.accepted.map((x: any) => String(x).toLowerCase()) : [];
    return accepted.length ? accepted.includes(to.toLowerCase()) : Boolean(info.messageId);
  } catch (error) {
    // Nunca registrar senhas, tokens ou conteúdo do e-mail nos logs.
    console.error("smtp delivery failed", error instanceof Error ? error.message : "unknown error");
    return false;
  }
}

export async function sendMail(to: string, subject: string, html: string) {
  const result = await sendMailDetailed(to, subject, html);
  return result.ok;
}

export function resetCodeEmail(siteName: string, code: string) {
  return `<div style="background:#0a0a0a;color:#fff;font-family:Arial,sans-serif;padding:32px;border-radius:16px;max-width:480px">
    <p style="letter-spacing:4px;font-weight:bold;font-size:12px;color:#aaa">${siteName.toUpperCase()} • SUPORTE</p>
    <h1 style="font-size:24px;margin:12px 0">Recuperação de senha</h1>
    <p style="color:#ccc;line-height:1.6">Use o código abaixo para criar uma nova senha. Ele vale por <b>15 minutos</b> e só pode ser usado uma vez. Se você não pediu isso, ignore este e-mail.</p>
    <p style="font-size:38px;font-weight:900;letter-spacing:10px;background:#fff;color:#000;text-align:center;padding:16px;border-radius:12px;margin:24px 0">${code}</p>
    <p style="color:#888;font-size:12px">Equipe ${siteName} — nunca pedimos sua senha por e-mail.</p>
  </div>`;
}


export function resetLinkEmail(siteName: string, resetUrl: string) {
  const safeName = siteName.toUpperCase();
  return `<div style="background:#0a0a0a;color:#fff;font-family:Arial,sans-serif;padding:32px;border-radius:16px;max-width:520px">
    <p style="letter-spacing:4px;font-weight:bold;font-size:12px;color:#aaa">${safeName} • SEGURANÇA</p>
    <h1 style="font-size:24px;margin:12px 0">Redefinir sua senha</h1>
    <p style="color:#ccc;line-height:1.6">Recebemos um pedido para redefinir a senha da sua conta. Toque no botão abaixo para criar uma nova senha. Este link vale por <b>30 minutos</b>, só pode ser usado uma vez e ninguém da equipe pode ver sua senha.</p>
    <p style="margin:28px 0"><a href="${resetUrl}" style="display:inline-block;background:#ffffff;color:#000000;text-decoration:none;font-weight:900;padding:15px 26px;border-radius:999px">Criar nova senha</a></p>
    <p style="color:#999;font-size:13px;line-height:1.6">Se o botão não abrir, copie e cole este endereço no navegador:</p>
    <p style="word-break:break-all;color:#fff;font-size:13px;line-height:1.6">${resetUrl}</p>
    <p style="color:#888;font-size:12px;margin-top:24px">Se você não pediu isso, ignore este e-mail. Sua senha atual continua a mesma.</p>
  </div>`;
}

export function verificationEmail(siteName: string, verifyUrl: string) {
  const safeName = siteName.toUpperCase();
  return `<div style="background:#0a0a0a;color:#fff;font-family:Arial,sans-serif;padding:32px;border-radius:16px;max-width:520px">
    <p style="letter-spacing:4px;font-weight:bold;font-size:12px;color:#aaa">${safeName} • BEM-VINDO(A)</p>
    <h1 style="font-size:24px;margin:12px 0">Confirme seu e-mail</h1>
    <p style="color:#ccc;line-height:1.6">Sua conta foi criada. Quando a verificação estiver ativa, use o botão abaixo para confirmar este e-mail.</p>
    <p style="margin:28px 0"><a href="${verifyUrl}" style="display:inline-block;background:#ffffff;color:#000000;text-decoration:none;font-weight:900;padding:15px 26px;border-radius:999px">Confirmar e-mail</a></p>
  </div>`;
}
