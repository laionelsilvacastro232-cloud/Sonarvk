import { NextResponse } from "next/server";
import crypto from "crypto";
import { getAppOrigin, googleRedirectUri } from "@/lib/app-url";

// Inicia o login com Google (OAuth 2.0 real). Requer GOOGLE_CLIENT_ID e GOOGLE_CLIENT_SECRET.
export async function GET(req: Request) {
  const id = (process.env.GOOGLE_CLIENT_ID || "").trim();
  const secret = (process.env.GOOGLE_CLIENT_SECRET || "").trim();
  if (!id || !secret) {
    const missing = [
      ...(!id ? ["GOOGLE_CLIENT_ID"] : []),
      ...(!secret ? ["GOOGLE_CLIENT_SECRET"] : []),
    ];
    const message = "Login com Google ainda não foi ativado no servidor. O administrador precisa configurar GOOGLE_CLIENT_ID e GOOGLE_CLIENT_SECRET.";
    // Navegador: volta para a tela de login com a explicação (nada de JSON cru na tela).
    if ((req.headers.get("accept") || "").includes("text/html")) {
      return NextResponse.redirect(`${getAppOrigin(req)}/login?erro=${encodeURIComponent(message)}`);
    }
    return NextResponse.json({ error: message, missing, redirectUri: googleRedirectUri(req) }, { status: 503 });
  }
  const state = crypto.randomBytes(16).toString("hex");
  const params = new URLSearchParams({
    client_id: id,
    redirect_uri: googleRedirectUri(req),
    response_type: "code",
    scope: "openid email profile",
    state,
    access_type: "online",
    prompt: "select_account",
  });
  const res = NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
  res.cookies.set("g_state", state, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 600,
    secure: process.env.NODE_ENV === "production",
  });
  return res;
}
