import { LegalPage } from "@/components/pages";
export default function Page(){ return <LegalPage type="terms"/>; }
