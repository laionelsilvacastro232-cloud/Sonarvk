import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/db";
import { users, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, createSession } from "@/lib/auth";
import { getAppOrigin, googleRedirectUri } from "@/lib/app-url";
import { logAuthEvent } from "@/lib/security";
import { ensureSeed } from "@/lib/catalog";
import crypto from "crypto";

// Callback do Google: troca o código por token (no servidor), pega o perfil e entra/cria a conta.
export async function GET(req: Request) {
  await ensureSeed();
  const url = new URL(req.url);
  const origin = getAppOrigin(req);
  const fail = (msg: string) => NextResponse.redirect(`${origin}/login?erro=${encodeURIComponent(msg)}`);
  const id = process.env.GOOGLE_CLIENT_ID, secret = process.env.GOOGLE_CLIENT_SECRET;
  if (!id || !secret) return fail("Login com Google não configurado no servidor.");
  const code = url.searchParams.get("code"); const state = url.searchParams.get("state");
  const c = await cookies(); const savedState = c.get("g_state")?.value;
  if (!code || !state || state !== savedState) return fail("Sessão do Google expirou. Tente novamente.");
  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ code, client_id: id, client_secret: secret, redirect_uri: googleRedirectUri(req), grant_type: "authorization_code" }),
    });
    const tokenData = await tokenRes.json();
    if (!tokenRes.ok || !tokenData.access_token) return fail("Não foi possível validar com o Google.");
    const infoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", { headers: { Authorization: `Bearer ${tokenData.access_token}` } });
    const info = await infoRes.json();
    if (!info?.email) return fail("O Google não retornou um e-mail válido.");
    if (info.email_verified === false) return fail("O e-mail desta conta Google ainda não foi verificado pelo Google.");
    const mail = String(info.email).toLowerCase();
    let [u] = await db.select().from(users).where(eq(users.email, mail)).limit(1);
    if (!u) {
      const displayName = info.name || mail.split("@")[0];
      const base = (displayName.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "") || "usuario").slice(0, 20);
      let username = base; let suffix = 1;
      while (true) { const [taken] = await db.select().from(users).where(eq(users.username, username)).limit(1); if (!taken) break; suffix++; username = base + suffix; }
      const [nu] = await db.insert(users).values({ email: mail, username, displayName, passwordHash: await hashPassword(crypto.randomBytes(24).toString("hex")), bio: "", avatarUrl: info.picture || "" }).returning();
      u = nu;
      await db.insert(notifications).values({ userId: u.id, title: "Bem-vindo(a) à SONAR", body: "Sua conta foi criada com o Google. Explore o catálogo, siga artistas e monte sua primeira playlist." });
    }
    if (u.suspended) return fail("Conta suspensa. Fale com o suporte.");
    await logAuthEvent({ req, userId: u.id, identifier: mail, event: "google_login", success: true });
    const token = await createSession(u.id, u.role, (u as any).sessionVersion || 1);
    const res = NextResponse.redirect(`${origin}/`);
    // Garante o cookie de sessão (30 dias) também no redirecionamento do Google.
    res.cookies.set("noir_session", token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 30, secure: process.env.NODE_ENV === "production" });
    res.cookies.set("g_state", "", { path: "/", maxAge: 0, httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
    return res;
  } catch (e) { console.error("google auth", e); return fail("Erro ao entrar com o Google. Tente novamente."); }
}
