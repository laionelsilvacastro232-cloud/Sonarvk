import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppProvider, Shell } from "@/components/platform";

export const metadata: Metadata = {
  title: { default: "SONAR — A nova era da música social", template: "%s | SONAR" },
  description: "Descubra artistas independentes, crie playlists, siga amigos, veja os charts e ouça em qualquer dispositivo. Plataforma musical social gratuita da comunidade.",
  manifest: "/manifest.json",
  icons: { icon: "/icon.svg" },
  openGraph: { title: "SONAR — A nova era da música social", description: "Música, artistas, charts e comunidade em um só lugar.", type: "website" },
  keywords: ["música", "streaming", "artistas independentes", "playlists", "charts", "SONAR"],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="bg-[#0a0a0a] text-white antialiased">
        <AppProvider><Shell>{children}</Shell></AppProvider>
      </body>
    </html>
  );
}
