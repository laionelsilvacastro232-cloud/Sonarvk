import { ChartsPage } from "@/components/pages";
export default function Page(){ return <ChartsPage/>; }
