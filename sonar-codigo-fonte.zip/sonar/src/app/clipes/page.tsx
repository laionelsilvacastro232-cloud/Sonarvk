import { ClipsPage } from "@/components/pages";
export default function Page(){ return <ClipsPage/>; }
