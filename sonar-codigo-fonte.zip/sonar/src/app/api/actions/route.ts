import { NextResponse } from "next/server";
import { db } from "@/db";
import { favorites, artistFollows, albumSaves, playlistSaves, userFollows, history, tracks, playlists, playlistTracks, notifications, reports, artists, users } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed, serializeTracks } from "@/lib/catalog";

async function library(userId:number){
  const favs=await db.select().from(favorites).where(eq(favorites.userId,userId));
  const favTracksRaw= favs.length? await db.select().from(tracks).where(eq(tracks.published,true)) : [];
  const favTracks= (await serializeTracks(favTracksRaw)).filter((t:any)=>favs.some(f=>f.trackId===t.id));
  const myPlaylists=await db.select().from(playlists).where(eq(playlists.userId,userId)).orderBy(desc(playlists.createdAt));
  const savedPl=await db.select().from(playlistSaves).where(eq(playlistSaves.userId,userId));
  const allPl=await db.select().from(playlists);
  const pts=await db.select().from(playlistTracks);
  const enrich=(p:any)=>({...p, trackCount:pts.filter(x=>x.playlistId===p.id).length, trackIds:pts.filter(x=>x.playlistId===p.id).sort((a:any,b:any)=>a.position-b.position).map((x:any)=>x.trackId)});
  const followed=await db.select().from(artistFollows).where(eq(artistFollows.userId,userId));
  const savedAlbumsRows=await db.select().from(albumSaves).where(eq(albumSaves.userId,userId));
  const hist=await db.select().from(history).where(eq(history.userId,userId)).orderBy(desc(history.playedAt)).limit(50);
  const histTracks= hist.length? await serializeTracks(await db.select().from(tracks)) : [];
  const notifs=await db.select().from(notifications).where(eq(notifications.userId,userId)).orderBy(desc(notifications.createdAt)).limit(30);
  const following=await db.select().from(userFollows).where(eq(userFollows.followerId,userId));
  const followers=await db.select().from(userFollows).where(eq(userFollows.followingId,userId));
  return {
    favorites:favTracks, favoriteIds:favs.map(f=>f.trackId),
    playlists:myPlaylists.map(enrich),
    savedPlaylists: allPl.filter(p=>savedPl.some(s=>s.playlistId===p.id)).map(enrich),
    followedArtistIds:followed.map(f=>f.artistId),
    savedAlbumIds:savedAlbumsRows.map(s=>s.albumId),
    history: hist.map(h=>({id:h.id, playedAt:h.playedAt, track: histTracks.find((t:any)=>t.id===h.trackId)})).filter(x=>x.track),
    notifications:notifs,
    followingIds:following.map(f=>f.followingId), followerCount:followers.length, followingCount:following.length,
  };
}

export async function GET(){
  await ensureSeed(); const me=await getCurrentUser(); if(!me) return NextResponse.json({error:"unauthorized"},{status:401});
  return NextResponse.json(await library(me.id));
}

export async function POST(req:Request){
  await ensureSeed(); const me=await getCurrentUser(); if(!me) return NextResponse.json({error:"Faça login para usar este recurso."},{status:401});
  const b=await req.json().catch(()=>({})); const a=b.action;
  try{
    if(a==="toggle-favorite"){
      const [ex]=await db.select().from(favorites).where(and(eq(favorites.userId,me.id), eq(favorites.trackId,b.trackId))).limit(1);
      if(ex) await db.delete(favorites).where(eq(favorites.id,ex.id)); else await db.insert(favorites).values({userId:me.id, trackId:b.trackId});
    }
    else if(a==="play"){
      const [t]=await db.select().from(tracks).where(eq(tracks.id,b.trackId)).limit(1); if(!t) return NextResponse.json({error:"Música não encontrada."},{status:404});
      await db.update(tracks).set({plays:(t.plays||0)+1}).where(eq(tracks.id,t.id));
      if(!me.historyPrivate) await db.insert(history).values({userId:me.id, trackId:t.id});
    }
    else if(a==="toggle-follow-artist"){
      const [ex]=await db.select().from(artistFollows).where(and(eq(artistFollows.userId,me.id), eq(artistFollows.artistId,b.artistId))).limit(1);
      if(ex) await db.delete(artistFollows).where(eq(artistFollows.id,ex.id)); else await db.insert(artistFollows).values({userId:me.id, artistId:b.artistId});
    }
    else if(a==="toggle-follow-user"){
      if(b.userId===me.id) return NextResponse.json({error:"Você não pode seguir a si mesmo."},{status:400});
      const [ex]=await db.select().from(userFollows).where(and(eq(userFollows.followerId,me.id), eq(userFollows.followingId,b.userId))).limit(1);
      if(ex) await db.delete(userFollows).where(eq(userFollows.id,ex.id)); else { await db.insert(userFollows).values({followerId:me.id, followingId:b.userId}); await db.insert(notifications).values({userId:b.userId, title:"Novo seguidor", body:`${me.displayName} começou a seguir você.`}); }
    }
    else if(a==="toggle-save-album"){
      const [ex]=await db.select().from(albumSaves).where(and(eq(albumSaves.userId,me.id), eq(albumSaves.albumId,b.albumId))).limit(1);
      if(ex) await db.delete(albumSaves).where(eq(albumSaves.id,ex.id)); else await db.insert(albumSaves).values({userId:me.id, albumId:b.albumId});
    }
    else if(a==="toggle-save-playlist"){
      const [ex]=await db.select().from(playlistSaves).where(and(eq(playlistSaves.userId,me.id), eq(playlistSaves.playlistId,b.playlistId))).limit(1);
      if(ex) await db.delete(playlistSaves).where(eq(playlistSaves.id,ex.id)); else await db.insert(playlistSaves).values({userId:me.id, playlistId:b.playlistId});
    }
    else if(a==="create-playlist"){
      if(!b.name?.trim()) return NextResponse.json({error:"Dê um nome à playlist."},{status:400});
      const [p]=await db.insert(playlists).values({userId:me.id, name:b.name.trim(), description:b.description||"", coverUrl:b.coverUrl||"", isPublic:b.isPublic!==false, isCollaborative:!!b.isCollaborative}).returning();
      return NextResponse.json({playlist:p, library: await library(me.id)});
    }
    else if(a==="update-playlist"){
      const [p]=await db.select().from(playlists).where(eq(playlists.id,b.playlistId)).limit(1);
      if(!p) return NextResponse.json({error:"Playlist não encontrada."},{status:404});
      if(p.userId!==me.id && !p.isCollaborative && me.role!=="admin") return NextResponse.json({error:"Sem permissão para editar."},{status:403});
      await db.update(playlists).set({name:b.name??p.name, description:b.description??p.description, coverUrl:b.coverUrl??p.coverUrl, isPublic:b.isPublic??p.isPublic, isCollaborative:b.isCollaborative??p.isCollaborative}).where(eq(playlists.id,p.id));
    }
    else if(a==="delete-playlist"){
      const [p]=await db.select().from(playlists).where(eq(playlists.id,b.playlistId)).limit(1);
      if(!p|| (p.userId!==me.id && me.role!=="admin")) return NextResponse.json({error:"Sem permissão."},{status:403});
      await db.delete(playlistTracks).where(eq(playlistTracks.playlistId,p.id)); await db.delete(playlists).where(eq(playlists.id,p.id));
    }
    else if(a==="add-to-playlist"){
      const [p]=await db.select().from(playlists).where(eq(playlists.id,b.playlistId)).limit(1);
      if(!p) return NextResponse.json({error:"Playlist não encontrada."},{status:404});
      if(p.userId!==me.id && !p.isCollaborative && me.role!=="admin") return NextResponse.json({error:"Sem permissão para adicionar."},{status:403});
      const existing=await db.select().from(playlistTracks).where(eq(playlistTracks.playlistId,p.id));
      if(existing.some(x=>x.trackId===b.trackId)) return NextResponse.json({error:"Música já está nesta playlist."},{status:409});
      await db.insert(playlistTracks).values({playlistId:p.id, trackId:b.trackId, addedBy:me.id, position:existing.length});
    }
    else if(a==="remove-from-playlist"){
      const [p]=await db.select().from(playlists).where(eq(playlists.id,b.playlistId)).limit(1);
      if(!p|| (p.userId!==me.id && !p.isCollaborative && me.role!=="admin")) return NextResponse.json({error:"Sem permissão."},{status:403});
      await db.delete(playlistTracks).where(and(eq(playlistTracks.playlistId,p.id), eq(playlistTracks.trackId,b.trackId)));
    }
    else if(a==="duplicate-playlist"){
      const [p]=await db.select().from(playlists).where(eq(playlists.id,b.playlistId)).limit(1); if(!p) return NextResponse.json({error:"Playlist não encontrada."},{status:404});
      if(!p.isPublic && p.userId!==me.id) return NextResponse.json({error:"Playlist privada."},{status:403});
      const [np]=await db.insert(playlists).values({userId:me.id, name:p.name+" (cópia)", description:p.description, coverUrl:p.coverUrl, isPublic:false}).returning();
      const items=await db.select().from(playlistTracks).where(eq(playlistTracks.playlistId,p.id));
      for(const it of items.sort((x,y)=>x.position-y.position)) await db.insert(playlistTracks).values({playlistId:np.id, trackId:it.trackId, addedBy:me.id, position:it.position});
      return NextResponse.json({playlist:np, library: await library(me.id)});
    }
    else if(a==="clear-history"){ await db.delete(history).where(eq(history.userId,me.id)); }
    else if(a==="remove-history"){ await db.delete(history).where(and(eq(history.userId,me.id), eq(history.id,b.historyId))); }
    else if(a==="mark-notifications"){ await db.update(notifications).set({read:true}).where(eq(notifications.userId,me.id)); }
    else if(a==="report"){ if(!b.reason) return NextResponse.json({error:"Descreva o motivo."},{status:400}); await db.insert(reports).values({userId:me.id, targetType:b.targetType||"track", targetId:b.targetId, reason:b.reason}); return NextResponse.json({ok:true, message:"Denúncia enviada para moderação."}); }
    else return NextResponse.json({error:"Ação inválida."},{status:400});
    return NextResponse.json({ok:true, library: await library(me.id)});
  }catch(e:any){ console.error(e); return NextResponse.json({error:"Erro ao salvar. Tente novamente."},{status:500}); }
}
