import { NextResponse } from "next/server";
import { db } from "@/db";
import { userPreferences } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/catalog";

const THEMES = ["original", "rosa", "verde", "azul", "amarelo"];

export async function GET() {
  await ensureSeed();
  const me = await getCurrentUser(); if (!me) return NextResponse.json({ error: "Faça login." }, { status: 401 });
  const [p] = await db.select().from(userPreferences).where(eq(userPreferences.userId, me.id)).limit(1);
  return NextResponse.json({ prefs: p || { theme: "original", favoriteGenres: "[]", onboardingDone: false, cookieConsent: "" } });
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getCurrentUser(); if (!me) return NextResponse.json({ error: "Faça login." }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const [existing] = await db.select().from(userPreferences).where(eq(userPreferences.userId, me.id)).limit(1);
  const vals: any = {
    userId: me.id,
    theme: THEMES.includes(b.theme) ? b.theme : (existing?.theme || "original"),
    favoriteGenres: Array.isArray(b.favoriteGenres) ? JSON.stringify(b.favoriteGenres.slice(0, 20)) : (existing?.favoriteGenres || "[]"),
    onboardingDone: typeof b.onboardingDone === "boolean" ? b.onboardingDone : (existing?.onboardingDone || false),
    cookieConsent: typeof b.cookieConsent === "object" && b.cookieConsent ? JSON.stringify({ ...b.cookieConsent, ts: new Date().toISOString() }) : (existing?.cookieConsent || ""),
    updatedAt: new Date(),
  };
  if (existing) await db.update(userPreferences).set(vals).where(eq(userPreferences.id, existing.id));
  else await db.insert(userPreferences).values(vals);
  return NextResponse.json({ ok: true, prefs: vals });
}
