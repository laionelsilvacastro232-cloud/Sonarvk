import { ProfilePage } from "@/components/pages";
export default function Page(){ return <ProfilePage/>; }
